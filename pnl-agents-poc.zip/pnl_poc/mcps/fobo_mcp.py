"""FOBO agent — runs front-office vs back-office reconciliation and surfaces breaks.

Production wiring: reads from FO and BO position systems. For the POC, the data
file holds pre-computed gross/net numbers and known breaks.
"""
from mcp.server.fastmcp import FastMCP
from _shared import load_data, audit_log

mcp = FastMCP("fobo")


@mcp.tool()
def run_recon(book_id: str) -> dict:
    """Run FOBO reconciliation for a book. Returns reconciliation result + any breaks.

    Args:
        book_id: e.g. RATES-EUR-001

    Returns:
        {
          "book_id", "matched": bool, "fo_gross", "bo_gross", "diff",
          "breaks": [{"break_id", ...}]
        }
    """
    data = load_data()
    audit_log("fobo", "run_recon", {"book_id": book_id})

    fo = data["fo_pnl"].get(book_id)
    bo = data["bo_pnl"].get(book_id)
    if not fo or not bo:
        return {"error": f"No FO/BO data for {book_id}"}

    diff = fo["gross"] - bo["gross"]
    breaks = [b for b in data["breaks"] if b["book_id"] == book_id]

    return {
        "book_id": book_id,
        "matched": diff == 0,
        "fo_gross": fo["gross"],
        "bo_gross": bo["gross"],
        "diff": diff,
        "breaks": breaks,
    }


@mcp.tool()
def get_break_detail(break_id: str) -> dict:
    """Return full detail for a specific break record."""
    data = load_data()
    audit_log("fobo", "get_break_detail", {"break_id": break_id})
    for b in data["breaks"]:
        if b["break_id"] == break_id:
            return b
    return {"error": f"break_id {break_id} not found"}


@mcp.tool()
def list_breaks(book_id: str | None = None) -> dict:
    """List all breaks, optionally filtered by book."""
    data = load_data()
    audit_log("fobo", "list_breaks", {"book_id": book_id})
    breaks = data["breaks"]
    if book_id:
        breaks = [b for b in breaks if b["book_id"] == book_id]
    return {"count": len(breaks), "breaks": breaks}


if __name__ == "__main__":
    mcp.run()
