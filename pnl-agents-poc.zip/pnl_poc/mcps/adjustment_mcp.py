"""Adjustment agent — drafts adjustment journals with policy citation.

CRITICAL: this agent NEVER posts to GL. It drafts only.
The post_journal tool exists for the orchestrator-controller workflow but
requires an approver_id + OTP, simulating the human in the loop.
"""
import uuid
from mcp.server.fastmcp import FastMCP
from _shared import load_data, save_data, audit_log, now_iso

mcp = FastMCP("adjustment")


@mcp.tool()
def draft_adjustment(book_id: str, amount: float, narrative: str, policy_ref: str) -> dict:
    """Draft an adjustment journal. Stored as DRAFT — not posted to the GL.

    Args:
        book_id: e.g. RATES-EUR-001
        amount: signed USD amount
        narrative: rationale text
        policy_ref: policy identifier (e.g. PAD-RATES-002)

    Returns:
        {"draft_id", "status": "DRAFT", ...}
    """
    data = load_data()
    audit_log("adjustment", "draft_adjustment",
              {"book_id": book_id, "amount": amount, "policy_ref": policy_ref})

    # Validate policy exists and amount within threshold
    policy = next((p for p in data["policies"] if p["policy_ref"] == policy_ref), None)
    if not policy:
        return {"error": f"Unknown policy_ref {policy_ref}"}
    if abs(amount) > policy["threshold"]:
        return {
            "error": "amount exceeds policy threshold",
            "policy_ref": policy_ref,
            "threshold": policy["threshold"],
            "requested": amount,
            "remediation": "Escalate to senior controller; cannot auto-draft above threshold."
        }

    draft = {
        "draft_id": f"ADJ-{uuid.uuid4().hex[:8].upper()}",
        "book_id": book_id,
        "amount": amount,
        "narrative": narrative,
        "policy_ref": policy_ref,
        "policy_title": policy["title"],
        "status": "DRAFT",
        "drafted_at": now_iso(),
        "posted_at": None,
        "approver": None,
    }
    data["_ephemeral"]["drafts"].append(draft)
    save_data(data)
    return draft


@mcp.tool()
def list_drafts(book_id: str | None = None) -> dict:
    """List adjustment drafts that are pending approval (status=DRAFT)."""
    data = load_data()
    audit_log("adjustment", "list_drafts", {"book_id": book_id})
    drafts = [d for d in data["_ephemeral"]["drafts"] if d["status"] == "DRAFT"]
    if book_id:
        drafts = [d for d in drafts if d["book_id"] == book_id]
    return {"count": len(drafts), "drafts": drafts}


@mcp.tool()
def post_journal(draft_id: str, approver_id: str, otp: str) -> dict:
    """Post a previously-drafted adjustment to the GL.

    THIS REQUIRES A HUMAN: the orchestrator MUST NOT call this. The cockpit
    (human-facing UI) collects approver_id and OTP from the controller and
    invokes this tool on the controller's behalf.

    Args:
        draft_id: ID returned by draft_adjustment
        approver_id: PC controller user ID
        otp: one-time password / MFA token

    Returns:
        {"status": "POSTED", "draft_id", "posted_at", ...} or {"error": ...}
    """
    data = load_data()
    audit_log("adjustment", "post_journal",
              {"draft_id": draft_id, "approver_id": approver_id})

    if otp != "123456":  # POC stand-in for real MFA verification
        return {"error": "OTP verification failed", "draft_id": draft_id}

    for d in data["_ephemeral"]["drafts"]:
        if d["draft_id"] == draft_id and d["status"] == "DRAFT":
            d["status"] = "POSTED"
            d["posted_at"] = now_iso()
            d["approver"] = approver_id
            save_data(data)
            return d
    return {"error": f"No pending draft {draft_id}"}


if __name__ == "__main__":
    mcp.run()
