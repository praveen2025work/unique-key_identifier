"""Monitoring agent — detects when books are ready in CFC and exposes status.

Production wiring: subscribes to MOTIF book-state events; for the POC we read
mock_data.json. Tools are read-only.
"""
from mcp.server.fastmcp import FastMCP
from _shared import load_data, audit_log

mcp = FastMCP("monitoring")


@mcp.tool()
def list_open_books(date: str | None = None) -> dict:
    """List all books that are open in CFC and therefore ready for downstream processing.

    Args:
        date: as-of date (YYYY-MM-DD). Defaults to the snapshot date.

    Returns:
        {"as_of_date": str, "open_books": [{"book_id", "name", "desk", "ready_at"}]}
    """
    data = load_data()
    audit_log("monitoring", "list_open_books", {"date": date})
    open_books = [
        {"book_id": b["book_id"], "name": b["name"], "desk": b["desk"], "ready_at": b["ready_at"]}
        for b in data["books"] if b["status"] == "open_in_cfc"
    ]
    return {"as_of_date": data["as_of_date"], "open_books": open_books}


@mcp.tool()
def check_book_status(book_id: str) -> dict:
    """Return the CFC status for a specific book.

    Args:
        book_id: e.g. RATES-EUR-001

    Returns:
        {"book_id", "status", "ready_at", "name", "desk"} or {"error": ...} if not found
    """
    data = load_data()
    audit_log("monitoring", "check_book_status", {"book_id": book_id})
    for b in data["books"]:
        if b["book_id"] == book_id:
            return b
    return {"error": f"book_id {book_id} not found"}


@mcp.tool()
def wait_for_book_ready(book_id: str) -> dict:
    """Block-style check: report whether the book is ready, and the orchestrator
    decides whether to proceed or revisit. The POC does not actually block.
    """
    status = check_book_status(book_id)
    if "error" in status:
        return status
    return {
        "book_id": book_id,
        "ready": status.get("status") == "open_in_cfc",
        "ready_at": status.get("ready_at"),
    }


if __name__ == "__main__":
    mcp.run()
