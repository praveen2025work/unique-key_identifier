"""Exception agent — classifies breaks, suggests resolution, creates exception records.

Classification taxonomy mirrors what PC controllers use:
  - market_move   (no action needed beyond commentary)
  - new_trade     (book reconciliation needed)
  - data_quality  (upstream system issue — route to support)
  - book_error    (genuine booking error — adjustment needed)
"""
import uuid
from mcp.server.fastmcp import FastMCP
from _shared import load_data, save_data, audit_log, now_iso

mcp = FastMCP("exception")

CLASSIFY_RULES = {
    "market_move":  lambda b: abs(b["diff"]) < 10000 and b["age_hours"] < 1.0,
    "data_quality": lambda b: abs(b["diff"]) < 5000 and b["age_hours"] > 1.0,
    "book_error":   lambda b: abs(b["diff"]) >= 5000 and b["age_hours"] >= 1.0,
}


@mcp.tool()
def classify_break(break_id: str) -> dict:
    """Classify a break by root cause using deterministic rules.

    Args:
        break_id: e.g. BRK-001

    Returns:
        {"break_id", "classification", "confidence", "suggested_resolution"}
    """
    data = load_data()
    audit_log("exception", "classify_break", {"break_id": break_id})

    brk = next((b for b in data["breaks"] if b["break_id"] == break_id), None)
    if not brk:
        return {"error": f"break_id {break_id} not found"}

    for label, rule in CLASSIFY_RULES.items():
        if rule(brk):
            return {
                "break_id": break_id,
                "classification": label,
                "confidence": 0.85,
                "suggested_resolution": _resolution_for(label, brk),
            }
    return {
        "break_id": break_id,
        "classification": "new_trade",
        "confidence": 0.55,
        "suggested_resolution": "Reconcile with FO; new trade likely not yet posted to BO."
    }


def _resolution_for(label: str, brk: dict) -> str:
    if label == "market_move":
        return f"Acceptable variance of ${brk['diff']:+,}. No adjustment needed; document in commentary."
    if label == "data_quality":
        return "Stale feed suspected. Route to data ops; do not adjust pending refresh."
    if label == "book_error":
        return f"Draft adjustment for ${-brk['diff']:+,} citing PAD-RATES-002. Requires PC approval to post."
    return "Investigate further."


@mcp.tool()
def create_exception(break_id: str, classification: str, suggested_resolution: str) -> dict:
    """Create an exception record in the Exception Hub for human triage."""
    data = load_data()
    audit_log("exception", "create_exception",
              {"break_id": break_id, "classification": classification})

    exc = {
        "exception_id": f"EXC-{uuid.uuid4().hex[:8].upper()}",
        "break_id": break_id,
        "classification": classification,
        "suggested_resolution": suggested_resolution,
        "status": "OPEN",
        "created_at": now_iso(),
        "resolved_at": None,
        "resolver": None,
    }
    data["_ephemeral"]["exceptions"].append(exc)
    save_data(data)
    return exc


@mcp.tool()
def list_exceptions(status: str | None = "OPEN") -> dict:
    """List exceptions in the hub, optionally filtered by status."""
    data = load_data()
    audit_log("exception", "list_exceptions", {"status": status})
    exceptions = data["_ephemeral"]["exceptions"]
    if status:
        exceptions = [e for e in exceptions if e["status"] == status]
    return {"count": len(exceptions), "exceptions": exceptions}


if __name__ == "__main__":
    mcp.run()
