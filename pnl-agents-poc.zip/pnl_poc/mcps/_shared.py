"""Shared utilities for all MCP agents.

In production these would be:
  - data layer  → BOFC / MOTIF / P&L Engine APIs
  - audit_log() → append-only audit store (WORM)
  - now()       → time service (with snapshot-time for determinism)
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "mock_data.json"
AUDIT_FILE = Path(__file__).resolve().parent.parent / "data" / "audit_log.jsonl"


def load_data() -> dict:
    """Load the mock backing store. Re-reads on each call to allow cross-MCP visibility."""
    with open(DATA_FILE) as f:
        return json.load(f)


def save_data(data: dict) -> None:
    """Persist the mock backing store after mutation."""
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def audit_log(agent: str, action: str, payload: dict) -> None:
    """Append-only audit log. In production this is the WORM record MRM reviews."""
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "agent": agent,
        "action": action,
        "payload": payload,
    }
    with open(AUDIT_FILE, "a") as f:
        f.write(json.dumps(record) + "\n")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
