"""P&L Prep agent — assembles the desk-level P&L and reconciles to manual baseline.

This is the agent that produces the FINAL number that goes to the front office,
once all upstream agents have completed and tollgates are cleared.
"""
import uuid
from mcp.server.fastmcp import FastMCP
from _shared import load_data, save_data, audit_log, now_iso

mcp = FastMCP("pnl_prep")


@mcp.tool()
def assemble_pnl(book_id: str) -> dict:
    """Assemble the final desk-level P&L for a book, applying any POSTED adjustments.

    Returns:
        {
          "book_id", "fo_gross", "bo_gross", "adjustments_posted",
          "final_pnl", "trade_count"
        }
    """
    data = load_data()
    audit_log("pnl_prep", "assemble_pnl", {"book_id": book_id})

    fo = data["fo_pnl"].get(book_id)
    bo = data["bo_pnl"].get(book_id)
    if not fo:
        return {"error": f"No P&L data for {book_id}"}

    posted_adjustments = [
        d for d in data["_ephemeral"]["drafts"]
        if d["book_id"] == book_id and d["status"] == "POSTED"
    ]
    adj_total = sum(d["amount"] for d in posted_adjustments)

    snapshot = {
        "snapshot_id": f"PNL-{uuid.uuid4().hex[:8].upper()}",
        "book_id": book_id,
        "fo_gross": fo["gross"],
        "bo_gross": bo["gross"] if bo else None,
        "adjustments_posted": [
            {"draft_id": d["draft_id"], "amount": d["amount"], "policy_ref": d["policy_ref"]}
            for d in posted_adjustments
        ],
        "adjustments_total": adj_total,
        "final_pnl": bo["gross"] + adj_total if bo else fo["gross"] + adj_total,
        "trade_count": fo["trades"],
        "snapshot_at": now_iso(),
    }
    data["_ephemeral"]["snapshots"].append(snapshot)
    save_data(data)
    return snapshot


@mcp.tool()
def reconcile_baseline(book_id: str, manual_baseline: float) -> dict:
    """Compare agent-produced P&L vs manually-produced baseline.

    Used during shadow-mode rollout to prove the agent flow matches the
    existing manual workflow.

    Args:
        book_id: e.g. RATES-EUR-001
        manual_baseline: signed USD P&L from the manual process

    Returns:
        {"book_id", "agent_pnl", "manual_baseline", "diff", "matches": bool}
    """
    audit_log("pnl_prep", "reconcile_baseline",
              {"book_id": book_id, "manual_baseline": manual_baseline})
    snapshot = assemble_pnl(book_id)
    if "error" in snapshot:
        return snapshot
    agent_pnl = snapshot["final_pnl"]
    diff = agent_pnl - manual_baseline
    return {
        "book_id": book_id,
        "agent_pnl": agent_pnl,
        "manual_baseline": manual_baseline,
        "diff": diff,
        "matches": abs(diff) < 1.0,
    }


if __name__ == "__main__":
    mcp.run()
