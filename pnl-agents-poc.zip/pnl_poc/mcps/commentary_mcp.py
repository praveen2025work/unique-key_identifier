"""Commentary agent — drafts desk-head commentary in their voice using historical patterns.

The actual narrative drafting happens in the orchestrator LLM. This MCP provides
the deterministic context (history, P&L data) the orchestrator needs to draft well.
"""
from mcp.server.fastmcp import FastMCP
from _shared import load_data, audit_log

mcp = FastMCP("commentary")


@mcp.tool()
def get_history(book_id: str, n_days: int = 5) -> dict:
    """Return prior commentaries for a book so the orchestrator can match voice + style.

    Args:
        book_id: e.g. RATES-EUR-001
        n_days: how many recent commentaries to return

    Returns:
        {"book_id", "history": [{"date", "text"}]}
    """
    data = load_data()
    audit_log("commentary", "get_history", {"book_id": book_id, "n_days": n_days})
    history = [c for c in data["commentary_history"] if c["book_id"] == book_id]
    history = sorted(history, key=lambda x: x["date"], reverse=True)[:n_days]
    return {"book_id": book_id, "history": history}


@mcp.tool()
def get_pnl_context(book_id: str) -> dict:
    """Return the data the orchestrator needs to write commentary:
    FO/BO numbers, any posted adjustments, recent break activity.
    """
    data = load_data()
    audit_log("commentary", "get_pnl_context", {"book_id": book_id})

    fo = data["fo_pnl"].get(book_id, {})
    bo = data["bo_pnl"].get(book_id, {})
    breaks = [b for b in data["breaks"] if b["book_id"] == book_id]
    posted = [
        d for d in data["_ephemeral"]["drafts"]
        if d["book_id"] == book_id and d["status"] == "POSTED"
    ]
    return {
        "book_id": book_id,
        "fo_pnl": fo,
        "bo_pnl": bo,
        "breaks": breaks,
        "posted_adjustments": posted,
    }


if __name__ == "__main__":
    mcp.run()
