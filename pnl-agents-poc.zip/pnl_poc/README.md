# P&L Agent POC — MCP-based orchestration

A working proof-of-concept for the P&L workflow agent design. Each specialist agent is
implemented as an **MCP server** (stdio transport); the **orchestrator** is either Claude Code
running interactively, or a Python script using the Claude Agent SDK.

This is the **agents-as-tools** pattern: the intelligence (orchestration, reasoning, narrative)
lives in one auditable Claude session; each agent is a deterministic, testable tool surface.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│ Orchestrator (Claude Code interactive  OR  Agent SDK script)    │
│ system_prompt.md defines toll-gate behaviour + tool flow        │
└──────┬──────────────────────────────────────────────────────────┘
       │ MCP (stdio)
       ▼
┌────────────┬────────────┬──────────────┬────────────┬───────────┬─────────────┐
│ monitoring │ fobo       │ adjustment   │ exception  │ pnl_prep  │ commentary  │
│  3 tools   │  3 tools   │  3 tools     │  3 tools   │  2 tools  │  2 tools    │
└─────┬──────┴─────┬──────┴──────┬───────┴─────┬──────┴─────┬─────┴──────┬──────┘
      └────────────┴─────────────┴─────────────┴────────────┴────────────┘
                                  data/mock_data.json
                              (stands in for MOTIF/BOFC/P&L Engine/Exception Hub)
```

Every tool call is appended to `data/audit_log.jsonl` — the audit trail MRM would review.

## What's in the box

| Agent      | MCP tools                                                                | Maps to deck slide |
|------------|--------------------------------------------------------------------------|--------------------|
| monitoring | `list_open_books`, `check_book_status`, `wait_for_book_ready`            | Stage 1            |
| fobo       | `run_recon`, `get_break_detail`, `list_breaks`                           | Stage 2            |
| exception  | `classify_break`, `create_exception`, `list_exceptions`                  | Stage 2 / 3        |
| adjustment | `draft_adjustment`, `list_drafts`, `post_journal` *(human-only)*         | Stage 3 + toll gate|
| pnl_prep   | `assemble_pnl`, `reconcile_baseline`                                     | Stage 4            |
| commentary | `get_history`, `get_pnl_context`                                         | Stage 5            |

## Setup

```bash
# 1. Python 3.10+ recommended
python --version

# 2. Install deps
pip install -r requirements.txt

# 3. (Optional, recommended) — verify Claude Code is installed
claude --version
# If not installed: curl -fsSL https://claude.ai/install.sh | bash

# 4. Set credentials. Two options:
#    a) Anthropic API directly:
export ANTHROPIC_API_KEY=sk-ant-...
#    b) Bedrock (matches your AOF setup) — see ANTHROPIC_BEDROCK section below
```

## Run option A — Interactive Claude Code

This is the fastest test path. Claude Code auto-discovers `.mcp.json` in the project root.

```bash
cd pnl-agents-poc
claude
```

Claude Code starts; the six MCPs are loaded as subprocesses. Then type:

```
Read orchestrator/system_prompt.md and follow it. Run the daily P&L workflow for book
RATES-EUR-001. Stop at toll gates and summarize what would need a human controller.
```

You'll see Claude Code:
1. Read the system prompt
2. Call `mcp__monitoring__check_book_status` to confirm the book is open
3. Call `mcp__fobo__run_recon` and find the break
4. Call `mcp__exception__classify_break` to classify it
5. Either draft an adjustment or document it as a market move
6. Call `mcp__pnl_prep__assemble_pnl` to produce the final number
7. Call `mcp__commentary__get_history` + `get_pnl_context` and draft commentary

If at any point it tries to call `mcp__adjustment__post_journal`, Claude Code will prompt for
your approval — that's the toll gate working as designed.

## Run option B — Programmatic via Agent SDK

For CI / automated runs / production wiring:

```bash
python orchestrator/run.py RATES-EUR-001
```

The script uses `claude_agent_sdk.query()` with the same MCPs configured. `post_journal` is
deliberately omitted from `allowed_tools`, so any attempt to post will trigger a permission
prompt (which fails in non-interactive mode — the correct safety behaviour).

## Inspect the audit trail

```bash
cat data/audit_log.jsonl | jq .
```

Every tool call is logged with timestamp, agent name, action, and payload. This is the
artifact you'd hand to MRM / Internal Audit to demonstrate reproducibility.

To clear it before a fresh run:

```bash
rm data/audit_log.jsonl
```

## Test scenarios

See `tests/scenarios.md` for six scenarios that exercise:
- Happy path (market_move classification, no adjustment)
- Book error path (draft adjustment, halt at toll gate)
- Above-threshold escalation
- Pending book (no downstream calls)
- Audit trail completeness
- Determinism of numbers vs narrative

## Bedrock / AOF wiring

To run against Bedrock instead of the Anthropic API (matches your AOF setup):

```bash
export CLAUDE_CODE_USE_BEDROCK=1
export AWS_REGION=us-east-1
# Use whichever AWS auth method your AOF environment uses (profile, IAM role, etc.)
export AWS_PROFILE=aof-dev
```

The SDK and Claude Code both honour these env vars. No code changes needed.

## What to demonstrate to your manager / Anthropic

1. **The six MCPs each map to one slide in the deck.** Open the SKILL: the architecture
   slide → six specialist tiles → six MCP servers. One-to-one.

2. **The toll-gate guarantee.** Run a `book_error` scenario, point at the audit log,
   show that `post_journal` was never called by the agent. Then run it interactively
   and manually post — show how the cockpit (you) provides the OTP.

3. **The MRM story.** Show the audit log. Every number traceable to a tool call.
   LLM narrative annotates the numbers, never produces them.

4. **The extension model.** Adding a 7th agent = one new file in `mcps/`, one entry in
   `.mcp.json` and `run.py`, one paragraph in `system_prompt.md`. No core changes.

5. **The deterministic substrate under the agent layer.** Tools always return the same
   output for the same input. Run Scenario 6 to prove it.

## Limitations of the POC

- Mock data only — no real MOTIF / BOFC / P&L Engine integration
- Single-book runs only — no fan-out across the 200 name PNLs
- No persistence beyond JSON file — production needs Oracle / WORM audit store
- No four-eyes enforcement — `approver_id` is unchecked, OTP is hard-coded `123456`
- No real MRM validation pack — the audit log is the *substrate* MRM would build on

## Next steps after the POC works

1. **Replace one mock with a real read-only integration.** Easiest: P&L Engine, since
   you already have one. Hardest: MOTIF events (would need event subscription).
2. **Add the Lineage MCP** — wraps your existing P&L Lineage Dashboard FastAPI.
3. **Add real auth + four-eyes** — Central Enterprise Entitlement System exposed as
   `check_authorization` tool, called by every other tool before executing.
4. **Add evals.** For each scenario above, define an expected structured output;
   regression-test the orchestrator against scenarios over time.
5. **Wire into AgentCore Gateway** — when you're ready to move from local POC to
   AOF-runtime, the MCPs become AgentCore tools; the orchestrator runs on Bedrock.

## File map

```
pnl-agents-poc/
├── README.md                       ← this file
├── requirements.txt
├── .mcp.json                       ← Claude Code auto-discovery
├── data/
│   ├── mock_data.json              ← stands in for MOTIF/BOFC/...
│   └── audit_log.jsonl             ← created on first run
├── mcps/
│   ├── _shared.py                  ← load_data / save_data / audit_log helpers
│   ├── monitoring_mcp.py
│   ├── fobo_mcp.py
│   ├── adjustment_mcp.py
│   ├── exception_mcp.py
│   ├── pnl_prep_mcp.py
│   └── commentary_mcp.py
├── orchestrator/
│   ├── system_prompt.md            ← toll-gate behaviour rules
│   └── run.py                      ← SDK-based orchestrator
└── tests/
    └── scenarios.md                ← six test scenarios
```
