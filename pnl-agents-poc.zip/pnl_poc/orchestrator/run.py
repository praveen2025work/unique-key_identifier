"""Programmatic orchestrator using the Claude Agent SDK.

Run:
    python orchestrator/run.py RATES-EUR-001

Make sure ANTHROPIC_API_KEY is set, or configure Bedrock via
CLAUDE_CODE_USE_BEDROCK=1 + AWS credentials (matches your AOF setup).
"""
import asyncio
import sys
from pathlib import Path

from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage

ROOT = Path(__file__).resolve().parent.parent
SYSTEM_PROMPT = (ROOT / "orchestrator" / "system_prompt.md").read_text()


def build_options() -> ClaudeAgentOptions:
    """Configure MCP servers + tool allowlist for the orchestrator."""
    return ClaudeAgentOptions(
        cwd=str(ROOT),
        system_prompt=SYSTEM_PROMPT,
        mcp_servers={
            "monitoring": {"type": "stdio", "command": "python", "args": ["mcps/monitoring_mcp.py"]},
            "fobo":       {"type": "stdio", "command": "python", "args": ["mcps/fobo_mcp.py"]},
            "adjustment": {"type": "stdio", "command": "python", "args": ["mcps/adjustment_mcp.py"]},
            "exception":  {"type": "stdio", "command": "python", "args": ["mcps/exception_mcp.py"]},
            "pnl_prep":   {"type": "stdio", "command": "python", "args": ["mcps/pnl_prep_mcp.py"]},
            "commentary": {"type": "stdio", "command": "python", "args": ["mcps/commentary_mcp.py"]},
        },
        # Pre-approve read tools and draft tools. Post_journal is intentionally NOT here —
        # any attempt to post would prompt for permission (or fail if permission_mode bypasses).
        allowed_tools=[
            "mcp__monitoring__list_open_books",
            "mcp__monitoring__check_book_status",
            "mcp__monitoring__wait_for_book_ready",
            "mcp__fobo__run_recon",
            "mcp__fobo__get_break_detail",
            "mcp__fobo__list_breaks",
            "mcp__adjustment__draft_adjustment",
            "mcp__adjustment__list_drafts",
            # NOTE: mcp__adjustment__post_journal is deliberately omitted.
            "mcp__exception__classify_break",
            "mcp__exception__create_exception",
            "mcp__exception__list_exceptions",
            "mcp__pnl_prep__assemble_pnl",
            "mcp__pnl_prep__reconcile_baseline",
            "mcp__commentary__get_history",
            "mcp__commentary__get_pnl_context",
        ],
        permission_mode="default",  # Will prompt for any non-pre-approved tool (incl. post_journal)
        max_turns=20,
    )


async def run_workflow(book_id: str):
    prompt = (
        f"Run the daily P&L workflow for book {book_id} for the current snapshot date. "
        f"Follow the stages in your system prompt. STOP at each toll gate and summarize. "
        f"For this POC run, after drafting adjustments, simulate the controller having "
        f"approved them — i.e. proceed to P&L assembly and commentary as if posting was done."
    )

    print(f"\n{'=' * 70}\nP&L Orchestrator · book={book_id}\n{'=' * 70}\n")

    async for msg in query(prompt=prompt, options=build_options()):
        if isinstance(msg, AssistantMessage):
            for block in msg.content:
                if hasattr(block, "text") and block.text:
                    print(block.text)
                elif hasattr(block, "name"):
                    print(f"  → tool: {block.name}  input={getattr(block, 'input', {})}")
        elif isinstance(msg, ResultMessage):
            print(f"\n{'=' * 70}\nRESULT: {msg.subtype}\n{'=' * 70}")


if __name__ == "__main__":
    book_id = sys.argv[1] if len(sys.argv) > 1 else "RATES-EUR-001"
    asyncio.run(run_workflow(book_id))
