---
name: python-enterprise-dev
description: "Enterprise-grade Python engineering standards — typing, layering, design patterns, testing, and above all safe modification of existing production applications without breaking behavior. Use this skill for ANY Python work not covered by a more specific project skill — writing or reviewing modules, services, APIs (FastAPI/Flask/Django), data pipelines, or scripts; refactoring or extending a legacy/brownfield codebase; adding features to an existing app; fixing bugs; introducing typing, tests, logging, config, or error handling; or scaffolding a new Python project. Trigger whenever the user mentions Python, .py files, FastAPI, pytest, mypy, ruff, refactoring, 'without breaking', legacy code, coding standards, or design patterns — even for small snippets. If a project-specific Python skill also applies, read both; the project skill wins on conflicts."
---

# Python Enterprise Development

Standards for writing and *changing* Python at enterprise quality. The guiding principle: **boring, explicit, typed code that the next engineer understands in 30 seconds — and changes that provably preserve existing behavior.**

Cleverness is a cost. A broken production workflow is a much bigger cost. In brownfield code, correctness of the *change* outranks beauty of the *result*.

## How to use this skill

1. Read this file — the workflow, the prime directive, and the core rules.
2. Modifying an existing/legacy application → `references/safe-change-on-existing-code.md` **(read this before editing any pre-existing module)**
3. Typing, errors, logging, config, style → `references/code-standards.md`
4. Choosing a design pattern (and when not to) → `references/design-patterns.md`
5. Project layout, layering, DI, async → `references/architecture-and-structure.md`
6. Tests, tooling, CI gates → `references/testing-and-quality.md`
7. Before declaring done → `references/quality-checklist.md`

## The prime directive: don't break what works

Most enterprise Python work is *modification*, not creation. Every edit to an existing system carries regression risk, so:

- **Characterize before you change.** If a module has no test that pins its current behavior, write one *first* — asserting what the code does today, bugs included. That test is the contract you must not violate. Recipe in `references/safe-change-on-existing-code.md`.
- **Separate refactor commits from behavior commits.** A commit either changes structure with identical behavior, or changes behavior with minimal structure change. Never both — mixed diffs are unreviewable and unrevertible.
- **Public surface is frozen unless the task says otherwise.** Module paths, function/class names, signatures, return shapes, exception types, log formats consumed by monitoring, config keys, DB schema, and API contracts are all "public" to somebody. Extend with optional keyword arguments; never reorder or remove positional parameters. When something must go, ship a shim and a deprecation window.
- **Wrap, don't rewrite.** Prefer strangler-fig: put the new implementation behind the same interface, route to it behind a flag or config toggle, verify, then remove the old path in a later change.
- **Assume undocumented callers exist.** Grep the repo (and note that jobs, notebooks, and other teams may import it too) before assuming a function is unused.

If the user asks for a large rewrite, still land it as a sequence of individually-safe steps and say so.

## Agentic workflow — how to approach every task

**1. Explore before editing.** Read neighboring code first: how does this codebase structure packages, raise errors, log, inject dependencies, name things, manage config, write tests? Match established conventions even where this skill suggests otherwise — internal consistency beats external best practice. Note the deviation once; don't fight the codebase. Check `pyproject.toml`/`setup.cfg`/`tox.ini` for the actual toolchain, Python version, and lint rules in force before introducing syntax or dependencies the project doesn't support.

**2. Establish the safety net.** For any change to existing code: identify what currently exercises this code (tests, callers, entry points). If coverage is absent, add characterization tests for the paths you're about to touch. This is not optional overhead — it is the only thing that makes the rest of the work verifiable.

**3. Plan proportionally.** One-line fix: just fix it. Feature or refactor: state a 3–6 line plan (modules touched, data flow, external contracts affected, failure modes, rollback) before writing code. Never produce a wall of code for non-trivial work with no stated approach.

**4. Smallest correct diff.** Change what the task requires. Don't reformat untouched code, re-sort imports project-wide, rename unrelated variables, or "improve" adjacent modules — a 900-line whitespace diff hides the 3 lines that matter. Opportunistic fixes are allowed only for genuine bugs in code you're already editing, and must be called out.

**5. Verify.** Run what exists: tests, `mypy`, `ruff`, the app's startup. If nothing is runnable, re-read the diff explicitly checking types, exception paths, resource cleanup, and every caller of anything you changed. Never declare done on unverified code — say plainly what you could and couldn't verify.

**6. Explain the diff.** End with: what changed, why, behavior-preserving vs behavior-changing, contracts affected, what you deliberately deferred, and how to roll back.

## Core rules (the 90% that matters)

**Typing**
- Every public function, method, and dataclass field is annotated. `from __future__ import annotations` at the top of modules for cheap forward references.
- No bare `Any` in new code; no untyped `dict`/`list` as a domain type — model it (`dataclass`, `pydantic.BaseModel`, `TypedDict`, `NamedTuple`).
- Depend on `Protocol`/ABC at boundaries, not concrete classes — that is what makes the code testable and swappable.
- `Optional` means "genuinely absent", not "I haven't decided". Prefer narrow unions and `Literal`/`Enum` over stringly-typed parameters.

**Errors**
- Define a small app-specific exception hierarchy rooted at one base (e.g. `AppError`) and raise those from domain/service code; translate third-party exceptions at the boundary where they occur.
- Never `except Exception: pass`, never a bare `except:`. Catch the narrowest type you can handle, and if you catch broadly at a top-level boundary, log with `exc_info=True` and re-raise or convert deliberately.
- Errors carry context (ids, operation, not secrets). User/API-facing messages are actionable; stack traces go to logs.
- Fail fast on programmer error (assertions, `ValueError` on invalid input); degrade gracefully only on expected operational failure (timeouts, unavailable dependency) and make the degradation explicit.

**Logging & observability**
- Use the stdlib `logging` module with a module-level `logger = logging.getLogger(__name__)`. Never `print` in library or service code. Never configure logging at import time in a library — only in the application entry point.
- Lazy interpolation (`logger.info("loaded %s rows", n)`), structured extras where the platform supports it, and a correlation/request id threaded through a call.
- Never log secrets, tokens, full payloads with PII, or entire credentials-bearing config objects.

**Configuration & secrets**
- All config from environment/config files, loaded once into a typed settings object (`pydantic-settings` or equivalent), validated at startup — not read ad hoc via `os.getenv` scattered through modules.
- No secrets, hostnames, or environment-specific values in source or defaults. No mutable global state as a config channel.

**Data & resources**
- Context managers for every file, connection, session, lock, and temp resource. No manual `close()` in happy-path code.
- Parameterized queries only — never string-formatted SQL. Money is `Decimal`, never `float`. Datetimes are timezone-aware UTC internally; convert only at display boundaries.
- No mutable default arguments. No I/O at import time.

**Simplicity discipline**
- No premature abstraction: duplicate twice, extract on the third occurrence. A pattern that costs more lines than the problem is a bug.
- Prefer stdlib, then existing dependencies, then a new library only for genuinely hard problems. Every new dependency needs a justification and a licence/maintenance sanity check.
- Early returns over nested conditionals; small pure functions over long procedures; module-level functions over classes with one method.
- Delete dead code, don't comment it out — version control is the archive.

**Security floor**
- Validate and coerce all external input at the boundary (request, file, queue message, env). Trust nothing that crossed a process boundary.
- Never `eval`/`exec`/`pickle.loads` on untrusted input; `subprocess` without `shell=True` and with argument lists.
- Authorization is enforced server-side in the service layer, not assumed from the caller.

## Design patterns — apply Pythonically, not Java-ishly

Patterns are a vocabulary for solving a *pressure that already exists*, not a checklist to apply upfront. In Python, first-class functions, protocols, and modules make many classic patterns collapse into a few lines. The most valuable in enterprise Python: **Repository** and **Unit of Work** (isolate persistence), **Ports & Adapters / Strategy via `Protocol`** (swap implementations, enable testing), **Factory/registry** (choose implementation from config), **Adapter** (tame third-party APIs), **Decorator** (retry, cache, timing, auth), and **Result/typed errors** at boundaries.

Avoid: singletons implemented with metaclass gymnastics (use a module or a DI provider), inheritance more than two levels deep, service locators, and abstractions with exactly one implementation and no test seam. Full catalog with Python-idiomatic implementations and anti-patterns in `references/design-patterns.md`.

## Tooling baseline (when scaffolding, or when the project has none)

`pyproject.toml` with a `src/` layout · Python 3.11+ · `ruff` (lint + format) · `mypy --strict` on new packages, ratcheted per-module on legacy · `pytest` + `pytest-cov` + `pytest-mock` · `pydantic-settings` for config · `structlog` or stdlib logging with a JSON formatter · `uv` or `poetry` for dependency locking · pre-commit hooks · CI gates on lint, types, and tests. Details and legacy-friendly ratcheting strategy in `references/testing-and-quality.md`.

## Definition of done

Existing behavior preserved and demonstrated (tests/verification stated) · public contracts unbroken or deprecation-shimmed · typed and passing lint/type checks · errors and edge cases handled deliberately · no secrets or config in code · matches surrounding conventions · smallest reasonable diff, refactor and behavior changes separated · diff and rollback explained.
