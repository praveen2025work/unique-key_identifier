# Architecture and Project Structure

How to lay out an enterprise Python application so that boundaries are visible, dependencies point one way, and the thing stays changeable at year three.

**Contents**
1. Project layout
2. Layering and the dependency rule
3. Wiring dependencies (composition root)
4. API services (FastAPI shape)
5. Batch jobs and data pipelines
6. Async rules
7. Cross-cutting concerns
8. Packaging, versioning, and shared libraries
9. Applying this to an existing codebase

---

## 1. Project layout

`src/` layout, one installable package, tests outside the package:

```
project/
├── pyproject.toml
├── README.md
├── .env.example
├── src/
│   └── myapp/
│       ├── __init__.py
│       ├── main.py                 # entry point / composition root
│       ├── config.py               # typed Settings
│       ├── logging_setup.py
│       ├── api/                    # HTTP layer: routers, schemas, deps
│       │   ├── routers/
│       │   ├── schemas/            # request/response models (pydantic)
│       │   └── dependencies.py
│       ├── services/               # use cases / orchestration
│       ├── domain/                 # entities, value objects, ports, rules
│       │   ├── models.py
│       │   ├── ports.py
│       │   └── errors.py
│       ├── infrastructure/         # adapters: db, http clients, queues, files
│       │   ├── db/
│       │   ├── clients/
│       │   └── repositories/
│       └── jobs/                   # scheduled/batch entry points
├── tests/
│   ├── unit/
│   ├── integration/
│   └── conftest.py
├── migrations/
└── scripts/
```

Why `src/`: it makes it impossible to accidentally import the package from the working directory instead of the installed one, which is where "works on my machine, fails in CI" comes from.

Organize by **feature/domain** rather than by technical type once the app grows past a handful of modules — `pnl/`, `entitlements/`, `reconciliation/`, each with its own service/domain/infra internals. Type-based folders (`models/`, `services/`, `utils/`) mean every feature change touches every folder.

## 2. Layering and the dependency rule

Four layers, dependencies point **inward only**:

```
api / cli / jobs   (delivery)    → depends on services
services           (use cases)   → depends on domain (ports)
domain             (rules)       → depends on nothing
infrastructure     (adapters)    → depends on domain (implements ports)
```

Concretely:
- **domain** imports no framework, no ORM, no HTTP client, no `pandas`. If it does, the rules can't be tested or reused. Pure Python plus `dataclasses`/`Decimal`/`datetime`.
- **services** orchestrate: load via ports, apply domain rules, persist, emit events. They own transaction boundaries and know nothing about HTTP status codes.
- **api** translates: request → typed command, service result → response, domain error → status code. Thin. No business logic in a router function, ever.
- **infrastructure** implements ports and translates external errors into domain errors.

Enforce it mechanically rather than by discipline — `ruff`'s banned-api / `import-linter` contracts, or a test that asserts `domain` imports nothing from `infrastructure`. A rule nobody checks decays within two sprints.

**Circular imports are a layering violation**, not a puzzle. If `services` and `infrastructure` import each other, the port belongs in `domain` and infra should depend on it.

## 3. Wiring dependencies (composition root)

Construct objects in exactly one place — the entry point — and pass them down. No component reaches out to a global to find its collaborators.

```python
# main.py
def build_container(settings: Settings) -> Container:
    engine = create_engine(settings.database_dsn, pool_pre_ping=True)
    session_factory = sessionmaker(engine)
    price_source = BloombergPriceSource(BlpClient(settings.blp_url), timeout=settings.request_timeout_seconds)
    uow = SqlUnitOfWork(session_factory)
    return Container(
        settlement=SettlementService(uow=uow, prices=price_source),
        reporting=ReportingService(uow=uow),
    )
```

- Constructor injection, plain and explicit. A DI framework (`dependency-injector`, `wired`) is worth it only past real complexity — dozens of components with lifecycles.
- FastAPI's `Depends` is a fine composition mechanism for the API layer; keep the providers in one `dependencies.py` and have them return already-built services rather than constructing infrastructure inline in each route.
- Scope matters: engines and HTTP clients are application-scoped (built once); sessions and unit-of-work are request/job-scoped.
- Tests build the same container with fakes — that's the payoff. If the tests can't, the wiring is wrong.

## 4. API services (FastAPI shape)

```python
# api/routers/trades.py
router = APIRouter(prefix="/trades", tags=["trades"])

@router.post("/{trade_id}/settle", response_model=SettlementResponse, status_code=202)
def settle_trade(
    trade_id: str,
    body: SettleRequest,
    service: SettlementService = Depends(get_settlement_service),
    user: User = Depends(require_permission("trade:settle")),
) -> SettlementResponse:
    settlement = service.settle(trade_id, mode=body.mode, requested_by=user.id)
    return SettlementResponse.from_domain(settlement)
```

- Request/response schemas live in the API layer and are **separate from domain models**. Coupling them means a domain refactor becomes a breaking API change.
- One exception handler layer maps domain errors to status codes centrally (`NotFoundError`→404, `ValidationError`→422, `PermissionError`→403, `UpstreamError`→503) — routers never build error responses by hand.
- Versioned routes (`/api/v1/...`) from day one; adding a version later is far harder than having one.
- Authorization enforced in a dependency or the service, with the check based on the authenticated principal — never on a client-supplied role.
- Startup/shutdown via lifespan: build the container, verify connectivity, register health endpoints (`/health` liveness, `/ready` including dependency checks).
- Long work goes to a queue/worker, not a background task in the request process, if it must survive a restart.

## 5. Batch jobs and data pipelines

- Every job has: a single entry point, typed parameters (run date, book, mode), structured logging with a run id, and an exit code that means something.
- **Idempotent and re-runnable.** A rerun for the same business date must produce the same result, not duplicates. Design the write as upsert-by-key or delete-then-insert-within-a-transaction for the partition being rebuilt.
- **Checkpointing** for long runs so a failure resumes rather than restarts.
- Separate extract / transform / load functions so the transform is unit-testable without any I/O — that is where the business logic lives and where the bugs are.
- Bound memory: stream or chunk. `polars`/`duckdb` lazy frames or generator pipelines over `pandas` full-materialization when volume is real.
- Emit run metadata (rows in/out, duration, rejects) as both logs and a persisted run record — reconciliation and support both need it.
- Config-driven/metadata-driven pipelines: keep the metadata schema versioned and validated (`pydantic`) at load time, and make an invalid config fail before any data is touched.

## 6. Async rules

- Choose sync or async per application, not per module. A codebase that's half-and-half pays the cost of both.
- `async` buys you concurrency on I/O waits. It buys nothing for CPU work, and nothing for a script that makes three sequential calls.
- **Never call blocking code inside an async function** — a blocking DB driver or `requests` call freezes the whole event loop. Use an async driver, or `await asyncio.to_thread(blocking_fn, ...)`.
- Structure concurrency explicitly: `asyncio.TaskGroup` (3.11+) so failures propagate and nothing is orphaned. Bound fan-out with a semaphore.
- Every await on the network has a timeout (`asyncio.timeout`).
- Async generators need explicit cleanup; use `async with` on clients.

## 7. Cross-cutting concerns

Handle these once, in one place, not per module:

| Concern | Where |
|---|---|
| Logging config | entry point only |
| Correlation ids | middleware/decorator + `contextvars` |
| Auth/authorization | API dependency + service-level check |
| Error → response mapping | single exception handler layer |
| Retry/backoff | decorator or client wrapper in infrastructure |
| Metrics/tracing | middleware + instrumented adapters |
| Validation | boundary schemas (API/config/message) |
| Audit trail | service layer, as an explicit domain event |

Audit and entitlement checks belong to the service layer because that is the only layer that knows *both* the actor and the business operation.

## 8. Packaging, versioning, and shared libraries

- One `pyproject.toml`, pinned/locked dependencies (`uv.lock`, `poetry.lock`) committed; separate dependency groups for dev/test.
- Internal shared libraries: semantic versioning, a changelog, and a deprecation policy. Consumers pin a range, not `latest`.
- Don't create a shared "common utils" package early — it becomes a dumping ground with a release cadence that blocks everyone. Extract shared code only after the same need appears in three services.
- Every service ships with a reproducible build (lockfile + pinned base image) — "it worked last week" must be diagnosable.

## 9. Applying this to an existing codebase

You will rarely be given a clean slate. Don't restructure the repo to match this document — that's a giant unreviewable diff with no functional value.

Instead:
1. **Draw the current dependency map** and identify the one violation that hurts most (usually: business logic embedded in route handlers, or SQL scattered through services).
2. **Fix it only where you're already working.** Touching a router? Extract its logic into a service function as a behavior-preserving commit, leave the rest.
3. **Apply the standard to new modules fully**, old modules opportunistically. New code sets the direction; the old code converges as it's touched.
4. **Add the enforcement rule the day the boundary exists**, so it doesn't erode.
5. Track the remaining violations somewhere visible so this is a plan, not a vibe.

See `safe-change-on-existing-code.md` for how to make each of those steps individually safe.
