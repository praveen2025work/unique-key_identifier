# Quality Checklist

Run through this before declaring any Python change done. Skip items that genuinely don't apply; never skip an item because you didn't check it.

## Behavior preservation (existing code)

- [ ] Every path I modified had a test pinning its prior behavior — or I wrote one first.
- [ ] I grepped for all callers of every symbol whose signature, return shape, or exception type changed.
- [ ] Public surface intact: module paths, names, parameter order, return keys, exception types, config keys, log messages used by alerts.
- [ ] Refactoring commits and behavior commits are separate.
- [ ] Behavior-changing paths default to the old behavior, or are gated by a flag/config.
- [ ] Any removal or rename ships with a shim + deprecation warning, and the removal is tracked.
- [ ] Schema changes follow expand–contract; no destructive migration in the same release as its code.
- [ ] I can state how to roll this back.

## Correctness

- [ ] Edge cases covered: empty input, single element, zero, negative, boundary, max size, duplicate, out-of-order.
- [ ] Error paths are deliberate — nothing swallowed, causes chained with `from`, narrow `except` clauses.
- [ ] Money is `Decimal` with explicit rounding; datetimes are timezone-aware UTC; business dates are `date`.
- [ ] No mutation of caller-owned arguments; no mutable default arguments; no mutation while iterating.
- [ ] Retries only on idempotent operations, bounded, with backoff.
- [ ] Concurrency: no blocking calls inside async functions, no shared mutable state without protection.

## Types and style

- [ ] Every public function, method, and field annotated; no new `Any`; no unexplained `# type: ignore`.
- [ ] Domain types modeled (dataclass/pydantic/Enum/Literal), not raw dicts or magic strings.
- [ ] Boundaries depend on `Protocol`/ABC, not concrete infrastructure classes.
- [ ] Functions under ~50 lines, nesting under ~3 levels, keyword-only args where it aids readability.
- [ ] Names state intent; comments explain why; dead code deleted, not commented out.
- [ ] Matches the surrounding codebase's conventions (deviations noted once, not silently introduced).

## Architecture

- [ ] Dependencies point inward: domain imports no framework, ORM, or client library.
- [ ] Business logic is not in a route handler, a job entry point, or a repository.
- [ ] Dependencies are injected, not fetched from globals inside the logic.
- [ ] Transaction boundaries owned by the service layer; repositories don't self-commit.
- [ ] No new abstraction with a single implementation and no test seam.
- [ ] No circular imports; no side effects at import time.

## Operations

- [ ] Config and secrets come from settings/environment — nothing environment-specific in source, no secrets in defaults or logs.
- [ ] Logging at the right level, lazy formatting, correlation id present, no PII or credentials.
- [ ] All network calls have timeouts; clients and pools are reused, not per-call.
- [ ] All files, sessions, connections, and locks are managed by context managers.
- [ ] The change is observable: a metric or log line shows the new path is taken and whether it succeeds.
- [ ] External input validated at the boundary; queries parameterized; no `eval`/`exec`/`pickle` on untrusted data; no `shell=True`.
- [ ] Authorization enforced server-side in the service layer.

## Tests and verification

- [ ] New behavior has tests; the fixed bug has a regression test.
- [ ] Tests assert behavior, not internal call sequences; fakes used at ports rather than mock-heavy setups.
- [ ] Tests are deterministic — no real clock, no network, no fixed filesystem paths, no order dependence.
- [ ] I ran what could be run: `ruff`, `mypy`, unit suite, full suite, import/startup smoke.
- [ ] I stated honestly what I could not verify and why.

## Communication

- [ ] Diff explained: what changed, why, behavior-preserving vs behavior-changing.
- [ ] Contracts affected and consumers who need to know are called out.
- [ ] Trade-offs and deliberate deferrals are named, not hidden.
- [ ] Follow-up work is captured as `# TODO(owner, ticket)` or a backlog item, not left as an unspoken assumption.
