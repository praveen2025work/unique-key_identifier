# Python Code Standards

The conventions that make enterprise Python readable, typed, and operable. When the codebase already has a convention, follow it and note the deviation once.

**Contents**
1. Typing
2. Data modeling
3. Functions and control flow
4. Exceptions and error handling
5. Logging
6. Configuration and secrets
7. Resources, concurrency, and I/O
8. Correctness traps (money, time, mutation, equality)
9. Naming, docstrings, and comments
10. Imports and module hygiene

---

## 1. Typing

Types are the cheapest documentation and the only one that's checked.

```python
from __future__ import annotations  # cheap forward refs, PEP 563 semantics

from collections.abc import Iterable, Mapping, Sequence
from decimal import Decimal
from typing import Literal, Protocol
```

- Annotate every public function, method, and attribute. Local variables only when inference is ambiguous.
- **Accept abstract, return concrete**: parameters typed `Iterable[T]`/`Mapping[K, V]`/`Sequence[T]`; return types `list[T]`/`dict[K, V]`. Widest input, most useful output.
- Use built-in generics (`list[str]`, `dict[str, int]`) and `X | None`, not `List`/`Optional`, on 3.10+.
- `Any` is a defect in new code. If a boundary genuinely returns unknown shape, type it `object` and narrow explicitly, or model it. `cast()` is acceptable at a validated boundary with a comment saying why it's safe.
- Replace stringly-typed parameters with `Literal["flash", "formal"]` or an `Enum`. This turns runtime bugs into type errors.
- Define capability at the boundary with `Protocol` (structural) rather than requiring inheritance:

```python
class PriceSource(Protocol):
    def fetch(self, symbol: str, as_of: date) -> Decimal: ...
```

- `TypeVar`/generics only when a function is genuinely polymorphic over its input type — not for decoration.
- `TYPE_CHECKING` blocks for import-cycle-only imports; keep runtime imports minimal.

## 2. Data modeling

Pick deliberately; don't default to `dict`.

| Use | When |
|---|---|
| `@dataclass(frozen=True, slots=True)` | Internal value objects, domain entities, no validation needed |
| `pydantic.BaseModel` | Anything crossing a boundary: API request/response, config, message payloads, file schemas — you want validation and coercion |
| `TypedDict` | You must keep a dict shape (existing JSON contract) but want type checking |
| `NamedTuple` | Small immutable positional records, tuple-compatible for legacy callers |
| `Enum` / `StrEnum` | Fixed sets of values, statuses, modes |
| plain `dict` | Genuinely dynamic keys only |

Defaults: **immutable unless mutation is required** (`frozen=True`), `slots=True` for memory on high-volume objects, `kw_only=True` for models with more than ~3 fields so call sites stay readable and adding a field is safe.

Keep validation at the edges: parse into a validated model once at the boundary, and let the interior trust it. Don't re-validate the same data in six layers.

## 3. Functions and control flow

- One job per function. Over ~50 lines or more than ~3 levels of nesting → extract.
- **Keyword-only arguments** (`*`) for anything with more than two parameters or any boolean flag. `settle(trade, dry_run=True)` survives refactoring; `settle(trade, True)` does not.
- Boolean parameters that select behavior often want to be two functions instead.
- Guard clauses and early returns over nested conditionals.
- Pure functions where possible: input → output, no hidden state, no I/O. Push I/O to the edges; keep the logic testable in the middle.
- Never mutate a caller's argument unless that is explicitly the documented purpose.
- Generators for large sequences (`yield`, `Iterator[T]`) so pipelines don't materialize a million rows.
- No mutable default arguments — `def f(items: list[str] | None = None)` then `items = items or []`.

## 4. Exceptions and error handling

Define a hierarchy per application/package:

```python
class AppError(Exception):
    """Base for all application errors."""

class ConfigError(AppError): ...
class ValidationError(AppError): ...
class NotFoundError(AppError): ...
class UpstreamError(AppError):
    """A dependency failed; may be retryable."""
    def __init__(self, service: str, *, retryable: bool = False) -> None:
        super().__init__(f"upstream failure: {service}")
        self.service = service
        self.retryable = retryable
```

Rules:
- Catch the narrowest exception you can actually handle. `except Exception` only at a top-level boundary (request handler, job runner, worker loop), where it logs with `exc_info=True` and converts to a defined response.
- **Never swallow.** `except X: pass` is acceptable only with a comment explaining why the failure is genuinely irrelevant.
- Translate third-party exceptions at the boundary that owns them: the repository turns `sqlalchemy.exc.IntegrityError` into `DuplicateRecordError`; the service layer never sees a driver exception. This is what stops your persistence library leaking into every layer.
- Preserve the cause: `raise ValidationError(...) from exc`.
- Distinguish **programmer error** (raise immediately — `ValueError`, `TypeError`, assertions in dev) from **operational error** (timeouts, unavailability — retry, degrade, or surface cleanly).
- Retries only on idempotent operations, with bounded attempts, exponential backoff, and jitter. Retrying a non-idempotent write duplicates it.
- `finally` or context managers for cleanup — never rely on the happy path.

## 5. Logging

```python
import logging

logger = logging.getLogger(__name__)

logger.info("settled trade", extra={"trade_id": trade.id, "book": trade.book})
logger.warning("retrying upstream %s attempt %d", service, attempt)
logger.exception("failed to build report")  # inside except: includes traceback
```

- Module-level `getLogger(__name__)`. Never `print` outside scripts/CLI output.
- **Configure logging only in the application entry point** (`main.py`, ASGI startup, job bootstrap). Libraries and service modules must not call `basicConfig`, add handlers, or set levels — that hijacks the host application.
- Lazy `%s` formatting, not f-strings, so suppressed log levels cost nothing and log aggregation can group by template.
- Levels mean something: `DEBUG` = developer detail; `INFO` = business-significant event; `WARNING` = recovered or degraded; `ERROR` = operation failed, someone should know; `CRITICAL` = the process/system is unusable.
- Include correlation ids (request id, batch id, run id) on every line in a flow — via `contextvars`, a `LoggerAdapter`, or `structlog` binding.
- **Never log** secrets, tokens, passwords, full request bodies with PII, entire config objects, or raw stack traces to the user-facing channel.
- Log lines consumed by dashboards or alerts are a contract — don't reword them casually.

## 6. Configuration and secrets

```python
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="APP_", frozen=True)

    environment: Literal["local", "dev", "uat", "prod"]
    database_dsn: str
    request_timeout_seconds: float = Field(default=10.0, gt=0)
    enable_new_allocator: bool = False
```

- One typed settings object, constructed once at startup, validated at startup. A misconfigured app should fail loudly on boot, not at 2am on the first request that touches the missing key.
- Pass settings (or the specific values) into components explicitly; avoid importing a global `SETTINGS` deep inside domain logic — that's a hidden dependency that breaks tests.
- Secrets come from the platform (env, Vault, secret manager), never from source, never from defaults, never from committed `.env`. Commit a `.env.example` with dummy values.
- Config keys and their meanings are a contract with ops. Renaming one is a breaking change — support the old name for a cycle.

## 7. Resources, concurrency, and I/O

- Context managers everywhere: files, DB sessions, HTTP clients, locks, temp dirs. Write your own with `@contextlib.contextmanager` when a resource needs paired setup/teardown.
- Reuse clients and connection pools; creating an HTTP client or DB engine per call is a common and expensive bug.
- Always set timeouts on network calls. A call without a timeout is an outage waiting for a slow dependency.
- `async` is for I/O concurrency. Never call blocking code in an async function — use `asyncio.to_thread` or a thread pool. Don't sprinkle `async` where there is no concurrency to gain.
- CPU-bound work goes to processes (`ProcessPoolExecutor`), not threads.
- Batch and stream: process large datasets in chunks with bounded memory; don't `fetchall()` a million rows.
- Idempotency keys on anything that writes to an external system and might be retried.

## 8. Correctness traps

- **Money**: `Decimal`, always. Never `float`. Set explicit rounding (`ROUND_HALF_UP` or per business rule) and quantize at the point of persistence/display, not repeatedly mid-calculation.
- **Time**: timezone-aware UTC internally (`datetime.now(tz=UTC)`), convert at display. Never `datetime.utcnow()` (naive). Business dates (trade date, value date) are `date`, not `datetime`. Inject a clock for testability.
- **Mutation**: don't mutate while iterating; copy defensively when storing a caller's mutable object; `copy.deepcopy` sparingly and knowingly.
- **Equality/identity**: `is` only for `None`/singletons. `==` on floats is a bug; use tolerance or `Decimal`.
- **Truthiness**: `if x is None` when `0`, `""`, or `[]` are valid values — `if not x` silently conflates them.
- **Caching**: `functools.lru_cache` on a method holds `self` alive and caches per-instance-identity; on a function with mutable arguments it explodes. Cache pure functions of hashable inputs only.

## 9. Naming, docstrings, and comments

- `snake_case` functions/variables, `PascalCase` classes, `UPPER_SNAKE` constants, `_leading_underscore` for module-private.
- Names describe intent, not type or implementation: `unsettled_trades` not `trade_list`; `fetch_prices` not `get_data`.
- Booleans read as predicates: `is_active`, `has_breaks`, `should_retry`.
- Docstrings on public modules, classes, and non-obvious functions — one-line summary, then Args/Returns/Raises where it isn't self-evident. Don't restate the signature in prose.
- Comments explain **why**, never what. `# tolerance widened per Risk sign-off RSK-4471 for illiquid books` earns its place; `# loop over trades` does not.
- Mark genuine tech debt with `# TODO(owner, ticket): ...` so it's traceable, not anonymous.

## 10. Imports and module hygiene

- Absolute imports inside the application package; relative imports only within a tightly-coupled subpackage.
- Import order: stdlib, third-party, first-party, local — `ruff`/`isort` enforces it, don't hand-sort.
- **No side effects at import time**: no I/O, no network, no config loading, no logging configuration, no expensive computation. Importing a module must be free and safe.
- No wildcard imports. Define `__all__` in packages that re-export.
- Modules stay under ~500 lines; split by responsibility, not alphabetically.
- Circular imports are a design signal, not a puzzle to solve with local imports — the dependency direction is wrong; fix the layering (see `architecture-and-structure.md`).
