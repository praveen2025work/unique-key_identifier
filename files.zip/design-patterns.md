# Design Patterns in Idiomatic Python

Patterns solve pressures that already exist. Applying one before the pressure appears adds indirection, files, and cognitive load with no payoff. The test for every pattern below: *what does this let me change or test that I couldn't before?* If there's no answer, don't use it.

Python's first-class functions, protocols, closures, decorators, and modules collapse many GoF patterns into a few lines. Translating Java/C# structure verbatim into Python produces the classic over-engineered `AbstractFactoryProviderImpl` codebase — resist it.

**Contents**
1. Choosing a pattern (decision guide)
2. Ports & Adapters (Protocol-based dependency inversion)
3. Strategy
4. Factory / Registry
5. Repository
6. Unit of Work
7. Adapter / Anti-corruption layer
8. Decorator (retry, cache, timing, auth)
9. Template Method
10. Observer / event bus
11. Builder and parameter objects
12. Result types at boundaries
13. Patterns Python already gives you
14. Anti-patterns

---

## 1. Choosing a pattern

| Pressure you actually have | Pattern |
|---|---|
| Can't test because the code reaches out to a DB/API/clock | Ports & Adapters + dependency injection |
| Algorithm varies by config, tenant, or product | Strategy (often just a function) |
| "Which implementation?" decided at runtime from a string | Factory / registry |
| Persistence details leaking into business logic | Repository |
| Multi-step writes must commit or roll back together | Unit of Work |
| Third-party API is ugly, unstable, or wrong-shaped | Adapter / anti-corruption layer |
| Same cross-cutting concern wrapped around many functions | Decorator |
| Several flows share a skeleton, differ in a step or two | Template Method (or, better, pass a callable) |
| One event, several unrelated reactions | Observer / event bus |
| Constructor has 8 parameters | Parameter object / builder |
| Expected failures are common and typed handling matters | Result type at the boundary |

If the pressure isn't on the list and isn't real yet — write the straightforward code.

## 2. Ports & Adapters (dependency inversion)

The highest-value pattern in enterprise Python. The domain declares what it needs (`Protocol` = the port); infrastructure supplies it (the adapter). This is what makes code testable without patching.

```python
# domain/ports.py
class TradeRepository(Protocol):
    def get(self, trade_id: str) -> Trade | None: ...
    def save(self, trade: Trade) -> None: ...

class NotificationSender(Protocol):
    def send(self, to: str, subject: str, body: str) -> None: ...

# domain/services.py — depends only on ports, no imports from infra
class SettlementService:
    def __init__(self, trades: TradeRepository, notifier: NotificationSender) -> None:
        self._trades = trades
        self._notifier = notifier

    def settle(self, trade_id: str) -> Settlement: ...

# infrastructure/oracle_trade_repository.py
class OracleTradeRepository:  # structurally satisfies the Protocol, no inheritance needed
    def __init__(self, session: Session) -> None: ...
    def get(self, trade_id: str) -> Trade | None: ...
    def save(self, trade: Trade) -> None: ...
```

Notes:
- `Protocol` over ABC at boundaries — structural typing means the adapter doesn't import the domain to satisfy it, and test fakes are trivial. Use ABC when you want shared implementation or an enforced explicit hierarchy.
- Keep ports small (interface segregation). A 20-method repository port means every fake is 20 methods.
- Ports belong to the *consumer's* layer, not the implementer's. That's the inversion.
- In tests, write a simple in-memory fake rather than a mock with configured call expectations — fakes are readable and don't break on refactor.

## 3. Strategy

Vary an algorithm at runtime. In Python, usually a function or a `Protocol` — rarely a class hierarchy.

```python
# Simplest form: a callable
Allocator = Callable[[Decimal, Sequence[str]], dict[str, Decimal]]

def pro_rata(total: Decimal, books: Sequence[str]) -> dict[str, Decimal]: ...
def equal_split(total: Decimal, books: Sequence[str]) -> dict[str, Decimal]: ...

def allocate(total: Decimal, books: Sequence[str], *, strategy: Allocator = pro_rata) -> dict[str, Decimal]:
    return strategy(total, books)
```

Promote to a class only when the strategy needs configuration state, multiple related methods, or its own lifecycle.

## 4. Factory / Registry

Choose an implementation from config without an ever-growing `if/elif` and without the caller importing every implementation.

```python
_ALLOCATORS: dict[str, type[Allocator]] = {}

def register(name: str) -> Callable[[type[Allocator]], type[Allocator]]:
    def decorator(cls: type[Allocator]) -> type[Allocator]:
        if name in _ALLOCATORS:
            raise ConfigError(f"duplicate allocator: {name}")
        _ALLOCATORS[name] = cls
        return cls
    return decorator

def create_allocator(name: str, **kwargs: object) -> Allocator:
    try:
        cls = _ALLOCATORS[name]
    except KeyError:
        raise ConfigError(f"unknown allocator {name!r}; known: {sorted(_ALLOCATORS)}") from None
    return cls(**kwargs)
```

Caveat: registries depend on the modules being imported to populate themselves. Import them explicitly in a package `__init__` or use entry points — don't rely on accidental import order. And the error message should list the valid options; that one line saves hours.

## 5. Repository

Isolate persistence so domain logic never sees SQL, ORM sessions, or driver exceptions.

```python
class SqlTradeRepository:
    def __init__(self, session: Session) -> None:
        self._session = session

    def get(self, trade_id: str) -> Trade | None:
        row = self._session.get(TradeRow, trade_id)
        return _to_domain(row) if row else None

    def save(self, trade: Trade) -> None:
        try:
            self._session.merge(_to_row(trade))
        except IntegrityError as exc:
            raise DuplicateRecordError(trade.id) from exc
```

- Repository methods speak the domain language (`find_unsettled_for_book`), not the query language (`execute_sql`).
- Return domain objects, not ORM rows — otherwise lazy loading and session lifetime leak everywhere.
- Don't build a generic `Repository[T]` with `filter(**kwargs)` — that's just the ORM with extra steps and no isolation benefit.
- Worth it when: you have real domain logic, multiple storage backends, or you need fast tests. Not worth it for a CRUD app that is honestly just a database with a web interface.

## 6. Unit of Work

Make a multi-step operation atomic and give the service one place to commit.

```python
class SqlUnitOfWork:
    def __init__(self, session_factory: Callable[[], Session]) -> None:
        self._session_factory = session_factory

    def __enter__(self) -> Self:
        self._session = self._session_factory()
        self.trades = SqlTradeRepository(self._session)
        self.breaks = SqlBreakRepository(self._session)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type:
            self._session.rollback()
        else:
            self._session.commit()
        self._session.close()

# usage
with uow:
    trade = uow.trades.get(trade_id)
    uow.breaks.record(detect_breaks(trade))
```

The service layer owns the transaction boundary; repositories never commit on their own. That single rule prevents most partial-write bugs.

## 7. Adapter / anti-corruption layer

Wrap external systems so their model, naming, and failure modes don't infect yours.

```python
class BloombergPriceSource:
    """Adapts the vendor SDK to our PriceSource port."""

    def __init__(self, client: BlpClient, timeout: float = 5.0) -> None: ...

    def fetch(self, symbol: str, as_of: date) -> Decimal:
        try:
            raw = self._client.reference_data(self._to_vendor_ticker(symbol), as_of)
        except BlpTimeout as exc:
            raise UpstreamError("bloomberg", retryable=True) from exc
        return Decimal(str(raw["PX_LAST"]))
```

This is the single most valuable place to spend abstraction budget: vendor APIs change, and when they do you want one file to edit.

## 8. Decorator

Cross-cutting concerns — retry, cache, timing, authorization, audit — without touching the business function.

```python
def retry(attempts: int = 3, backoff: float = 0.5) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @functools.wraps(func)  # preserves name, docstring, signature metadata
        def wrapper(*args, **kwargs):
            for attempt in range(1, attempts + 1):
                try:
                    return func(*args, **kwargs)
                except UpstreamError as exc:
                    if not exc.retryable or attempt == attempts:
                        raise
                    logger.warning("retry %d/%d for %s", attempt, attempts, func.__name__)
                    time.sleep(backoff * 2 ** (attempt - 1))
        return cast(F, wrapper)
    return decorator
```

Rules: always `functools.wraps`; keep decorators thin and side-effect-obvious; don't stack more than two or three (debugging a five-deep stack is miserable); never hide business logic in a decorator — only concerns that are genuinely orthogonal.

## 9. Template Method

A fixed skeleton with varying steps. Use an ABC when the variation is genuinely a family of related implementations; prefer passing callables when it's one or two steps.

```python
class BatchJob(ABC):
    def run(self) -> JobResult:          # the skeleton — do not override
        self._prepare()
        rows = self.extract()
        result = self.transform(rows)
        self.load(result)
        return self._finalize(result)

    @abstractmethod
    def extract(self) -> Iterable[Row]: ...
    @abstractmethod
    def transform(self, rows: Iterable[Row]) -> Frame: ...
    @abstractmethod
    def load(self, frame: Frame) -> None: ...
```

Keep the hierarchy one level deep. Inheritance three levels down is where behavior becomes untraceable.

## 10. Observer / event bus

One thing happens; several unrelated things must react, and the publisher must not know about them.

```python
@dataclass(frozen=True)
class TradeSettled:
    trade_id: str
    settled_at: datetime

Handler = Callable[[object], None]

class EventBus:
    def __init__(self) -> None:
        self._handlers: defaultdict[type, list[Handler]] = defaultdict(list)

    def subscribe(self, event_type: type, handler: Handler) -> None:
        self._handlers[event_type].append(handler)

    def publish(self, event: object) -> None:
        for handler in self._handlers[type(event)]:
            try:
                handler(event)
            except Exception:
                logger.exception("handler failed for %s", type(event).__name__)
```

Use when decoupling genuinely pays (notifications, audit, projections). Be aware of the cost: control flow becomes non-obvious and stack traces stop telling the whole story. In-process buses should not be used to fake a distributed system — if you need durability and retries, use a real queue.

## 11. Builder and parameter objects

For constructors with many parameters, prefer a frozen parameter object over a fluent builder — it's typed, immutable, and testable.

```python
@dataclass(frozen=True, kw_only=True, slots=True)
class ReportRequest:
    book: str
    as_of: date
    mode: Literal["flash", "formal"] = "flash"
    include_greeks: bool = True
    currency: str = "USD"
```

Fluent builders earn their place only when construction is genuinely stepwise and conditional.

## 12. Result types at boundaries

When failure is expected and the caller must handle it explicitly, returning a typed result can beat exceptions:

```python
@dataclass(frozen=True, slots=True)
class Ok[T]:
    value: T

@dataclass(frozen=True, slots=True)
class Err:
    error: AppError

Result = Ok[T] | Err
```

Use sparingly and consistently — mixing exceptions and result types in the same layer produces the worst of both. Validation pipelines that must collect *all* failures are the classic good fit; anything else usually wants exceptions, which are the Python-native mechanism.

## 13. Patterns Python already gives you

Don't hand-roll these:

- **Singleton** → a module (imported once, cached by the interpreter) or a DI provider. Not a metaclass.
- **Iterator** → generators and `__iter__`.
- **Context/RAII** → `with` and `@contextmanager`.
- **Command** → a function or `functools.partial`.
- **Prototype** → `copy.replace` / `dataclasses.replace`.
- **Flyweight** → `functools.lru_cache` on a factory function.
- **Visitor** → `functools.singledispatch` or structural pattern matching (`match`).
- **Proxy/lazy init** → `functools.cached_property`, `__getattr__`.
- **Chain of responsibility** → a list of callables in a loop.

## 14. Anti-patterns

- **Abstraction with one implementation and no test seam.** Delete the interface; add it when the second implementation arrives.
- **Service locator / global registry fetched deep inside logic.** Hidden dependency, untestable, order-dependent. Inject instead.
- **Deep inheritance.** More than two levels, or inheriting to reuse code rather than to express an *is-a* relationship. Prefer composition.
- **God class / god module.** A `utils.py` or `Manager` class that everything imports. Split by responsibility.
- **Anemic domain + fat service** taken to the extreme: every rule in one 2000-line service module. Push invariants into the model.
- **Framework in the domain.** FastAPI `Request`, SQLAlchemy `Session`, or `pandas.DataFrame` types in domain signatures means the domain can never be reused or tested cheaply.
- **Mock-heavy tests.** Tests that assert on `mock.assert_called_with` for internal calls test your implementation, not your behavior, and break on every refactor. Fakes at the port boundary, real objects inside.
- **Config read at import time / module-level singletons of live clients.** Makes import order significant and testing painful.
- **Pattern for the résumé.** If you can't name the change it enables, it's decoration.
