# Safe Change on Existing Code

Read this before editing any module you did not just write. The goal is changing a running system without regressions, in steps that are individually reviewable and individually revertible.

**Contents**
1. Orientation: understand before you touch
2. Characterization tests (the safety net)
3. Finding and creating seams
4. The refactoring catalog (behavior-preserving moves)
5. Adding behavior without breaking callers
6. Strangler fig: replacing a component
7. Deprecation and shims
8. Database and schema changes (expand–contract)
9. Rollout, flags, and rollback
10. The verification ladder

---

## 1. Orientation: understand before you touch

Spend the first minutes mapping, not editing.

- **Entry points**: where does execution start? (`main`, FastAPI routers, Airflow DAGs, CLI commands, cron, consumers.)
- **Callers**: `grep -rn "function_name" --include="*.py"` across the repo. Then consider callers *outside* the repo — other services importing the package, notebooks, DAGs, ops scripts. If you cannot rule those out, treat the symbol as public API.
- **Side effects**: what does this code write to? DB, files, queues, external APIs, caches, logs consumed by alerts. Side effects are the real contract; they're what breaks silently.
- **Shared state**: module-level mutable globals, singletons, class attributes, caches (`lru_cache`), connection pools. These are where "harmless" refactors go wrong.
- **Existing coverage**: `pytest --collect-only`, or run coverage on the target module. Coverage tells you how much you can trust the suite to catch your mistake.

Write down (to the user, briefly) what the module currently guarantees. If you can't state it, you're not ready to change it.

## 2. Characterization tests (the safety net)

A characterization test asserts **what the code does today**, not what it should do. Its purpose is regression detection, so it captures bugs faithfully. Write these when coverage is missing for the paths you're about to touch.

Recipe:

1. Call the function/endpoint with realistic inputs from production-like data.
2. Assert the actual observed output — run it, print it, paste it in. Do not reason about what it *should* return.
3. Cover the paths you intend to modify plus the obvious edge inputs (empty, null, boundary, error).
4. Capture side effects too: rows written, files created, calls made to mocks, exceptions raised, log lines the monitoring depends on.
5. Comment the intent so nobody "fixes" the test later.

```python
def test_characterize_allocate_pnl_rounds_down_on_ties():
    """Characterization: current behavior rounds .5 DOWN (banker's rounding via
    float accumulation). Pinning this before refactor — NOT an endorsement.
    If this must change, change it in a separate, deliberate commit."""
    result = allocate_pnl(total=Decimal("100.005"), books=["A", "B"])
    assert result == {"A": Decimal("50.00"), "B": Decimal("50.00")}
```

For legacy code that's hard to call directly, use approval-style testing: serialize the whole output to a snapshot file, review it once by hand, and assert equality thereafter. Golden-file tests over a set of representative inputs are extremely effective on report generators, transformers, and pipelines.

If the code cannot be called at all without a database or network, that's a seam problem — see next section — and the smallest safe first change is usually introducing the seam, not fixing the logic.

## 3. Finding and creating seams

A *seam* is a place where you can change behavior without editing the code in question. No seam means no test means no safe change. Ways to introduce one, cheapest first:

**Parameterize the dependency (preferred).** Add an optional keyword argument that defaults to today's behavior — fully backward compatible.

```python
# Before: unmockable, hits the real clock and the real client
def build_report():
    now = datetime.utcnow()
    client = SnowflakeClient(SETTINGS.dsn)
    ...

# After: identical behavior for every existing caller, now testable
def build_report(
    *,
    client: WarehouseClient | None = None,
    now: datetime | None = None,
) -> Report:
    client = client or SnowflakeClient(SETTINGS.dsn)
    now = now or datetime.now(tz=UTC)
    ...
```

**Extract a method, then override it in a test subclass.** Useful when the dependency is buried mid-function and the function is huge. Extract the awkward part into `self._fetch_rows()`, subclass in the test, override.

**Extract an interface (`Protocol`) at the boundary.** When more than one thing needs swapping, define the port and pass an implementation. See `design-patterns.md` (Ports & Adapters).

**Patch as a last resort.** `monkeypatch`/`unittest.mock.patch` on the import path works, but couples the test to internal structure and rots. Use it to get an initial characterization test in place, then replace it with a real seam.

## 4. The refactoring catalog (behavior-preserving moves)

Each of these should be a standalone commit with tests green before and after, and **no behavior change whatsoever**.

| Move | When | Watch out for |
|---|---|---|
| Rename (symbol, local) | Name lies about purpose | Rename via search across repo; keep an alias if it's public |
| Extract function | A block has a comment explaining it, or the function exceeds ~50 lines | Don't change the extracted logic while extracting |
| Inline function | Indirection with no value | Only if single caller |
| Introduce parameter object | 5+ parameters, or repeated groups | Keep old signature as a thin wrapper for one release |
| Replace conditional with polymorphism / registry | Long `if/elif` on a type or code | Only when the branches genuinely vary; two branches is not a pattern |
| Guard clauses / early return | Nested `if` more than 2 deep | Verify the negation of each condition carefully |
| Replace magic value with constant/Enum | Repeated literals | Confirm every occurrence means the same thing |
| Extract class / split module | God class, module over ~500 lines | Preserve import paths with re-exports |
| Introduce Protocol at boundary | Untestable dependency | Default to the existing concrete implementation |

Rules for all of them:
- Tests green before you start. If they aren't, fix or quarantine first — never refactor on a red suite.
- One move per commit, message describing the move (`refactor: extract fx_conversion from build_report (no behavior change)`).
- Re-run tests after each move, not at the end.
- Let the tools do it where possible (IDE rename, `ruff` fixes) — mechanical beats manual.

## 5. Adding behavior without breaking callers

**Extend by optional keyword, never by positional change.**

```python
# Safe: every existing call site keeps working unchanged
def settle(trade: Trade, *, dry_run: bool = False, retry_policy: RetryPolicy | None = None) -> Settlement:
```

**Additive return shapes.** Adding a key to a returned dict/model is usually safe; removing or renaming one is not. If the return type is consumed by serialization (API responses, files), a new field can still break strict consumers — check the consumer's schema validation before assuming.

**New behavior defaults to off.** If the change alters outcomes, gate it: config flag, feature toggle, or an explicit parameter. Default = today's behavior. Flip the default in a separate change once verified.

**Widen inputs, narrow outputs.** Accepting more types is backward compatible; returning more types is not.

**Don't change exception types or messages** that callers or alerts might match on without treating it as a breaking change.

## 6. Strangler fig: replacing a component

For anything bigger than a function, don't rewrite in place.

1. **Define the interface** that describes what the old component does (`Protocol` or ABC), and make the old implementation satisfy it — often it already does, or needs a thin adapter.
2. **Route all callers through the interface.** Behavior-preserving commit, tests green.
3. **Build the new implementation** behind the same interface, in a new module. Test it independently against the same characterization suite — the suite is now shared, which is the whole point.
4. **Shadow-run if the stakes are high**: execute both, log/compare outputs, ship nothing. This catches the 5% of cases your tests didn't imagine. Run it for a real cycle (a day, a batch, a month-end) before switching.
5. **Switch by config**, one environment/tenant/percentage at a time.
6. **Remove the old path** in a later, separate commit once the new one has run clean.

Never leave step 6 undone indefinitely — two live implementations is a maintenance tax that compounds.

## 7. Deprecation and shims

When something must be renamed, moved, or removed:

```python
# old_module.py — preserve the import path
import warnings
from new_package.reporting import build_report as _build_report

def build_report(*args, **kwargs):
    warnings.warn(
        "old_module.build_report is deprecated; use new_package.reporting.build_report. "
        "Removal planned for v3.0.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _build_report(*args, **kwargs)
```

- Keep the shim for at least one release/deployment cycle, longer if external teams consume it.
- Log deprecation usage in production so you know when it's actually safe to delete — absence of complaints is not evidence.
- Record the removal in a changelog with a date/version, and put the removal in the backlog immediately.

## 8. Database and schema changes (expand–contract)

Schema changes are the most common source of "the deploy broke prod". Never do a destructive migration in the same release as the code that needs it.

1. **Expand**: add the new column/table as nullable with a default. Deploy. Old code is unaffected.
2. **Migrate**: backfill in batches, idempotently, with a resumable job — not a single unbounded `UPDATE`.
3. **Dual-write**: new code writes both old and new; reads still come from old. Deploy and observe.
4. **Switch reads** to the new column. Deploy and observe.
5. **Contract**: stop writing the old column, then drop it — a separate, later release.

Also: migrations must be forward-only and reversible in effect (have a documented rollback plan even if the down-migration is manual); every migration is tested against a copy of production-shaped data; and long-running DDL on large tables needs a lock-impact assessment before it goes anywhere near production.

## 9. Rollout, flags, and rollback

- Every behavior-changing deployment answers: *how do I turn this off in 60 seconds?* Config flag, env var, or revertible deploy — decide before shipping.
- Feature flags are boolean and short-lived. Read them once at a well-defined point, not scattered. Delete the flag after the rollout completes; stale flags become permanent hidden branches.
- Prefer dark launch → internal users → percentage → full for anything touching money, entitlements, or externally visible output.
- Add the observability *with* the change: a metric or log line that tells you the new path is being taken and whether it's succeeding. Shipping a change you can't observe is shipping blind.

## 10. The verification ladder

Climb as far as the environment allows, and state honestly where you stopped.

1. `ruff check` / `ruff format --check` — style and obvious defects.
2. `mypy` on the touched packages — signature and contract breakage.
3. Unit + characterization tests for the touched modules.
4. Full test suite — catches the caller you forgot.
5. Import smoke test: `python -c "import app.main"` and app startup — catches circular imports and config errors that tests mock away.
6. Contract/integration tests against a real (containerized) dependency.
7. Manual/scripted exercise of the actual workflow with realistic data, diffing output against the pre-change run.

Diffing old vs new output over a representative dataset is the single highest-value check for data and reporting systems — worth building a small script for, and reusable on every subsequent change.

**Never claim verification you didn't perform.** "Tests pass locally; I could not run the integration suite because it needs Oracle" is a useful, honest report. "Done" is not.
