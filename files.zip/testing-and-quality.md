# Testing, Tooling, and Quality Gates

**Contents**
1. What to test, and how much
2. Test structure and naming
3. Fixtures, fakes, and mocks
4. Testing the hard parts (time, randomness, I/O, DB)
5. Parametrization and property-based tests
6. Integration and contract tests
7. Tooling baseline
8. Introducing tooling to a legacy codebase (ratcheting)
9. CI gates
10. Performance and regression checks

---

## 1. What to test, and how much

Optimize for **confidence per second of runtime**, not coverage percentage.

- **Unit tests (the bulk)**: pure domain logic and transforms. No I/O, milliseconds, run on every save.
- **Service tests**: use cases with fake adapters at the ports. This is the sweet spot for enterprise apps — real business flow, no infrastructure.
- **Integration tests (a few)**: real DB (containerized), real migrations, real serialization. Prove the adapters actually work.
- **End-to-end (very few)**: one or two happy paths through the deployed shape.

Always test: business rules, edge cases (empty, boundary, zero, negative, max), error paths, anything with money or dates, anything that has broken before (a bug fix without a regression test invites the bug back).

Don't test: framework behavior, third-party libraries, getters, or your own mocks.

Coverage is a signal, not a target. 100% coverage of trivial code with 0% of the allocation engine is worse than the reverse. Where a number is required, gate on **coverage of changed lines** rather than global percentage — that ratchets up without demanding a mass back-fill.

## 2. Test structure and naming

```python
def test_settle_raises_when_trade_already_settled():
    # Arrange
    trades = InMemoryTradeRepository([make_trade(status="SETTLED")])
    service = SettlementService(trades=trades, prices=FixedPriceSource())

    # Act / Assert
    with pytest.raises(InvalidStateError, match="already settled"):
        service.settle("T1")
```

- Name the behavior, not the method: `test_<action>_<condition>_<expected>`. A failing test name should tell you what broke without opening the file.
- One logical assertion per test. Multiple `assert` lines checking one outcome is fine; testing three behaviors in one function is not.
- Arrange–Act–Assert, visibly separated.
- Tests are independent and order-agnostic — no shared mutable module state, no test that depends on another having run.
- Use builder helpers (`make_trade(**overrides)`) so a test states only the fields it cares about. This is the single biggest factor in whether tests survive a model change.
- Mirror the source tree: `tests/unit/services/test_settlement.py`.

## 3. Fixtures, fakes, and mocks

Preference order: **real object > fake > stub > mock**.

- **Fakes** — working in-memory implementations of a port (`InMemoryTradeRepository`). Readable, reusable, survive refactoring. Default choice.
- **Stubs** — return canned values for a query. Fine.
- **Mocks with call assertions** — only when the *interaction itself* is the behavior under test (e.g. "an audit event is emitted", "the payment is not retried"). Asserting `mock.assert_called_once_with` on internal collaborators tests implementation and breaks on every refactor.
- **`monkeypatch`/`patch`** — last resort, used to get legacy code under test before introducing a real seam. Patch where the name is *used*, not where it's defined.

Fixtures: keep them shallow and explicit. A `conftest.py` with 40 interdependent fixtures makes tests unreadable. Scope expensive fixtures (`session`) and cheap ones per-function.

## 4. Testing the hard parts

- **Time**: inject a clock (`now: Callable[[], datetime]` or a `Clock` port) rather than patching `datetime`. `freezegun`/`time-machine` are acceptable for legacy code you can't change yet.
- **Randomness / ids**: inject the generator, or seed deterministically.
- **Filesystem**: `tmp_path` fixture, never a fixed path.
- **HTTP**: `respx`/`responses` to stub at the transport layer, or a fake adapter at the port. Never hit a real external service in a unit test.
- **Database**: for unit tests, fake the repository. For integration tests, use a real containerized instance (`testcontainers`) — SQLite standing in for Oracle/Postgres will silently accept things production rejects. Roll back per test or recreate the schema per session.
- **Async**: `pytest-asyncio` with `asyncio_mode = "auto"`; test the async function directly, don't wrap in `run_until_complete`.
- **Concurrency**: hard to test reliably; prefer designing it out. Where it matters, assert invariants under load rather than exact interleavings.

## 5. Parametrization and property-based tests

```python
@pytest.mark.parametrize(
    ("total", "books", "expected"),
    [
        (Decimal("100"), ["A", "B"], {"A": Decimal("50"), "B": Decimal("50")}),
        (Decimal("100"), ["A"], {"A": Decimal("100")}),
        (Decimal("0"), ["A", "B"], {"A": Decimal("0"), "B": Decimal("0")}),
    ],
    ids=["even-split", "single-book", "zero-total"],
)
def test_allocate(total, books, expected):
    assert allocate(total, books) == expected
```

Always give `ids` — an unnamed failing case number tells you nothing.

Property-based testing (`hypothesis`) earns its keep on: allocation/rounding logic (the parts must sum to the whole), parsers and serializers (round-trip identity), and anything with invariants over a wide input space. One property test can replace thirty examples and finds the case you didn't think of.

## 6. Integration and contract tests

- Test the adapter against the real technology: real SQL dialect, real migrations applied from scratch, real driver types, real timezone handling.
- **Run the same behavioral test suite against both the fake and the real adapter** where feasible. That's the only thing that guarantees your fake doesn't lie.
- Consumer-driven contract tests when another team depends on your API — a schema snapshot test on your OpenAPI document catches accidental breaking changes cheaply.
- Mark them (`@pytest.mark.integration`) so the fast suite stays fast: `pytest -m "not integration"` locally, everything in CI.

## 7. Tooling baseline

`pyproject.toml`:

```toml
[tool.ruff]
target-version = "py311"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "N", "UP", "B", "A", "C4", "SIM", "RET", "ARG", "PTH", "RUF", "S", "DTZ", "LOG", "TRY"]
ignore = ["E501"]  # formatter handles line length

[tool.mypy]
python_version = "3.11"
strict = true
warn_unreachable = true
plugins = ["pydantic.mypy"]

[tool.pytest.ini_options]
addopts = "-q --strict-markers --strict-config"
markers = ["integration: requires external services", "slow"]

[tool.coverage.report]
exclude_also = ["if TYPE_CHECKING:", "raise NotImplementedError"]
```

- `ruff` for lint + format (replaces flake8/isort/black/pyupgrade — one tool, one config, fast).
- `mypy --strict` (or `pyright`) as the second reviewer that never gets tired.
- `pytest` + `pytest-cov` + `pytest-mock` + `pytest-asyncio`; `hypothesis` where properties exist; `testcontainers` for integration.
- `bandit`/ruff `S` rules for security lint; `pip-audit` for known CVEs in dependencies.
- `pre-commit` running ruff, mypy on changed files, and a secrets scanner (`detect-secrets`/`gitleaks`).
- `uv` or `poetry` with a committed lockfile.

Notable ruff rule groups worth keeping on in finance/enterprise code: `S` (security), `DTZ` (naive datetimes), `TRY` (exception anti-patterns), `B` (bugbear), `PTH` (pathlib), `ARG` (unused arguments — catches dead parameters after refactors).

## 8. Introducing tooling to a legacy codebase (ratcheting)

Never turn everything on at once and land a 40,000-line diff. Ratchet:

1. **Format first, in one isolated commit** that touches nothing else. Add its hash to `.git-blame-ignore-revs` so history stays useful.
2. **Lint with a narrow rule set** (`E`, `F`, `I`) globally; add rule groups one at a time, fixing as you go.
3. **Types module by module.** Global `ignore_errors` with per-module overrides that flip to strict as modules are cleaned:

```toml
[[tool.mypy.overrides]]
module = ["legacy.*"]
ignore_errors = true

[[tool.mypy.overrides]]
module = ["myapp.domain.*", "myapp.services.*"]
strict = true
```

4. **New code is strict from day one.** CI checks changed files at full strictness even while the baseline is relaxed — that's what makes the ratchet only turn one way.
5. Track the shrinking exclusion list; when it's empty, delete the overrides.

The point is that quality improves monotonically without a big-bang change that risks the running system. See `safe-change-on-existing-code.md` for the same principle applied to behavior.

## 9. CI gates

Blocking on every PR: lint · format check · type check · unit tests · changed-line coverage threshold · dependency vulnerability scan · secrets scan. Non-blocking but reported: full coverage, integration suite on merge to main, build/import smoke.

Rules that keep the gate meaningful: the pipeline must be fast enough that people run it (target under ~10 minutes for the blocking set), flaky tests get fixed or quarantined the same week (a tolerated flake trains everyone to ignore red), and no `--no-verify` culture — if a hook is wrong, fix the hook.

## 10. Performance and regression checks

- Measure before optimizing: `cProfile`/`py-spy` for CPU, `tracemalloc` for memory. Optimizing the wrong 5% is the default outcome of guessing.
- Guard the hot path with a benchmark test (`pytest-benchmark`) only where performance is a stated requirement — otherwise it becomes a flaky test on a noisy CI box.
- For data pipelines, assert on bounded resource use (rows streamed, peak memory) and on runtime against a realistic volume, not on wall-clock in CI.
- Regression protection for reporting/transform systems: keep a golden dataset and diff the output on every change. This is the highest-value test type for finance data systems and pays for itself the first time it fires.
