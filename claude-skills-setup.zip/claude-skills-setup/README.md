# Claude Code Skills — Ready to Copy

Two skills, already unzipped in their final folder structure. Just copy each folder to its destination.

## What goes where

| Folder in this zip | Copy the skill folder INTO | Why |
|---|---|---|
| `personal-skills/react-enterprise-dev/` | `~/.claude/skills/` | Generic React standards — applies to ALL your projects |
| `project-skills/wms-react-development/` | `<your-wms-repo>/.claude/skills/` | WMS-specific — lives with the repo, teammates get it via git |

## Commands (Mac / Linux)

```bash
# Personal skill (works everywhere)
mkdir -p ~/.claude/skills
cp -r personal-skills/react-enterprise-dev ~/.claude/skills/

# Project skill (run from inside this zip's folder; adjust the repo path)
mkdir -p /path/to/your/wms-repo/.claude/skills
cp -r project-skills/wms-react-development /path/to/your/wms-repo/.claude/skills/
```

## Commands (Windows PowerShell)

```powershell
# Personal skill
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Copy-Item -Recurse personal-skills\react-enterprise-dev "$HOME\.claude\skills\"

# Project skill (adjust the repo path)
New-Item -ItemType Directory -Force "C:\path\to\wms-repo\.claude\skills" | Out-Null
Copy-Item -Recurse project-skills\wms-react-development "C:\path\to\wms-repo\.claude\skills\"
```

## After copying

1. If `.claude/skills/` did not exist in the repo before, restart Claude Code once (new top-level skill directories need a restart; edits after that are picked up live).
2. Verify: start Claude Code and ask "what skills do you have available?" — both should be listed. They also appear as `/react-enterprise-dev` and `/wms-react-development` slash commands.
3. Optional: commit the project skill so your team gets it:
   ```bash
   git add .claude/skills && git commit -m "Add WMS React development skill"
   ```

## Final layout after copying

```
~/.claude/skills/
└── react-enterprise-dev/
    ├── SKILL.md
    └── references/ (4 files)

<wms-repo>/.claude/skills/
└── wms-react-development/
    ├── SKILL.md
    └── references/ (4 files)
```
