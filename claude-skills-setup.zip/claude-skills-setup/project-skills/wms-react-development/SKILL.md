---
name: wms-react-development
description: Development standards and domain knowledge for the enterprise Workflow Management System (WMS) React application used for financial services PnL operations. Use this skill whenever working on the WMS frontend — building or modifying React components, dashboards, stage/substage views, role panels, file upload/download UI, refactoring existing dashboard code, fixing bugs, adding TypeScript types, integrating REST APIs or WebSockets, or reviewing WMS code. Trigger for any mention of workflow dashboard, stages, substages, producer/approver roles, business date, attestation, process status, or PnL workflow UI — even if the user just says "add a feature" or "fix this component" in the context of this application.
---

# WMS React Development

Standards for developing the Workflow Management System React frontend. This is an **existing enterprise application** for financial services daily PnL operations — reliability, auditability, and consistency matter more than novelty. Keep designs simple, clean, and efficient. Prefer refactoring toward these standards over rewrites.

## How to use this skill

1. Read this file for core principles and non-negotiables.
2. Before writing components → read `references/component-patterns.md`
3. Before data fetching, status logic, or state work → read `references/state-and-data.md`
4. Before typing anything domain-related → read `references/domain-types.md`
5. Before finishing any task → run through `references/code-review-checklist.md`

## Domain model (memorize this)

Hierarchy: **Application → App Group → Stage → Substage**. Configuration templates (`WORKFLOW_APP_CONFIG`) are copied into process instances (`WORKFLOW_PROCESS`) per **business date** when triggered; process data is then locked for that date. Everything on the dashboard is scoped to a business date.

- Stages for Daily PnL: Pre WF → Substantiation → Review → Publish → Sign Off (plus Rainy Day, Exception).
- Substages have a **sequence** and **dependencies**; dependencies can only point to earlier-sequenced substages (backend rule — the UI must render dependency status, never allow forward deps in config screens).
- Substage flags: `auto`, `adhoc`, `attest`, `upload`, `approval`, `alteryx`, `active`.
- Roles: **producer** and **approver**, declared per business date, rolled over daily. A user who acted as producer cannot switch to approver that day (and vice versa). Render role-gated actions accordingly.
- Param precedence (lowest → highest): app params → global params (per app group) → substage params.

## Status model — the single most important rule

Statuses are a **finite state machine**, not free-form strings. Never compare raw strings inline (`status === "completed"` scattered around). All status logic lives in one module (`src/domain/status.ts`) — see `references/state-and-data.md` for the full implementation.

Canonical statuses: `NOT_STARTED`, `READY`, `IN_PROGRESS`, `POST_MANUAL`, `COMPLETED`, `FAILED`, `REJECTED`.

Valid flows by substage type:
- **auto**: NOT_STARTED → READY → IN_PROGRESS → COMPLETED | FAILED
- **post-manual**: NOT_STARTED → IN_PROGRESS → POST_MANUAL → COMPLETED | FAILED
- **manual**: NOT_STARTED → IN_PROGRESS → COMPLETED
- **approval/attest**: NOT_STARTED → IN_PROGRESS → COMPLETED | REJECTED

External systems may send repeated IN_PROGRESS / POST_MANUAL updates with extra info for long transactions — treat these as info updates, not transitions.

## Non-negotiables

These come from real defects found in this codebase. Do not reintroduce them.

1. **No JSX inside useEffect, event handlers, or any non-render logic.** JSX belongs only in render return paths (component body / render functions). Handlers set state; the render reads state. This bug shipped once — treat any JSX inside an effect as a build-breaking error.
2. **TypeScript everywhere.** No implicit `any`. All props get an interface. All API responses get typed DTOs (see `references/domain-types.md`). The `.tsx` files currently contain untyped JS-style code — when touching a file, add types to what you touch.
3. **Normalize backend flag types at the API boundary.** The Oracle schema mixes `NUMBER(1)` (0/1) and `VARCHAR2(1)` ('Y'/'N') booleans. Convert to real `boolean` in one mapping layer; components never see `'Y'`, `'N'`, `0`, or `1`.
4. **Guard division and empty collections.** Progress bars computing `completed / substages.length` must handle `length === 0` (existing dashboard divides by zero for empty stages).
5. **Audit fields are first-class.** Every mutating action surface shows `updatedBy/updatedOn`, `lockedBy/lockedOn`, `completedBy/completedOn`, `attestedBy/attestedOn` where applicable. Never drop them from DTOs.
6. **Respect locking.** If a process/workflow is locked, disable mutating actions and show who locked it and when. Locked state comes from the server; never infer it client-side.
7. **Business date is explicit.** Every process-data fetch includes the business date. Never default silently to "today" without showing the selected date in the UI. Format dates with a shared util; never `toISOString().split('T')[0]` on local dates (timezone bug).

## Design language

Simple, clean, dense-but-readable — this is an operations dashboard, not a marketing site.

- Tailwind utility classes; the existing palette: gray neutrals, `green` = completed, `blue` = in progress/approver, `red` = failed, `amber` = warning/force actions, gray = not started. Add `purple` for POST_MANUAL and keep `red` variants distinct for FAILED vs REJECTED.
- Status colors come from one function (`statusStyle(status)`), never inline ternary chains repeated per component.
- Icons: lucide-react, `w-4 h-4` default, `w-3 h-3` in dense rows.
- No new UI libraries without explicit request. shadcn/ui Card/Alert already in use.
- Accessibility: every icon-only button gets `title` and `aria-label`; interactive divs become `<button>`; modals trap focus and close on Escape.

## Working on the existing codebase

- **Small, surgical diffs.** Change what the task requires; opportunistically fix non-negotiable violations only in code you're already touching, and mention them.
- **Extract, don't duplicate.** The dashboard files contain two near-identical substage renderers — when modifying substage UI, extract a shared `SubstageRow` component instead of editing both copies.
- **Component budget**: a component over ~150 lines or with more than ~7 state variables should be split (container/presentational or extracted hooks). The current `WorkflowDashboard` monolith is the anti-pattern; move toward the structure in `references/component-patterns.md`.
- **No mock data in components.** Mock data lives in `src/mocks/`; components consume hooks that can be pointed at mocks or real APIs.

## Definition of done

A task is complete when: it compiles with strict TypeScript, passes the checklist in `references/code-review-checklist.md`, handles loading/error/empty states, preserves audit and locking behavior, and the diff is explained (what changed, why, any standards violations fixed in passing).
