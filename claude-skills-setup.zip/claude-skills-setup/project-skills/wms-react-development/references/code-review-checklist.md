# Pre-Completion Checklist

Run through this before declaring any WMS frontend task done. Items marked ⛔ are the historical defects — check them every time.

## Correctness
- ⛔ No JSX inside useEffect, event handlers, or any non-render code path
- ⛔ No division by zero: any `x / arr.length` guards `length === 0`
- ⛔ No raw `'Y'/'N'/0/1` reaching components — booleans normalized in `api/mappers.ts`
- Status logic uses `ProcessStatus` enum + `status.ts` helpers; zero inline status-string literals in JSX
- Invalid transitions impossible from the UI (buttons for disallowed transitions don't render or are disabled with reason)
- Dates: local business-date formatting via `utils/dates.ts` (no `toISOString().split('T')[0]`); null timestamps render '—'

## TypeScript
- Strict mode passes; no `any`, no `@ts-ignore` without a comment explaining why
- All component props have interfaces; all API responses have DTO + domain types
- New backend fields flow DTO → mapper → domain type in the same diff

## Enterprise behavior
- Loading, error, and empty states all handled for every data-driven component
- Audit info (updatedBy/On, lockedBy/On, completedBy/On) displayed wherever the data supports it
- Locked workflows/steps disable mutating actions and show who/when
- Actions gated by declared daily role (producer/approver rules respected)
- Business date visible and included in every process-data request
- Mutations invalidate the right query keys; no optimistic status updates on control steps

## Structure & quality
- No duplicated renderers — shared components extracted (SubstageRow, StatusBadge, SlidePanel...)
- Components under ~150 lines / ~7 state vars, else split
- List keys are domain IDs; memoization on dense-list rows with stable callbacks
- No mock data inside components
- Icon-only buttons have `title` + `aria-label`; clickable divs are `<button>`; panels close on Escape

## Communication
- Diff summary states: what changed, why, any standards violations fixed in passing, anything intentionally left for follow-up
