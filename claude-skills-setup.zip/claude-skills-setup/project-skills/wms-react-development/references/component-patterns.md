# Component Patterns

## Target folder structure

Migrate incrementally toward this — don't reorganize wholesale unless asked.

```
src/
├── domain/            # Pure TS: types, status machine, param resolution. No React.
│   ├── types.ts
│   ├── status.ts
│   └── params.ts
├── api/               # Fetch layer: typed clients + DTO→domain mappers
│   ├── client.ts
│   ├── mappers.ts     # Y/N + 0/1 → boolean lives HERE and only here
│   └── endpoints/
├── hooks/             # useWorkflow, useProcessPolling, useRoleSelection...
├── components/
│   ├── ui/            # Dumb primitives: StatusBadge, ProgressBar, FileChip, AuditLine
│   ├── workflow/      # StageTabs, StageCard, SubstageRow, SubstageDetails, DependencyList
│   ├── panels/        # ActivityPanel, RolesPanel (one generic SlidePanel base)
│   └── navigation/    # Breadcrumbs, HierarchyBrowser
├── pages/             # Route-level containers: DashboardPage, AuditPage, ConfigPage
├── mocks/
└── utils/             # dates.ts, format.ts
```

## Container / presentational split

Pages and containers own data (hooks, queries) and pass typed props down. Presentational components are pure: props in, JSX out, no fetching, no global state.

```tsx
// Container
const StageSection: React.FC<{ stageId: number; businessDate: string }> = ({ stageId, businessDate }) => {
  const { data, isLoading, error } = useStageProcesses(stageId, businessDate);
  if (isLoading) return <StageSkeleton />;
  if (error) return <ErrorState message="Unable to load stage" onRetry={...} />;
  if (!data?.substages.length) return <EmptyState label="No substages configured" />;
  return <StageCard stage={data} />;
};
```

Every data-driven component handles **loading, error, and empty** — all three, always.

## The shared SubstageRow

The two dashboard files duplicate the substage renderer. Consolidate to one component with clear prop boundaries:

```tsx
interface SubstageRowProps {
  substage: SubstageProcess;
  expanded: boolean;
  onToggle: (id: number) => void;
  onAction: (id: number, action: SubstageAction) => void; // 'trigger' | 'forceStart' | 'rerun'
  userRole: DailyRole | null;   // gates which actions render
  readOnly: boolean;            // locked workflow or viewer role
}
```

Action buttons render only when: substage is not `auto`, workflow/step is not locked, and the user's declared role permits the action. Disabled-with-tooltip beats hidden when the user *could* act under a different condition (e.g., "Locked by John Doe at 06:30").

## Rules that prevent past bugs

**JSX only in render paths.** This exact defect existed: a JSX block pasted inside a `useEffect` click-outside handler. Effects and handlers contain statements only. If a handler needs to show something, it sets state; the render reads it.

```tsx
// ✅
useEffect(() => {
  const onDown = (e: MouseEvent) => {
    if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
      setShowPanel(false);
    }
  };
  document.addEventListener('mousedown', onDown);
  return () => document.removeEventListener('mousedown', onDown);
}, []);
```

**Stable keys.** Use domain IDs (`substage.processId`), never array index, for lists that reorder, filter, or mutate. Index keys are acceptable only for static, never-reordered display lists (message lines).

**Derive, don't duplicate state.** Completion %, filtered lists, and counts are computed from source data with `useMemo` — never stored in separate `useState` that can drift.

```tsx
const completion = useMemo(() => {
  if (!substages.length) return 0;                       // guard div-by-zero
  const done = substages.filter(s => s.status === Status.COMPLETED).length;
  return Math.round((done / substages.length) * 100);
}, [substages]);
```

**One SlidePanel, many contents.** ActivityPanel and RolesPanel share a generic `SlidePanel` (positioning, click-outside, Escape, focus trap, close button) with children for content. Don't build panel chrome twice.

**Modals/panels**: `role="dialog"`, `aria-modal`, close on Escape, focus first interactive element on open, return focus on close.

## Performance for dense lists

Workflows can have 20+ substages per stage, ~300 instances per application:

- Wrap `SubstageRow` in `React.memo`; keep `onToggle`/`onAction` referentially stable with `useCallback` in the container.
- Expanded-state maps (`Record<number, boolean>`) update immutably: `setExpanded(prev => ({...prev, [id]: !prev[id]}))`.
- Debounce search inputs (250–300ms) before filtering large lists.
- Virtualize only if a single scroll container exceeds ~200 rows (react-window); don't add it preemptively.

## Formatting utilities (shared, in utils/)

```ts
// dates.ts — never inline date formatting in components
export const toBusinessDateString = (d: Date): string => format(d, 'yyyy-MM-dd'); // local, not toISOString
export const formatTimestamp = (iso: string | null): string => iso ? format(parseISO(iso), 'dd MMM yyyy HH:mm') : '—';
```

`new Date(value).toLocaleString()` scattered in JSX is a violation — route through `formatTimestamp` so nulls render as '—' instead of "Invalid Date".
