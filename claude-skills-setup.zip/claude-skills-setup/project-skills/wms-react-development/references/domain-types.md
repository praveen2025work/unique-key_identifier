# Domain Types (src/domain/types.ts)

Canonical TypeScript model. All components and hooks type against these — never against raw DTO shapes. DTO interfaces (mirroring Oracle column names) live in `src/api/dtos.ts` and stop at the mapper.

```ts
import { ProcessStatus, SubstageKind } from './status';

// ---------- Identity & session ----------
export type BusinessDate = string; // 'yyyy-MM-dd', always explicit

export type DailyRole = 'producer' | 'approver' | 'viewer';

export interface UserSession {
  username: string;
  declaredRole: DailyRole | null;      // per business date; null until declared
  roleLockedByAction: boolean;         // acted as producer/approver already today
  entitledApps: number[];
}

// ---------- Configuration hierarchy ----------
export interface WorkflowApplication {
  appId: number;
  name: string;
  category: string | null;
  description: string | null;
  isActive: boolean;
  isLockingEnabled: boolean;
  cronExpression: string;
  runDateOffset: number;
  runOnWeekdaysOnly: boolean;
  usesRunCalendar: boolean;
}

export interface AppGroup {
  appGroupId: number;
  groupName: string;
  description: string | null;
  isActive: boolean;
}

export interface Stage {
  stageId: number;
  appId: number;
  name: string;
  description: string | null;
}

export interface SubstageConfig {
  substageId: number;
  name: string;
  componentName: string | null;
  serviceLine: string | null;
  defaultStageId: number;
  expectedDurationMinutes: number | null;
  expectedTime: string | null;         // 'HH:mm'
  sendEmailAtStart: boolean;
  followUp: boolean;
  templateId: number | null;
}

// ---------- Runtime (per business date) ----------
export interface AuditInfo {
  updatedBy: string | null;
  updatedOn: string | null;            // ISO timestamp
  completedBy: string | null;
  completedOn: string | null;
  attestedBy: string | null;
  attestedOn: string | null;
}

export interface LockInfo {
  locked: boolean;
  lockedBy: string | null;
  lockedOn: string | null;
}

export interface DependencyStatus {
  substageId: number;
  name: string;
  status: ProcessStatus;
}

export type FileDirection = 'upload' | 'download' | 'preview';

export interface ProcessFile {
  name: string;
  paramType: string;
  direction: FileDirection;
  required: boolean;
  status: ProcessStatus;
  sizeLabel?: string;
  description: string | null;
}

export interface ProcessMessage {
  type: 'info' | 'detail' | 'error';
  text: string;
  receivedOn?: string;
}

export interface SubstageProcess extends AuditInfo, LockInfo {
  processId: number;
  configId: number;
  businessDate: BusinessDate;
  appGroupId: number;
  appId: number;
  stageId: number;
  substageId: number;
  name: string;
  sequence: number;
  kind: SubstageKind;
  status: ProcessStatus;
  auto: boolean;
  attest: boolean;
  upload: boolean;
  approval: boolean;
  adhoc: boolean;
  alteryx: boolean;
  isForceStart: boolean;
  isRerun: boolean;
  durationSeconds: number | null;
  message: string | null;
  dependencies: DependencyStatus[];
  files: ProcessFile[];
  messages: ProcessMessage[];
  params: Record<string, string>;      // resolved: app → global → substage
}

export interface StageProcessView {
  stage: Stage;
  substages: SubstageProcess[];        // ordered by sequence
}

export interface WorkflowInstanceView {
  appGroupId: number;
  businessDate: BusinessDate;
  stages: StageProcessView[];
  lock: LockInfo;                      // instance-level lock
}

// ---------- Params ----------
export type ParamScope = 'application' | 'global' | 'substage';

export interface ResolvedParam {
  name: string;
  value: string;
  scope: ParamScope;                   // where the winning value came from
  editable: boolean;
}

// ---------- Activity & roles ----------
export interface ActivityEntry {
  user: string;
  role: DailyRole | 'system';
  action: string;
  substageName: string | null;
  status: ProcessStatus | null;
  timestamp: string;
}

export interface RoleAssignment {
  name: string;
  role: DailyRole;
  lastActivity: string | null;
  timestamp: string | null;
}

// ---------- Actions ----------
export type SubstageAction = 'trigger' | 'forceStart' | 'rerun' | 'complete' | 'approve' | 'reject' | 'attest';

// ---------- API envelope ----------
export interface ApiError {
  status: number;
  code: string;
  message: string;
}
```

## Typing conventions

- `strict: true` in tsconfig; no `any` — use `unknown` + narrowing at boundaries.
- Nullable server fields are `X | null`, never optional-`undefined`, so absence is deliberate and rendered as '—'.
- Union string literals (`DailyRole`, `SubstageAction`) over enums for UI-facing unions; the `ProcessStatus` enum is the exception because it backs the state machine.
- Derive narrow prop types from domain types (`Pick<SubstageProcess, ...>`) rather than redeclaring shapes.
- When the backend adds a field, extend the DTO + mapper + domain type in the same change — a field that skips the mapper is a bug.
