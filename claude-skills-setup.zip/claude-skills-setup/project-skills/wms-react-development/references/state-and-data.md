# State, Data Fetching, and the Status Machine

## The status state machine (src/domain/status.ts)

Single source of truth for all status logic. Components import from here; no raw string comparisons in JSX.

```ts
export enum ProcessStatus {
  NOT_STARTED = 'NOT_STARTED',
  READY = 'READY',
  IN_PROGRESS = 'IN_PROGRESS',
  POST_MANUAL = 'POST_MANUAL',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  REJECTED = 'REJECTED',
}

export type SubstageKind = 'auto' | 'manual' | 'postManual' | 'approval';

const TRANSITIONS: Record<SubstageKind, Partial<Record<ProcessStatus, ProcessStatus[]>>> = {
  auto: {
    [ProcessStatus.NOT_STARTED]: [ProcessStatus.READY],
    [ProcessStatus.READY]: [ProcessStatus.IN_PROGRESS],
    [ProcessStatus.IN_PROGRESS]: [ProcessStatus.IN_PROGRESS, ProcessStatus.COMPLETED, ProcessStatus.FAILED],
    [ProcessStatus.FAILED]: [ProcessStatus.READY], // rerun by RTB
  },
  postManual: {
    [ProcessStatus.NOT_STARTED]: [ProcessStatus.IN_PROGRESS],
    [ProcessStatus.IN_PROGRESS]: [ProcessStatus.IN_PROGRESS, ProcessStatus.POST_MANUAL],
    [ProcessStatus.POST_MANUAL]: [ProcessStatus.POST_MANUAL, ProcessStatus.COMPLETED, ProcessStatus.FAILED],
    [ProcessStatus.FAILED]: [ProcessStatus.IN_PROGRESS],
  },
  manual: {
    [ProcessStatus.NOT_STARTED]: [ProcessStatus.IN_PROGRESS],
    [ProcessStatus.IN_PROGRESS]: [ProcessStatus.COMPLETED],
  },
  approval: {
    [ProcessStatus.NOT_STARTED]: [ProcessStatus.IN_PROGRESS],
    [ProcessStatus.IN_PROGRESS]: [ProcessStatus.COMPLETED, ProcessStatus.REJECTED],
    [ProcessStatus.REJECTED]: [ProcessStatus.IN_PROGRESS], // resubmission after toll gate reopen
  },
};

export const canTransition = (kind: SubstageKind, from: ProcessStatus, to: ProcessStatus): boolean =>
  TRANSITIONS[kind][from]?.includes(to) ?? false;

export const isTerminal = (s: ProcessStatus) =>
  s === ProcessStatus.COMPLETED || s === ProcessStatus.FAILED || s === ProcessStatus.REJECTED;

export const isActionable = (s: ProcessStatus) => !isTerminal(s) || s === ProcessStatus.FAILED; // FAILED allows rerun
```

Repeated `IN_PROGRESS`/`POST_MANUAL` messages from long-running external systems are self-transitions carrying new `message` info — append to the message log, don't error.

One style function, used everywhere:

```ts
export const statusStyle = (s: ProcessStatus): { badge: string; border: string; label: string } => ({
  [ProcessStatus.NOT_STARTED]: { badge: 'bg-gray-100 text-gray-700',   border: 'border-gray-300',  label: 'Not Started' },
  [ProcessStatus.READY]:       { badge: 'bg-cyan-100 text-cyan-700',   border: 'border-cyan-400',  label: 'Ready' },
  [ProcessStatus.IN_PROGRESS]: { badge: 'bg-blue-100 text-blue-700',   border: 'border-blue-500',  label: 'In Progress' },
  [ProcessStatus.POST_MANUAL]: { badge: 'bg-purple-100 text-purple-700', border: 'border-purple-500', label: 'Post Manual' },
  [ProcessStatus.COMPLETED]:   { badge: 'bg-green-100 text-green-700', border: 'border-green-500', label: 'Completed' },
  [ProcessStatus.FAILED]:      { badge: 'bg-red-100 text-red-700',     border: 'border-red-500',   label: 'Failed' },
  [ProcessStatus.REJECTED]:    { badge: 'bg-rose-100 text-rose-800',   border: 'border-rose-500',  label: 'Rejected' },
}[s]);
```

## API boundary and DTO mapping (src/api/mappers.ts)

The Oracle schema is inconsistent: booleans arrive as `'Y'/'N'`, `0/1`, `'0'/'1'`, or null. Normalize once:

```ts
export const toBool = (v: unknown): boolean => v === 'Y' || v === 1 || v === '1' || v === true;

export const mapProcess = (dto: WorkflowProcessDto): SubstageProcess => ({
  processId: dto.WORKFLOW_PROCESS_ID,
  status: mapStatus(dto.STATUS),           // string → ProcessStatus enum, throws/logs on unknown
  businessDate: dto.BUSINESSDATE,
  auto: toBool(dto.AUTO),
  attest: toBool(dto.ATTEST),
  upload: toBool(dto.UPLOAD),
  adhoc: toBool(dto.ADHOC),
  locked: toBool(dto.ISLOCKED),
  lockedBy: dto.LOCKEDBY ?? null,
  lockedOn: dto.LOCKEDON ?? null,
  updatedBy: dto.UPDATEDBY ?? null,
  updatedOn: dto.UPDATEDON ?? null,
  // ...
});
```

`mapStatus` must handle unknown server strings explicitly (log + map to a visible `UNKNOWN` render, never silently coerce). This is a financial audit system — surfacing bad data beats hiding it.

## Data fetching: React Query

All server state goes through React Query (`@tanstack/react-query`). No `useEffect` + `fetch` + `useState` triads.

Query key convention — always include business date for process data:

```ts
export const queryKeys = {
  workflow: (appGroupId: number, businessDate: string) => ['workflow', appGroupId, businessDate] as const,
  stage: (appGroupId: number, stageId: number, businessDate: string) => ['stage', appGroupId, stageId, businessDate] as const,
  activity: (appGroupId: number, businessDate: string) => ['activity', appGroupId, businessDate] as const,
  roles: (appId: number, businessDate: string) => ['roles', appId, businessDate] as const,
};
```

Polling / refresh timer: implement the dashboard's countdown with `refetchInterval` — don't hand-roll `setInterval` fetch loops:

```ts
const { data, dataUpdatedAt } = useQuery({
  queryKey: queryKeys.workflow(appGroupId, businessDate),
  queryFn: () => fetchWorkflow(appGroupId, businessDate),
  refetchInterval: refreshSeconds * 1000,
  refetchIntervalInBackground: false,
});
```

The visible countdown derives from `dataUpdatedAt`, keeping timer and data in sync.

Mutations invalidate the affected keys and use **server response as truth** — optimistic updates are avoided for status changes (a wrongly optimistic "Completed" on a financial control step is unacceptable). Show pending state on the button instead.

```ts
const complete = useMutation({
  mutationFn: (processId: number) => completeProcess(processId),
  onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.stage(appGroupId, stageId, businessDate) }),
  onError: (e) => notifyError('Failed to complete step', e),
});
```

WebSocket integration (when added): socket events (`PROCESS_STATUS_CHANGED`, etc.) call `queryClient.invalidateQueries` for the affected keys — the socket is a cache-invalidation signal, not a second data path.

## Client state

- **Server data** → React Query only.
- **UI state** (expanded rows, panel visibility, search text) → local `useState`/`useReducer` in the owning component.
- **Cross-cutting session state** (selected business date, hierarchy path, declared role) → a single React Context (`WorkflowSessionContext`) or Zustand store; never prop-drill business date through 5 levels and never store it redundantly.

Role declaration rules enforced in the hook, not scattered in components:

```ts
// useRoleSelection: once the user has performed a producer action for the business date,
// switching to approver is blocked (server-verified; the hook mirrors the server rule for instant UX).
```

## Error handling

- One `ApiError` type from the client layer with `status`, `code`, `message`.
- Route-level `ErrorBoundary`; per-widget `ErrorState` with retry.
- User-facing messages are actionable ("Rerun requires RTB role") — never raw stack traces; full details go to console/monitoring.
