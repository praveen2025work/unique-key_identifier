# Components and Project Structure

## Folder structure (feature-first)

```
src/
├── app/                  # App shell: providers, router, layouts
├── features/             # One folder per business feature
│   └── orders/
│       ├── api/          # feature-specific queries/mutations
│       ├── components/   # feature-private components
│       ├── hooks/
│       ├── types.ts
│       └── index.ts      # public surface of the feature
├── components/ui/        # Shared dumb primitives: Button, Badge, Modal, Spinner, EmptyState, ErrorState
├── hooks/                # Cross-feature hooks
├── lib/ or api/          # HTTP client, interceptors, error normalization
├── utils/                # Pure helpers: dates.ts, format.ts (no React imports)
├── types/                # Cross-cutting types only
└── mocks/
```

Rules: features import from `components/ui`, `hooks`, `utils` — never from each other's internals (only via a feature's `index.ts`). Utilities are pure and React-free. Mock data never lives inside components.

## Container / presentational split

Containers (pages, feature roots) own data and orchestration; presentational components are pure props-to-JSX. This keeps rendering testable and reusable.

```tsx
// Container: owns the query
function OrderListPage() {
  const { data, isLoading, error, refetch } = useOrders();
  if (isLoading) return <ListSkeleton rows={8} />;
  if (error) return <ErrorState message="Couldn't load orders" onRetry={refetch} />;
  if (!data.length) return <EmptyState label="No orders yet" />;
  return <OrderList orders={data} />;
}

// Presentational: pure
interface OrderListProps { orders: Order[] }
function OrderList({ orders }: OrderListProps) {
  return (
    <ul>
      {orders.map(o => <OrderRow key={o.id} order={o} />)}
    </ul>
  );
}
```

Build `ErrorState`, `EmptyState`, and skeleton primitives once in `components/ui` and reuse them everywhere — three-state handling should cost one line per state, not a bespoke block per component.

## Component design rules

**Props contracts**
- Explicit interface per component. Prefer narrow props (`Pick<Order, 'id' | 'status'>` or specific fields) over passing whole objects a component barely uses.
- Callbacks named `onX` (`onSelect`, `onSubmit`); booleans read as assertions (`isOpen`, `disabled`, `readOnly`).
- Avoid boolean-prop explosions (`isSmall isPrimary isOutline`) — use a `variant`/`size` union instead.

**Composition over configuration**
- `children` and slot props before a dozen config flags:

```tsx
<Modal title="Confirm deletion" onClose={close}>
  <p>This cannot be undone.</p>
  <Modal.Actions>
    <Button variant="ghost" onClick={close}>Cancel</Button>
    <Button variant="danger" onClick={confirm}>Delete</Button>
  </Modal.Actions>
</Modal>
```

**State placement**
- State lives at the lowest component that needs it. Lift only when two siblings truly share it. Reach for Context only for genuinely app-wide session data (auth, theme, locale) — Context for frequently-changing data causes render storms.
- UI state maps update immutably: `setExpanded(prev => ({ ...prev, [id]: !prev[id] }))`.

**Render hygiene**
- No side effects during render. No JSX in effects/handlers — handlers set state, render reads it:

```tsx
// ❌ effect building UI
useEffect(() => { if (error) showToast(<ErrorCard e={error} />); }, [error]);
// ✅ render reads state
{error && <ErrorBanner error={error} onDismiss={clearError} />}
```

- Guard math: `items.length ? Math.round(done / items.length * 100) : 0`.
- Null-safe display: shared formatters render `null` as '—', never "Invalid Date"/"NaN":

```ts
// utils/format.ts
export const formatTimestamp = (iso: string | null) =>
  iso ? new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso)) : '—';
```

## Performance — measured, not superstitious

Default: write simple code; React is fast. Optimize when a list is large (>100 rows) or a re-render is demonstrably janky:

1. `React.memo` on repeated row components + `useCallback` for the handlers passed to them (memo without stable callbacks is useless).
2. `useMemo` for genuinely expensive derivations (sorting/filtering big arrays), not for `a + b`.
3. Debounce search/filter inputs (250–300ms).
4. Virtualize (react-window / @tanstack/virtual) only past ~200 visible rows.
5. Code-split routes with `React.lazy` + `Suspense`.

Never sprinkle memoization "just in case" — it's noise that hides the real hot spots.

## Accessibility patterns

- Interactive = interactive element: `<button>`, `<a>`, `<input>` — never `onClick` on `div`/`span` (if unavoidable, add `role`, `tabIndex`, key handlers — but it's almost never unavoidable).
- Icon-only buttons: `aria-label` + `title`.
- Overlays: `role="dialog"` `aria-modal="true"`, focus moves in on open and returns on close, Escape closes, click-outside optional.
- Forms: every input has an associated `<label>`; errors linked with `aria-describedby`; announce async results (`aria-live="polite"` region for toasts/status).
- Color never carries meaning alone — pair status colors with text or icons.
