# Quality Checklist — run before declaring done

## Verify first
- Run typecheck/lint/tests/build if commands exist in the repo (`package.json` scripts). If none are runnable, re-read the full diff line by line and say so honestly.

## Correctness
- All hooks rules satisfied: top-level calls only, honest dependency arrays, cleanup for every subscription/timer/listener
- No JSX inside effects, handlers, or utilities — render paths only
- Loading, error, AND empty states handled for every async-data component
- Division/aggregation guards empty collections; formatters handle null/undefined ('—', not "NaN"/"Invalid Date")
- List keys are stable domain IDs
- No state that duplicates derivable data
- Mutations: pending state shown, double-submit prevented, affected queries invalidated

## TypeScript
- Strict passes; zero `any`; `@ts-ignore` only with justification comment
- Exported functions and all component props explicitly typed
- Impossible states unrepresentable where cheap (discriminated unions for request/status shapes)
- Wire DTOs stop at the mapper; components import domain types only

## Enterprise quality
- Errors: normalized at the client layer, boundary in place, user messages actionable, technical detail to console/monitoring only
- Accessibility: semantic elements, labeled inputs, `aria-label` on icon buttons, keyboard reachable, Escape closes overlays, color not sole signal
- No secrets/env-specific values hardcoded; no `dangerouslySetInnerHTML` with unsanitized input
- Client-side role/permission checks are UX only — server enforces

## Simplicity & fit
- Smallest diff that solves the task; untouched code left untouched
- Matches surrounding codebase conventions (naming, styling system, data layer)
- No new dependency without stated justification
- No premature abstraction or "just in case" memoization
- Components under ~150 lines; logic extracted to hooks/utils when they grow
- Dead code deleted, not commented out

## Communication
- Summary delivered: what changed, why, trade-offs, bugs fixed in passing, anything deferred
