# State and Data

## The fundamental split

**Server state ≠ client state.** Treat them with different tools:

| Kind | Examples | Tool |
|---|---|---|
| Server state | API data, anything another user could change | TanStack Query (or SWR / RTK Query if incumbent) |
| Client UI state | open panels, form drafts, selected tab, search text | `useState` / `useReducer`, local to the owner |
| App-wide session | auth user, theme, locale, feature flags | Context (rarely changing) or Zustand |
| URL state | current page, filters worth sharing/bookmarking | router search params |

The classic mistake is caching server data in `useState` via `useEffect` + `fetch` — you inherit races, no caching, no retries, stale closures. Don't hand-roll it.

```tsx
// ❌ the triad
const [data, setData] = useState(null);
useEffect(() => { fetch(url).then(r => r.json()).then(setData); }, [url]);

// ✅
const { data, isLoading, error } = useQuery({ queryKey: ['orders', filters], queryFn: () => fetchOrders(filters) });
```

## Query conventions

- **Query keys are contracts.** Centralize them; include every variable the fetch depends on:

```ts
export const queryKeys = {
  orders: (filters: OrderFilters) => ['orders', filters] as const,
  order: (id: string) => ['orders', id] as const,
};
```

- One query hook per resource (`useOrders`, `useOrder(id)`) wrapping `useQuery` — components never call `useQuery` with inline keys.
- Polling: `refetchInterval`, never hand-rolled `setInterval` fetch loops.
- Real-time (WebSocket/SSE): events invalidate query keys (`queryClient.invalidateQueries`) — the socket is a cache-invalidation signal, not a parallel data path.

## Mutations

```ts
const createOrder = useMutation({
  mutationFn: postOrder,
  onSuccess: () => queryClient.invalidateQueries({ queryKey: ['orders'] }),
  onError: (e) => notifyError('Order failed', e),
});
```

- Invalidate affected keys on success; show `isPending` on the trigger button.
- **Optimistic updates only for low-stakes, easily-reversed actions** (likes, toggles). For anything with business/financial consequence, wait for the server and show pending state — a false "success" is worse than a spinner.
- Disable submit while pending to prevent double-fire.

## The API boundary

One place normalizes the outside world; components see clean domain types.

```ts
// lib/api/client.ts — single fetch wrapper
export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${config.apiBase}${path}`, {
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    ...init,
  });
  if (!res.ok) throw await toApiError(res);   // normalize every failure shape once
  return res.json() as Promise<T>;
}
```

- **Map DTOs to domain types at this boundary** — rename ugly backend fields, convert `'Y'/'N'`/`0/1` flags to real booleans, parse dates, default nulls. Components never see raw wire shapes.
- Validate untrusted/critical payloads with zod (or similar) when the backend contract is shaky; log-and-surface unknown enum values rather than silently coercing.

## Forms

- 1–3 fields: controlled `useState` is fine.
- Real forms: React Hook Form + zod resolver — typed values, per-field errors, no re-render storms.
- Always: label every field, disable submit while pending, show field-level validation on blur/submit (not on first keystroke), preserve user input on failure.

## useEffect discipline

Legitimate uses: subscribing to external systems (sockets, DOM events, timers, third-party widgets) with cleanup. Everything else has a better home:

| Symptom | Fix |
|---|---|
| Effect computes derived value into state | Compute during render (`useMemo` if expensive) |
| Effect reacts to a state change caused by an event | Do it in the event handler |
| Effect fetches data | Query library |
| Effect syncs one state to another | Restructure — single source of truth |
| Chain of effects triggering each other | `useReducer` with explicit transitions |

Every effect that subscribes returns a cleanup. Every dependency array is honest (fix the code, not the array, when the linter complains).

## Error handling architecture

Three layers, defined once:

1. **Normalization** — client layer converts all failures to `ApiError`.
2. **Boundaries** — route-level `ErrorBoundary` for render crashes; widget-level `ErrorState` with retry for data failures. One broken widget must not blank the page.
3. **Messaging** — user text is actionable ("Session expired — sign in again"), technical detail goes to console/monitoring. Never render raw error objects or stack traces.
