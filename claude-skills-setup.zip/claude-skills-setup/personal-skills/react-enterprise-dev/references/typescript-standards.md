# TypeScript Standards

## Compiler baseline

`strict: true` plus `noUncheckedIndexedAccess: true`. If the codebase isn't strict yet, write new code as if it were and don't add fresh violations.

## The rules

**No `any`.** Use `unknown` at trust boundaries and narrow:

```ts
function isApiError(e: unknown): e is ApiError {
  return e instanceof ApiError;
}
```

`@ts-ignore`/`@ts-expect-error` only with a comment explaining why and ideally a ticket.

**Model the domain with unions, not booleans.**

```ts
// ❌ impossible states representable
interface Req { isLoading: boolean; isError: boolean; data?: Data }

// ✅ discriminated union
type Req =
  | { state: 'loading' }
  | { state: 'error'; error: ApiError }
  | { state: 'success'; data: Data };
```

Exhaustive handling via `switch` + `never` guard so adding a variant breaks the build where handling is missing:

```ts
function assertNever(x: never): never { throw new Error(`Unhandled: ${JSON.stringify(x)}`); }
```

**String literal unions over enums** for UI-facing values (`type Variant = 'primary' | 'ghost' | 'danger'`). Enums acceptable when backing runtime logic (state machines) or mirroring backend codes.

**Nullability is deliberate.** Server-nullable fields are `T | null` (not optional `?`), so "absent by design" is visible and rendered as '—'. Optional `?` means "may not be provided by the caller."

**Derive, don't redeclare.** `Pick`, `Omit`, `Partial`, `ReturnType`, `z.infer` — one source of truth per shape. Component props that are subsets of domain types use `Pick<Order, 'id' | 'status'>`.

**DTO vs domain types.** Wire shapes (backend column names, string flags) live in `api/dtos.ts` and stop at the mapper. Everything else imports domain types only. When the backend adds a field: DTO + mapper + domain type change together in one diff.

**Function signatures.** Type parameters and returns on exported functions; let inference handle locals. Prefer readonly inputs for arrays you don't mutate (`readonly Order[]`).

**Generics earn their complexity.** A generic that's only ever instantiated with one type is a plain type. Constrain generics (`<T extends { id: string }>`) rather than reaching into unknowns.

## React-specific typing

```tsx
// Props: interface, children typed explicitly when accepted
interface CardProps {
  title: string;
  onClose?: () => void;
  children: React.ReactNode;
}
function Card({ title, onClose, children }: CardProps) { ... }
```

- Avoid `React.FC` (implicit children, awkward generics) — plain function with typed props.
- Events: precise types (`React.ChangeEvent<HTMLInputElement>`, `React.MouseEvent<HTMLButtonElement>`).
- `useState` with unions: annotate when the initial value doesn't reveal the type: `useState<Order | null>(null)`.
- Refs: `useRef<HTMLDivElement>(null)` for DOM, `useRef<number | undefined>(undefined)` for mutable values.
- Custom hooks return objects (`{ data, isLoading }`) once past two values; use `as const` for tuple returns.

## Naming

- Components/types/interfaces: `PascalCase`. Hooks: `useCamelCase`. Constants: `SCREAMING_SNAKE` only for true module-level constants.
- Files match their main export: `OrderRow.tsx`, `useOrders.ts`, `types.ts`.
- Booleans read as predicates: `isOpen`, `hasError`, `canSubmit`. Handlers `handleX` internally, `onX` as props.
