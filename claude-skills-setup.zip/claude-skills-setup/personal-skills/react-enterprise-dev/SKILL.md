---
name: react-enterprise-dev
description: Generic agentic coding standards for React and TypeScript development at enterprise-grade quality — clean, simple, maintainable code. Use this skill for ANY React work not covered by a more specific project skill - building components, pages, hooks, or full features; refactoring or reviewing React/TypeScript code; setting up data fetching, forms, routing, or state management; fixing bugs in React apps; or scaffolding a new React project. Trigger whenever the user mentions React, JSX/TSX, components, hooks, frontend features, or asks to write/fix/review UI code — even for small snippets. If a project-specific React skill also applies, read both; the project skill wins on conflicts.
---

# React Enterprise Development

Standards for writing clean, simple, enterprise-grade React with TypeScript. The guiding principle: **boring, predictable code that the next developer understands in 30 seconds**. Cleverness is a cost. Simplicity is the feature.

## How to use this skill

1. Read this file — it covers the agentic workflow and core rules.
2. Writing/refactoring components → `references/components-and-structure.md`
3. Data fetching, server/client state, forms → `references/state-and-data.md`
4. TypeScript conventions → `references/typescript-standards.md`
5. Before finishing → `references/quality-checklist.md`

## Agentic workflow — how to approach every task

**1. Explore before editing.** In an existing codebase, read neighboring code first: how do existing components fetch data, handle errors, name files, style elements? Match established conventions even when this skill suggests otherwise — consistency within a codebase beats external best practice. Note the deviation once; don't fight the codebase.

**2. Plan proportionally.** One-line fix: just fix it. New feature: state a 3–5 line plan (components involved, data flow, edge cases) before writing code. Never produce a wall of code with no stated approach for non-trivial work.

**3. Smallest correct diff.** Change what the task requires. Don't reformat untouched code, rename unrelated variables, or "improve" adjacent files. Opportunistic fixes are allowed only for genuine bugs in code you're already editing — and call them out.

**4. Verify.** If a build/typecheck/test command is available, run it. If not, re-read the diff checking: types compile mentally, all states handled (loading/error/empty), no unused imports, hooks rules respected. Never declare done on unverified code.

**5. Explain the diff.** End with: what changed, why, any trade-offs, anything deliberately deferred.

## Core rules (the 90% that matters)

**Components**
- One component, one job. Over ~150 lines or ~5 pieces of state → split it (extract a hook or a child component).
- Function components + hooks only. Props destructured, typed with an `interface` or `type` — never `any`, never untyped.
- Derive, don't store: anything computable from props/state is computed (with `useMemo` only when measurably needed), never mirrored into extra `useState` that can drift.
- Conditional rendering handles all three: **loading, error, empty** — every time a component depends on async data.
- Keys are stable domain IDs, not array indexes (indexes only for static never-reordered lists).
- JSX lives only in render return paths — never inside `useEffect`, event handlers, or utility functions.

**Hooks**
- `useEffect` is a last resort, for synchronizing with external systems (subscriptions, DOM, timers) — not for data transformation (derive it), not for responding to state changes (do it in the event handler), not for fetching (use a data library).
- Every effect: correct dependency array, cleanup function when it subscribes/listens/times.
- Reusable logic → custom hook (`useX`) with a clear return contract.

**Simplicity discipline**
- No premature abstraction: duplicate twice, extract on the third occurrence.
- No new dependency without justification — prefer the platform, then existing deps, then a new library only for genuinely hard problems (dates, data fetching, forms, virtualization).
- Early returns over nested conditionals. Small pure functions over inline lambdas doing real logic.
- Delete dead code; don't comment it out.

**Enterprise-grade non-negotiables**
- **TypeScript strict.** No `any`, no `@ts-ignore` without an explanatory comment. See `references/typescript-standards.md`.
- **Error handling is designed, not defaulted.** Every fetch/mutation has a defined failure UX. User-facing messages are actionable; technical details go to console/monitoring.
- **Accessibility floor**: semantic elements (`button`, not clickable `div`), labels on inputs, `aria-label` on icon-only buttons, keyboard operability, Escape closes overlays.
- **No secrets or environment-specific values in code.** Config via environment/config module.
- **Security basics**: never `dangerouslySetInnerHTML` with unsanitized input; validate/escape anything user-provided that reaches URLs or markup.
- **Never trust the client for authorization** — UI role checks are UX; the server is the enforcement.

## When scaffolding something new

Default modern baseline (unless the codebase dictates otherwise): Vite + React + TypeScript strict, functional components, TanStack Query for server state, plain `useState`/`useReducer` + Context (or Zustand if genuinely global) for client state, Tailwind or the incumbent styling system, ESLint + Prettier, Vitest + Testing Library. Folder layout in `references/components-and-structure.md`.

## Definition of done

Compiles under strict TypeScript · loading/error/empty handled · accessible · matches surrounding conventions · smallest reasonable diff · verified (or verification honestly stated as unavailable) · diff explained.
