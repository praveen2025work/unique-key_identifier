# Agent One — Plan Revision v3

**From:** 17-week fast track, 63 stories, 352 points
**To:** 19-week fast track, 72 stories, 417 points
**Wave 1 delta:** +55 points (297 → 352)

Three drivers: the P&L bridge model, the knowledge graph layer, and the move from
user-scoped to rec-scoped sessions. One offset: Phoenix already exists.

---

## 1. The P&L bridge — corrects a wrong assumption

The current plan treats `FO − BO` as the break. In an investment bank they are never equal
and are not meant to be. FO P&L is risk-based on a trader's view; BO P&L is accounting P&L
on a legal entity, containing reserves, XVA, funding charges, amortisation, intercompany
eliminations and FX translation that the desk never sees.

The rec is **FO + reconciling items = expected BO**, and the break is the residual.

Without this, Step 1 will raise a break on every book carrying a CVA allocation or an FTP
charge, on day one of UAT. This is the highest-priority change in the revision, and it is a
correctness issue rather than a scope addition.

**Changes:** `Step 1 - FOBO rec ingestion` acceptance criteria rewritten; new story
**Bridge computation service in recon engine** (8 pts, Sprint 5); bridge definitions modelled
in the new graph epic (8 pts).

---

## 2. Knowledge graph — new epic AOF-E13

The current backlog has no graph layer, but several stories assume one implicitly: row-level
scoping by desk and book, region-aware rec status, dataset lineage, and the bridge above all
need effective-dated identity, hierarchy and ownership.

**AOF-E13, Wave 1 (29 pts):**

| Story | Pts | Sprint |
|---|---|---|
| Bitemporal graph schema and Flyway migrations | 5 | 2 |
| Graph repository with `as_of` and caller-scoped queries | 8 | 3 |
| Reference layer ingestion with FO-to-BO mapping | 8 | 4 |
| P&L bridge model and reconciling item definitions | 8 | 4 |

**Deferred to Wave 1.5 (10 pts):** lineage layer ingestion, event layer write-back and
similar-break retrieval. Both are valuable but neither is needed for the pilot to be correct.
Institutional memory retrieved against unresolved entities is worse than none, because it
looks authoritative.

**Offset:** `Row-level data scoping by desk and book` drops 5 → 3 points, because entitlement
becomes a predicate inside the graph repository rather than a second implementation.

---

## 3. Rec-scoped sessions — replaces user-scoped

**Current:** session per user id.
**Target:** session identity derived from `(rec_id, book_set, cob_date, region)`.

This is the change with the widest blast radius, because session identity is what
idempotency, checkpointing, audit attribution and the dashboard all key on.

| Story | Was | Now | Change |
|---|---|---|---|
| Rec-scoped session persistence and resume | 5 | 8 | Multi-participant, join semantics, legacy migration |
| Rec-session concurrency control and handover | — | 5 | **New** — follow-the-sun |
| Rec-session and dataset creation tool (MCP) | 5 | 8 | One snapshot per rec, filtered per caller on read |
| Audit trail for user and AI actions | 5 | 8 | Per-action attribution inside a shared session |
| Async job execution with retry and idempotency | 8 | 8 | Idempotency key rederived — no point change |
| Workflow dashboard with role-based views | 8 | 8 | Rec-centric queue — no point change |

Four consequences worth deciding explicitly:

**Partial entitlement.** A caller entitled to only some books in the rec's book set must not
silently get a filtered subset — a rec that looks complete but isn't is a control problem.
This routes to the existing *Forced partial analysis with explicit consent* pattern, which
the backlog already has. Good reuse.

**One dataset, not N.** The snapshot is built once for the whole book set and filtered per
caller at read time. Building per user would multiply storage and, worse, mean two analysts
in the same session are looking at different data.

**Checkpoint thread id** becomes the rec session identity. This is also what makes the
overnight pause and the regional handover work on the same mechanism.

**Legacy migration.** In-flight user-scoped sessions need draining or migrating at cutover.
Added to the acceptance criteria rather than left to discover at release.

---

## 4. Product-aware RecPack

Six hardcoded cause checks won't survive contact with more than one product. An FX break is
usually snap-time; equities is usually a corporate action; rates is usually a curve or fixing.
Tolerance models diverge just as sharply — FX runs huge notional at tight percentage
tolerance, credit the reverse.

**New story:** *RecPack abstraction for product-specific checks and tolerances* (8 pts,
Sprint 6). Pack resolved by `(product, rec_family)` at run time.

This is also the story that makes Wave 2 cheap. MBR and FAS onboarding currently carry 55
points largely because each is treated as bespoke; with RecPack in place, a new product is
configuration plus a predicate set. I have **not** reduced the Wave 2 estimates in this
revision — that saving should be claimed at the G4 gate once the abstraction is proven, not
assumed now.

---

## 5. Phoenix — reduced

Phoenix is already deployed in your estate for user logs, so the story becomes instrumentation
against an existing instance rather than a deployment.

*Deploy Phoenix with full trace instrumentation* → **Instrument agent traces in existing
Phoenix**, 5 → 3 points.

Added to the acceptance criteria: the specific span attributes needed for evaluation to be
attributable — `book_id`, `cob_date`, `as_of`, `rec_session_id`, `prompt_version`,
`caller_scope`. Without `prompt_version` in particular, you cannot attribute an evaluation
result to a prompt release, which undermines the governed learning loop in Sprint 8.

---

## 6. Schedule options

Net Wave 1 addition is 55 points, roughly one and a half sprints at the current run rate.

**Option A — extend to 19 weeks.** Add Sprint 9 (Wk18-19). Keeps full pilot scope, all five
workflow steps. This is what the revised backlog assumes.

**Option B — hold 17 weeks, descope.** Move *Step 3 Flash vs Formal* (8 pts) and *FAS request
preparation and MBR write-back* (8 pts) to Wave 1.5, and accept a three-step pilot: FOBO Rec,
Adjustments, Sign-off. Still demonstrates the full architecture end to end.

**Option C — hold 17 weeks, add capacity.** Roughly one additional backend engineer from
Sprint 2, since the graph epic front-loads into Sprints 2–4.

I'd recommend **A**. The bridge and graph work sits on the critical path for correctness, and
compressing it to protect a date produces a pilot that raises false breaks — which costs more
credibility with product control than two extra weeks.

**Option B is the better answer if the 17-week date is externally committed.** Flash vs Formal
is the most self-contained of the five steps and the least dependent on the graph.

---

## 7. Open questions

| # | Question | Blocks |
|---|---|---|
| Q1 | Are FO and BO book identifiers already canonical, or is probabilistic matching needed? | Sizing of AOF-E13 reference ingestion — could shift it by an order of magnitude |
| Q2 | Is the bridge pre-populated by upstream systems, or must the rec derive it? | Whether the bridge story is read-only or a build |
| Q3 | Which two products lead the pilot? | RecPack content, tolerance models |
| Q4 | Are PLEX residual and FOBO residual separately owned? | Whether packs are two or one |
| Q5 | Who owns reference data remediation when ingestion surfaces hierarchy gaps? | Phase 1 exception handling |

Q1 and Q2 are the two that could still move the estimate materially. Worth answering before
this revision goes to the CIO, since both are questions for product control rather than
engineering.

---

## Appendix — story count

| | v2 | v3 |
|---|---|---|
| Epics | 12 | 13 |
| Stories | 63 | 72 |
| Wave 1 points | 297 | 352 |
| Wave 1.5 points | — | 10 |
| Wave 2 points | 55 | 55 |
| Total | 352 | 417 |

Stories labelled `v2-revision` are new or materially changed. Stories labelled `wave-1.5` are
deferred out of the pilot.
