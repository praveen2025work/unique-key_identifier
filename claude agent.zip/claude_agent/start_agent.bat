@echo off
title Claude CLI Agent
echo =======================================
echo   Claude CLI Shared Folder Agent
echo =======================================
echo.

cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.8+
    pause
    exit /b 1
)

if "%1"=="--validate" (
    python claude_agent.py --validate
    pause
    exit /b
)

if "%1"=="--setup" (
    python claude_agent.py --setup
    pause
    exit /b
)

if "%1"=="--path" (
    python claude_agent.py --path "%2"
    pause
    exit /b
)

python claude_agent.py
pause
