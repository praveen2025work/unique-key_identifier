#!/usr/bin/env python3
"""
Claude CLI Shared Folder Agent
===============================
Validates Claude CLI, then watches an inbox folder for query files,
processes them via Claude CLI, and writes responses to outbox.

Usage:
    python claude_agent.py                          # Run full agent (validate + watch)
    python claude_agent.py --validate               # Validate only
    python claude_agent.py --setup                  # Create folder structure only
    python claude_agent.py --path "Z:\\claude_agent" # Override shared folder path
"""

import os
import sys
import subprocess
import shutil
import time
import argparse
import logging
from datetime import datetime
from pathlib import Path

# ── Configuration ────────────────────────────────────────────────────────────
# SET YOUR SHARED FOLDER PATH HERE
# Examples:
#   Windows network share : Path(r"\\manager-pc\SharedDrive\claude_agent")
#   Mapped drive          : Path(r"Z:\claude_agent")
#   Local shared folder   : Path(r"C:\Users\Manager\SharedFolder\claude_agent")

BASE_DIR = Path(r"Z:\claude_agent")   # <-- CHANGE THIS

POLL_INTERVAL = 5  # seconds between inbox scans

# Project-specific system prompts
PROJECT_CONTEXTS = {
    "fobo":        "You are helping with a FOBO orchestration service built in Java Spring Boot. Focus on burst handling, Quartz scheduling, and RabbitMQ/Kafka architecture.",
    "pnl":         "You are helping with a P&L Lineage Dashboard built in FastAPI + React/Vite/TypeScript. Focus on data lineage, CIO-level reporting, and visualization.",
    "entitlement": "You are helping with a central enterprise entitlement system using Spring Boot, Hibernate Envers, and Oracle DB. Focus on roles, audit trails, and access control.",
    "femwell":     "You are helping with the FemWell women's wellness app in React Native/Expo with Node.js/MongoDB backend.",
    "tbbb":        "You are helping with the TB-BB Exception Hub for exception processing, manual upload vs Atlas/Finstore systematic path.",
    "default":     "You are a senior software architect assistant. Provide clear, practical, production-grade answers."
}

# ── Logging Setup ─────────────────────────────────────────────────────────────

def setup_logging(logs_dir: Path):
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_file = logs_dir / f"agent_{datetime.now().strftime('%Y%m%d')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )

# ── Folder Setup ──────────────────────────────────────────────────────────────

def setup_folders(base: Path):
    folders = {
        "inbox":     base / "inbox",
        "outbox":    base / "outbox",
        "processed": base / "processed",
        "logs":      base / "logs",
        "contexts":  base / "contexts",
    }
    for name, path in folders.items():
        path.mkdir(parents=True, exist_ok=True)

    logging.info("✅ Folder structure ready:")
    for name, path in folders.items():
        logging.info(f"   {name:<12} → {path}")

    # Write sample query file
    sample = folders["inbox"] / "sample_query.txt.example"
    if not sample.exists():
        sample.write_text(
            "# Project: fobo\n"
            "# Author: YourName\n\n"
            "Review this Java Spring Boot service for performance issues.\n\n"
            "[Paste your code here]"
        )
        logging.info(f"   sample       → {sample}")

    return folders

# ── Validation ────────────────────────────────────────────────────────────────

def validate_claude() -> bool:
    print("\n" + "="*50)
    print("  Claude CLI Validation")
    print("="*50)

    all_ok = True

    # 1. Check PATH
    claude_path = shutil.which("claude")
    if not claude_path:
        print("❌ Claude CLI not found in PATH")
        print("   Fix: Add Claude install directory to your system PATH")
        print("   Then restart terminal and re-run this script")
        all_ok = False
    else:
        print(f"✅ Claude CLI found at: {claude_path}")

    if not all_ok:
        return False

    # 2. Check version
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            print(f"✅ Version: {result.stdout.strip()}")
        else:
            print(f"❌ Version check failed: {result.stderr.strip()}")
            all_ok = False
    except subprocess.TimeoutExpired:
        print("❌ Version check timed out")
        all_ok = False
    except Exception as e:
        print(f"❌ Error: {e}")
        all_ok = False

    # 3. Check auth
    try:
        auth = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True, text=True, timeout=10
        )
        if auth.returncode == 0:
            print(f"✅ Auth status: {auth.stdout.strip()}")
        else:
            print(f"⚠️  Auth check: {auth.stderr.strip()}")
            print("   Run: claude login   (if not already logged in)")
    except Exception:
        print("⚠️  Could not verify auth status — continuing anyway")

    # 4. Live prompt test
    print("\n--- Live prompt test ---")
    try:
        test = subprocess.run(
            ["claude", "-p", "Reply with exactly: CLAUDE_OK"],
            capture_output=True, text=True, timeout=30
        )
        if test.returncode == 0 and test.stdout.strip():
            print(f"✅ Claude responded: {test.stdout.strip()}")
        else:
            print(f"❌ Prompt test failed")
            print(f"   stderr: {test.stderr.strip()}")
            all_ok = False
    except subprocess.TimeoutExpired:
        print("❌ Prompt timed out — check network or VPN/proxy settings")
        all_ok = False
    except Exception as e:
        print(f"❌ Prompt error: {e}")
        all_ok = False

    print("="*50)
    if all_ok:
        print("✅ All checks passed — Agent is ready to start!\n")
    else:
        print("❌ Validation failed — fix issues above before running agent\n")

    return all_ok

# ── Context Resolution ────────────────────────────────────────────────────────

def get_project_context(project: str, context_dir: Path) -> str:
    ctx_file = context_dir / f"{project}.txt"
    if ctx_file.exists():
        return ctx_file.read_text().strip()
    return PROJECT_CONTEXTS.get(project, PROJECT_CONTEXTS["default"])

def extract_inline_context(content: str) -> tuple:
    lines = content.strip().splitlines()
    project = "default"
    clean_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.lower().startswith("# project:"):
            project = stripped.split(":", 1)[1].strip().lower()
        elif stripped.lower().startswith("# author:") or stripped.lower().startswith("# date:"):
            pass
        else:
            clean_lines.append(line)
    return project, "\n".join(clean_lines).strip()

# ── File Processor ─────────────────────────────────────────────────────────────

def process_file(filepath: Path, folders: dict):
    filename  = filepath.name
    stem      = filepath.stem
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    logging.info(f"Processing: {filename}")

    try:
        content = filepath.read_text(encoding="utf-8")
    except Exception as e:
        logging.error(f"Could not read {filename}: {e}")
        return

    project, prompt = extract_inline_context(content)
    system_ctx = get_project_context(project if project != "default" else stem, folders["contexts"])
    full_prompt = f"{system_ctx}\n\n---\n\n{prompt}"

    try:
        result = subprocess.run(
            ["claude", "-p", full_prompt],
            capture_output=True, text=True, timeout=120
        )
        response = result.stdout.strip() if result.returncode == 0 else (
            f"[ERROR - Claude returned code {result.returncode}]\n{result.stderr.strip()}"
        )
    except subprocess.TimeoutExpired:
        response = "[ERROR] Claude CLI timed out after 120 seconds."
    except Exception as e:
        response = f"[ERROR] Unexpected error: {e}"

    # Write response
    out_file = folders["outbox"] / f"{stem}_response_{timestamp}.txt"
    out_file.write_text(
        f"Query File : {filename}\n"
        f"Project    : {project}\n"
        f"Processed  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"{'='*60}\n\n"
        f"QUERY:\n{prompt}\n\n"
        f"{'='*60}\n\n"
        f"RESPONSE:\n{response}\n",
        encoding="utf-8"
    )

    # Archive original
    shutil.move(str(filepath), str(folders["processed"] / f"{stem}_{timestamp}.txt"))
    logging.info(f"✅ Done → {out_file.name}")

# ── Watcher ───────────────────────────────────────────────────────────────────

def watch(folders: dict):
    logging.info("👁️  Watching inbox for queries...")
    logging.info(f"   Drop .txt files into : {folders['inbox']}")
    logging.info(f"   Responses appear in  : {folders['outbox']}")
    logging.info("   Press Ctrl+C to stop\n")
    try:
        while True:
            for f in sorted(folders["inbox"].glob("*.txt")):
                process_file(f, folders)
            time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        logging.info("Agent stopped.")

# ── Entry Point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Claude CLI Shared Folder Agent")
    parser.add_argument("--validate", action="store_true", help="Validate Claude CLI only")
    parser.add_argument("--setup",    action="store_true", help="Create folder structure only")
    parser.add_argument("--path",     type=str,            help="Override shared folder path")
    args = parser.parse_args()

    # Path override via CLI arg
    base = Path(args.path) if args.path else BASE_DIR

    # Bootstrap logging to a temp location until folders exist
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout)])

    if args.validate:
        validate_claude()
        return

    folders = setup_folders(base)
    setup_logging(folders["logs"])

    if args.setup:
        return

    # Full run
    ok = validate_claude()
    if not ok:
        sys.exit(1)

    watch(folders)

if __name__ == "__main__":
    main()
