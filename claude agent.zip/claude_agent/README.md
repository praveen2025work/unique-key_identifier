# Claude CLI Shared Folder Agent

Drop query files → Claude processes them → Pick up responses.

---

## Quick Start (Manager's Machine)

### Step 1 — Set shared folder path
Open `claude_agent.py` and update line ~20:
```python
BASE_DIR = Path(r"Z:\claude_agent")          # Mapped drive
# OR
BASE_DIR = Path(r"\\manager-pc\Share\claude_agent")  # Network share
```
Or pass it at runtime (no file edit needed):
```
python claude_agent.py --path "Z:\claude_agent"
start_agent.bat --path "Z:\claude_agent"
```

### Step 2 — Validate Claude CLI
```
start_agent.bat --validate
```

### Step 3 — Start the agent
```
start_agent.bat
```

---

## Folder Structure (Auto-Created)

```
claude_agent/
├── claude_agent.py          ← main script
├── start_agent.bat          ← Windows launcher
├── README.md                ← this file
├── inbox/                   ← DROP your .txt query files here
├── outbox/                  ← Claude responses appear here
├── processed/               ← completed queries archived here
├── logs/                    ← daily log files
└── contexts/                ← per-project system prompts
    ├── fobo.txt
    ├── pnl.txt
    └── entitlement.txt
```

---

## How to Submit a Query

Create a `.txt` file in `inbox/` using this format:

```
# Project: fobo
# Author: Praveen

Review this Java Spring Boot service for performance issues.

[Paste your code here]
```

**Supported project prefixes:**

| Filename prefix   | Context loaded          |
|-------------------|-------------------------|
| `fobo_`           | FOBO / Quartz / Kafka   |
| `pnl_`            | P&L Dashboard / FastAPI |
| `entitlement_`    | Entitlement / Oracle DB |
| `femwell_`        | FemWell / React Native  |
| `tbbb_`           | TB-BB Exception Hub     |
| anything else     | Generic architect        |

**Example filenames:**
```
fobo_burst_review.txt
pnl_chart_help.txt
entitlement_audit_question.txt
```

---

## Pick Up Your Response

Check `outbox/` — file appears as:
```
fobo_burst_review_response_20260331_143022.txt
```
Contains your original query + Claude's full response.

---

## Commands

| Command                                  | What it does               |
|------------------------------------------|----------------------------|
| `python claude_agent.py`                 | Full run (validate + watch)|
| `python claude_agent.py --validate`      | Check Claude CLI only      |
| `python claude_agent.py --setup`         | Create folders only        |
| `python claude_agent.py --path "Z:\..."` | Override shared folder path|
| `start_agent.bat --validate`             | Windows: validate only     |

---

## Troubleshooting

| Problem              | Fix                                          |
|----------------------|----------------------------------------------|
| `command not found`  | Add Claude CLI to system PATH                |
| Auth error           | Run `claude login` in terminal               |
| Timeout              | Check VPN / corporate proxy                  |
| No response file     | Check `logs/` folder for error details       |
| Wrong folder         | Pass `--path` or update BASE_DIR in script   |
