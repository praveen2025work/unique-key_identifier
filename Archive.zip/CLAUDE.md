# FOBO Reconciliation Agent

## What this is
A FastAPI + MCP tool server for Front Office / Back Office equity reconciliation.
**No Anthropic API key required here.** Claude Code (or AOF) is the orchestrator.
This project only provides the MCP tools. LLM reasoning happens in your orchestrator.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  ORCHESTRATOR (you choose one)                       │
│  • Claude Code CLI  — local dev, your subscription   │
│  • AOF / Bedrock    — office prod, AWS               │
└──────────────────┬──────────────────────────────────┘
                   │  MCP protocol (stdio locally, SSE for AOF)
                   ▼
┌─────────────────────────────────────────────────────┐
│  FOBO MCP Server  (src/mcp_server.py)                │
│  Pure tools — no LLM, no Anthropic API key           │
│  • reconcile_all       • create_exception            │
│  • get_exceptions      • reload_rules                │
│  • generate_report                                   │
└──────────────────┬──────────────────────────────────┘
                   │
         ┌─────────┴──────────┐
         ▼                    ▼
  config/fobo_rules.json   data/*.json
  (BRD rules — edit this)  (swap to Oracle in prod)
```

## Quick start with Claude Code

```bash
pip install -r requirements.txt
cd fobo-agent
claude
```

Claude Code reads .mcp.json automatically, starts the MCP server as a subprocess,
and makes the fobo tools available. No API key needed — uses your Claude subscription.

Then type: Run FOBO recon for 2025-05-19
Or use the slash commands below.

## Web dashboard

```bash
source .venv/bin/activate   # or: pip install -r requirements.txt
export PYTHONPATH=.
uvicorn src.dashboard_app:app --host 127.0.0.1 --port 8080
```

Open **http://127.0.0.1:8080** — run recon by date/book, view breaks, exceptions, and PnL.

## Slash commands (defined in .claude/commands/)

| Command | What it does |
|---|---|
| /recon {date} | Full recon cycle, all books |
| /recon-desk {book} {date} | Recon for a specific desk |
| /reload-rules | Hot-reload BRD rules without restart |
| /exceptions {severity} | Show open exceptions |

## File guide

| File | Who edits | Purpose |
|---|---|---|
| config/fobo_rules.json | BRD / Product Control | Thresholds, severities, escalation rules |
| data/fo_trades.json | Dev / testing only | Sample FO data (replace with Oracle) |
| data/bo_settlements.json | Dev / testing only | Sample BO data (replace with Calypso) |
| src/mcp_server.py | Engineering | MCP tool definitions |
| src/reconciler.py | Engineering | Match/classify logic |
| src/rules_engine.py | Engineering | Rule resolution |
| src/data_layer.py | Engineering | Swap JSON to Oracle here only |

## Updating BRD rules (no redeploy)
1. Edit config/fobo_rules.json
2. Ask Claude Code: "reload the FOBO rules"  (calls reload_rules tool)
3. New thresholds apply on next reconcile_all call

## Running for AOF / office network (SSE mode)
```bash
uvicorn src.mcp_server:app --host 0.0.0.0 --port 8000
# AOF action group MCP URL: http://your-server:8000/sse
# See aof/ directory for full AOF registration config
```

## Switching to Oracle in prod
Edit src/data_layer.py only. Everything else stays identical.

## Tests
```bash
pytest tests/ -v
```
