/** Module Federation host configuration (used by rspack.config.mjs) */
export const moduleFederationHostConfig = {
  name: "agentone_host",
  filename: "remoteEntry.js",
  dts: false,
  exposes: {
    "./WorkspaceShell": "./src/components/layout/workspace-shell.tsx",
    "./PnLWorkflow": "./src/app/(workspace)/page.tsx",
  },
  shared: {
    react: { singleton: true, eager: true, requiredVersion: "19.2.3" },
    "react-dom": { singleton: true, eager: true, requiredVersion: "19.2.3" },
    zustand: { singleton: true, eager: true },
  },
};
