# Agent One — PnL Workflow Frontend

Production-grade Next.js frontend for the Agent One PnL Production workflow. Matches the reference design for workspace, pipeline, and overview views.

## Stack

- **Next.js 16.1.1** (App Router, Webpack via `--webpack`)
- **React 19.2.3**
- **Tailwind CSS v4** + shadcn/ui primitives
- **TanStack Query** for server state, **Zustand** for UI state
- **@json-render** for server-driven step output panels
- **@module-federation/enhanced** + **@rspack/core** for MFE host
- **next-themes** dark/light (Barclays Blue)

## Prerequisites

- Node.js 18+
- Mock API running at `http://localhost:8765` (see `../mock-api/`)

## Setup

```bash
cd frontend
npm install
```

## Development

Start the mock API (from repo root):

```bash
cd mock-api
PORT=8765 npm start
```

Start the frontend:

```bash
cd frontend
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Build

```bash
npm run build          # production build
npm run build:development
npm run build:uat
npm run build:production
```

## Environment

| File | Purpose |
|------|---------|
| `.env.development` | Local dev (`NEXT_PUBLIC_API_URL=http://localhost:8765`) |
| `.env.local` | Local overrides |
| `.env.uat` | UAT API URL |
| `.env.production` | Production API URL |

Optional server-side chat (no client API keys):

```bash
ANTHROPIC_API_KEY=sk-...   # enables real LLM in /api/chat route handler
```

Without `ANTHROPIC_API_KEY`, chat uses contextual mock responses.

## Architecture

```
src/
├── app/
│   ├── (workspace)/page.tsx    # Single workspace shell route
│   ├── api/chat/route.ts       # Chat proxy (no API keys client-side)
│   ├── layout.tsx
│   └── providers.tsx
├── components/
│   ├── layout/                 # TopBar, WorkspaceShell
│   ├── workspace/              # Left rail, output panels
│   ├── pipeline/               # DAG view
│   ├── overview/               # KPI + charts
│   ├── chat/                   # Agent chat panel
│   └── json-render/            # @json-render panel
├── hooks/use-api.ts            # TanStack Query hooks
├── store/ui-store.ts           # Zustand UI/session state
├── lib/                        # API client, chat, MCP bridge, schemas
└── data/workflow.ts            # Reference design fixture data
```

## Module Federation

- **Host name:** `agentone_host`
- **Exposes:** `./WorkspaceShell`, `./PnLWorkflow`
- **Next.js (Webpack):** native `webpack.container.ModuleFederationPlugin` in `next.config.ts` (compatible with Next 16)
- **Rspack standalone:** `@module-federation/enhanced` in `rspack.config.mjs` + shared config in `module-federation.config.ts`

## API Integration

All data calls use `NEXT_PUBLIC_API_URL` (default `http://localhost:8765`).

### API-driven (live from mock API)

| Area | Endpoint | UI surface |
|------|----------|------------|
| Models | `GET /api/models` | Top bar model badge, chat header |
| Sessions list / bootstrap | `GET /api/sessions` | Workspace shell session id |
| Session detail | `GET /api/sessions/:id` | Left rail title, id, started time |
| Session stats | `GET /api/sessions/:id/stats` | Top bar tokens/cost when stats populated |
| Quick actions | `GET /api/sessions/:id/actions` | Chat quick-prompt chips |
| Messages | `GET /api/sessions/:id/messages` | Chat history hydration |
| Documents | `GET /api/sessions/:id/documents` | Files tab (falls back to fixtures if empty) |
| Upload | `POST /api/upload` | Files tab upload button |
| Plugin activation | `POST /api/sessions/:id/plugins/:pluginId/activate` | Chat plugin badge, running indicator |

Chat send still POSTs to `/api/chat` (Next.js route handler), which proxies to Anthropic when configured. Message query is invalidated after each send.

### Still fixture-driven (`src/data/workflow.ts`)

- Workflow steps, progress rail, step header/footer
- Execution trace, greeks table, source files, data tables
- Pipeline DAG and overview KPIs/charts
- Initial findings / suggested actions when chat has no messages
- Book name in left rail footer

## Known Limitations

- Mock API has no `POST /messages` endpoint; chat history is local + route handler responses
- `@module-federation/enhanced` in Next.js webpack has compatibility issues with Next 16; enhanced MF is used in rspack standalone builds
- Some file preview libraries (pdfjs, docx-preview, fortune-sheet) are installed but not wired into the Files tab yet
- `@modelcontextprotocol/ext-apps` bridge is stubbed in `src/lib/mcp-bridge.ts`
