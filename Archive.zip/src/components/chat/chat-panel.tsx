"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUiStore } from "@/store/ui-store";
import {
  useChatMutation,
  useEffectiveSessionId,
  useSessionActions,
  useSessionMessages,
} from "@/hooks/use-api";
import { INITIAL_FINDINGS, QUICK_PROMPTS, SUGGESTED_ACTIONS } from "@/data/workflow";
import { cn } from "@/lib/utils";
import type { ChatMessage } from "@/types";

interface LocalMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  tag?: string;
}

function toLocalMessage(msg: ChatMessage): LocalMessage {
  return {
    id: msg.id,
    role: msg.role === "system" ? "assistant" : msg.role,
    content: msg.content,
    tag: msg.tag,
  };
}

export function ChatPanel() {
  const { isTyping, setIsTyping, updateTelemetry, telemetry, activePlugin } = useUiStore();
  const sessionId = useEffectiveSessionId();
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [input, setInput] = useState("");
  const chatMutation = useChatMutation(sessionId);
  const bottomRef = useRef<HTMLDivElement>(null);
  const hydratedFromApi = useRef(false);

  const { data: messagesData } = useSessionMessages(sessionId);
  const { data: actionsData } = useSessionActions(sessionId);

  const quickPrompts = useMemo(() => {
    if (!actionsData?.length) return QUICK_PROMPTS;

    const fromApi = actionsData.flatMap((category) =>
      category.actions.map((action) => ({
        label: action.label,
        message: action.message,
      })),
    );

    return fromApi.length > 0 ? fromApi : QUICK_PROMPTS.map((p) => ({ label: p, message: p }));
  }, [actionsData]);

  useEffect(() => {
    if (hydratedFromApi.current || !messagesData?.messages?.length) return;
    hydratedFromApi.current = true;
    setMessages(messagesData.messages.map(toLocalMessage));
  }, [messagesData]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || chatMutation.isPending) return;

    const userMsg: LocalMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: trimmed,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const history = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));
      const res = await chatMutation.mutateAsync({
        sessionId,
        message: trimmed,
        history,
      });
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: res.reply,
          tag: "🤖 Agent One",
        },
      ]);
      if (res.usage) {
        updateTelemetry(res.usage.input_tokens, res.usage.output_tokens);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content:
            "Unable to reach the agent. Please check your connection and try again.",
          tag: "⚠ Connection Error",
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void send(input);
    }
  };

  const showSeedContent = messages.length === 0;

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden bg-[var(--bg-2)]">
      <div className="panel-blur flex shrink-0 items-center gap-2.5 border-b border-[var(--border)] px-4 py-3">
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[rgba(139,124,255,0.28)] bg-[rgba(139,124,255,0.12)] px-[11px] py-[5px] font-mono text-[11px] font-bold text-[var(--violet-2)]">
          <div className="h-[7px] w-[7px] animate-pulse-dot rounded-full bg-[var(--violet)]" />
          {telemetry.model}
        </div>
        <div className="text-[12.5px] font-semibold">Agent Analysis & Chat</div>
        <div className="ml-auto flex items-center gap-1 rounded-[7px] border border-[var(--border)] bg-[var(--glass)] px-[9px] py-1 font-mono text-[10px] text-[var(--text-dim)]">
          {activePlugin ? `🔌 ${activePlugin.display_name}` : "📎 Step loaded"}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3.5">
        <div className="flex flex-col gap-[11px]">
          {showSeedContent ? (
            <div className="animate-msg-in flex flex-col gap-2">
              <div className="rounded-[14px] rounded-tl-[4px] border border-[var(--border)] bg-[var(--card)] p-3 shadow-[var(--shadow-sm)]">
                <div className="mb-2 flex items-center gap-1.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--cyan)] uppercase">
                  📝 Step Analysis
                </div>
                <div className="text-[12.5px] leading-[1.65] text-[var(--text-sec)] [&_strong]:font-semibold [&_strong]:text-[var(--text-pri)]">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {`PL Explains completed across **412 trades** (EMEA-IRD-Rates). Greeks decomposition covers **98.4%** of actual P&L — two greeks flag above tolerance.

The unexplained residual of **-$18,900** is within T+0 range but should be annotated before sign-off given delta and vega individually breaching the $25k threshold.`}
                  </ReactMarkdown>
                </div>
              </div>

              {INITIAL_FINDINGS.map((f) => (
                <div
                  key={f.id}
                  className="overflow-hidden rounded-[11px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]"
                >
                  <div className="flex items-stretch">
                    <div
                      className={cn(
                        "w-1 shrink-0",
                        f.level === "warn" && "bg-[var(--warning)]",
                        f.level === "err" && "bg-[var(--error)]",
                        f.level === "ok" && "bg-[var(--success)]",
                        f.level === "info" && "bg-[var(--cyan)]",
                      )}
                    />
                    <div className="flex-1 p-2.5 pl-3">
                      <div
                        className={cn(
                          "mb-1 text-[10px] font-extrabold tracking-[0.07em] uppercase",
                          f.level === "warn" && "text-[var(--warning)]",
                          f.level === "err" && "text-[var(--error)]",
                        )}
                      >
                        {f.label}
                      </div>
                      <div className="text-[11.5px] leading-normal text-[var(--text-sec)]">
                        {f.text}
                      </div>
                      {f.value ? (
                        <div className="mt-1 font-mono text-[10px] text-[var(--text-dim)]">
                          {f.value}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              ))}

              <div className="overflow-hidden rounded-[11px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
                <div className="border-b border-[var(--border)] bg-[var(--card-2)] px-3 py-2.5 text-[11px] font-bold text-[var(--text-sec)]">
                  💡 Suggested Actions
                </div>
                <div className="flex flex-col gap-[7px] p-3">
                  {SUGGESTED_ACTIONS.map((action, i) => (
                    <div
                      key={action}
                      className="flex items-start gap-2 text-[11.5px] leading-normal text-[var(--text-sec)]"
                    >
                      <div className="mt-px flex h-[19px] w-[19px] shrink-0 items-center justify-center rounded-[7px] text-[10px] font-bold text-white shadow-[0_2px_8px_rgba(45,168,255,0.35)] btn-gradient">
                        {i + 1}
                      </div>
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-[11px] border border-[var(--border)] bg-[var(--card)] p-3 shadow-[var(--shadow-sm)]">
                <div className="mb-2.5 flex items-center gap-1.5 text-[11px] font-bold text-[var(--text-sec)]">
                  🔢 Token Usage — This Step
                </div>
                <div className="flex flex-col gap-2">
                  <TokenBar label="Input" pct={68} value="14,280" color="bg-[var(--cyan)]" />
                  <TokenBar label="Output" pct={34} value="2,840" color="bg-[var(--violet)]" />
                  <TokenBar label="Cache hit" pct={52} value="7,100" color="bg-[var(--success)]" />
                </div>
              </div>
            </div>
          ) : null}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "animate-msg-in",
                msg.role === "user" ? "flex justify-end" : "flex flex-col gap-2",
              )}
            >
              {msg.role === "user" ? (
                <div className="max-w-[85%] rounded-[14px] rounded-br-[4px] px-3.5 py-2.5 text-[12.5px] leading-[1.55] text-white shadow-[0_4px_16px_rgba(45,168,255,0.3)] btn-gradient">
                  {msg.content}
                </div>
              ) : (
                <div className="rounded-[14px] rounded-tl-[4px] border border-[var(--border)] bg-[var(--card)] p-3 shadow-[var(--shadow-sm)]">
                  {msg.tag ? (
                    <div
                      className={cn(
                        "mb-2 text-[10px] font-extrabold tracking-[0.08em] uppercase",
                        msg.tag.includes("Error") ? "text-[var(--error)]" : "text-[var(--cyan)]",
                      )}
                    >
                      {msg.tag}
                    </div>
                  ) : null}
                  <div className="text-[12.5px] leading-[1.65] text-[var(--text-sec)] prose-p:my-1.5">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
                  </div>
                </div>
              )}
            </div>
          ))}

          {isTyping ? (
            <div className="flex items-center gap-2">
              <div className="flex gap-1 rounded-[14px] rounded-tl-[4px] border border-[var(--border)] bg-[var(--card)] px-[15px] py-[11px]">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="h-1.5 w-1.5 rounded-full bg-[var(--text-dim)]"
                    style={{ animation: `typing-dot 1.2s ${i * 0.2}s infinite` }}
                  />
                ))}
              </div>
              <span className="text-[11px] text-[var(--text-dim)]">Agent is thinking…</span>
            </div>
          ) : null}
          <div ref={bottomRef} />
        </div>
      </div>

      <div className="flex shrink-0 flex-wrap gap-1.5 px-3.5 pt-2.5">
        {quickPrompts.map((prompt) => {
          const label = typeof prompt === "string" ? prompt : prompt.label;
          const message = typeof prompt === "string" ? prompt : prompt.message;
          return (
            <button
              key={label}
              type="button"
              onClick={() => void send(message)}
              className="rounded-2xl border border-[var(--border)] bg-[var(--card)] px-3 py-1.5 text-[11px] text-[var(--text-sec)] whitespace-nowrap transition-all hover:-translate-y-px hover:border-[var(--cyan)] hover:text-[var(--cyan)]"
            >
              {label}
            </button>
          );
        })}
      </div>

      <div className="panel-blur shrink-0 border-t border-[var(--border)] p-3">
        <div className="flex items-end gap-2 rounded-[13px] border-[1.5px] border-[var(--border)] bg-[var(--bg-2)] p-2 transition-all focus-within:border-[var(--cyan)] focus-within:shadow-[0_0_0_3px_rgba(45,168,255,0.12)]">
          <textarea
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(e.target.scrollHeight, 100)}px`;
            }}
            onKeyDown={handleKey}
            rows={1}
            placeholder="Ask about this step, request analysis, or give instructions…"
            className="max-h-[100px] min-h-5 flex-1 resize-none border-none bg-transparent text-[12.5px] leading-[1.55] text-[var(--text-pri)] outline-none placeholder:text-[var(--text-dim)]"
          />
          <Button
            size="icon"
            disabled={!input.trim() || chatMutation.isPending}
            onClick={() => void send(input)}
            className="shrink-0"
          >
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="mt-[7px] px-0.5 text-[10px] text-[var(--text-dim)]">
          {activePlugin
            ? `Plugin: ${activePlugin.plugin_name} · ⌘↵ to send`
            : "Context: PL Explains · 412 trades · EMEA-IRD-Rates · ⌘↵ to send"}
        </div>
      </div>
    </div>
  );
}

function TokenBar({
  label,
  pct,
  value,
  color,
}: {
  label: string;
  pct: number;
  value: string;
  color: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 shrink-0 text-[10px] text-[var(--text-dim)]">{label}</div>
      <div className="h-[5px] flex-1 overflow-hidden rounded-sm bg-[var(--card-2)]">
        <div
          className={cn("h-full rounded-sm transition-all duration-700", color)}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="w-[46px] shrink-0 text-right font-mono text-[10px] text-[var(--text-sec)]">
        {value}
      </div>
    </div>
  );
}
