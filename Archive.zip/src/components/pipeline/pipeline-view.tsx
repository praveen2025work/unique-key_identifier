"use client";

import { ArrowRight, ArrowDown } from "lucide-react";
import { useUiStore } from "@/store/ui-store";
import { WORKFLOW_STEPS } from "@/data/workflow";
import { RUN_NUMBER } from "@/lib/env";
import { cn } from "@/lib/utils";

export function PipelineView() {
  const { setActiveView } = useUiStore();
  const completed = WORKFLOW_STEPS.filter((s) => s.status === "complete").length;
  const running = WORKFLOW_STEPS.filter((s) => s.status === "active").length;
  const queued = WORKFLOW_STEPS.filter((s) => s.status === "pending").length;

  const row1 = WORKFLOW_STEPS.slice(0, 3);
  const row2 = WORKFLOW_STEPS.slice(3);

  const goWorkspace = () => setActiveView("workspace");

  return (
    <div className="h-full overflow-auto px-10 py-8">
      <div className="mx-auto mb-7 flex max-w-[1100px] flex-wrap items-end gap-4">
        <div>
          <div className="text-2xl font-extrabold tracking-tight">Pipeline Flow</div>
          <div className="mt-1 text-[13px] text-[var(--text-sec)]">
            EMEA-IRD-Rates · T+0 · Run #{RUN_NUMBER} — agent-orchestrated stage graph
          </div>
        </div>
        <div className="ml-auto flex gap-2.5">
          <StatCard n={completed} label="Complete" color="var(--success)" />
          <StatCard n={running} label="Running" color="var(--cyan)" />
          <StatCard n={queued} label="Queued" color="var(--text-dim)" />
          <StatCard n={412} label="Trades" />
        </div>
      </div>

      <div className="mx-auto flex max-w-[1100px] flex-col">
        <div className="flex items-center">
          {row1.map((step, i) => (
            <div key={step.id} className="contents">
              <FlowNode step={step} onClick={goWorkspace} />
              {i < row1.length - 1 ? (
                <div className="flex w-14 shrink-0 items-center justify-center text-[var(--cyan)]">
                  <ArrowRight className="h-7 w-7" />
                </div>
              ) : null}
            </div>
          ))}
        </div>

        <div className="flex justify-center py-1 text-[var(--cyan)]">
          <ArrowDown className="h-[22px] w-[22px]" />
        </div>

        <div className="flex items-center">
          {row2.map((step, i) => (
            <div key={step.id} className="contents">
              <FlowNode step={step} onClick={goWorkspace} />
              {i < row2.length - 1 ? (
                <div className="flex w-14 shrink-0 items-center justify-center text-[var(--border-2)]">
                  <ArrowRight className="h-7 w-7" />
                </div>
              ) : null}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ n, label, color }: { n: number; label: string; color?: string }) {
  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--card)] px-4 py-2.5 text-center shadow-[var(--shadow-sm)]">
      <div className="text-xl font-extrabold" style={color ? { color } : undefined}>
        {n}
      </div>
      <div className="mt-0.5 text-[10px] tracking-[0.06em] text-[var(--text-dim)] uppercase">
        {label}
      </div>
    </div>
  );
}

function FlowNode({
  step,
  onClick,
}: {
  step: (typeof WORKFLOW_STEPS)[0];
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "relative flex-1 cursor-pointer overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)] p-[18px] text-left shadow-[var(--shadow-sm)] transition-all hover:-translate-y-[3px] hover:border-[var(--border-2)] hover:shadow-[var(--shadow)]",
        step.status === "complete" && "border-[rgba(52,211,153,0.3)]",
        step.status === "active" && "border-[rgba(45,168,255,0.4)] bg-[var(--grad-glow)]",
        step.status === "pending" && "opacity-55",
      )}
    >
      {step.status === "active" ? (
        <div className="absolute top-0 right-0 left-0 h-[3px] btn-gradient" />
      ) : null}
      <div className="mb-3 flex items-center gap-[11px]">
        <div
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-[11px] border border-[var(--border)] bg-[var(--card-2)] text-lg",
            step.status === "complete" &&
              "border-[rgba(52,211,153,0.3)] bg-[rgba(52,211,153,0.12)]",
            step.status === "active" &&
              "border-transparent btn-gradient text-white shadow-[0_4px_14px_rgba(45,168,255,0.45)]",
          )}
        >
          {step.icon}
        </div>
        <div>
          <div className="text-[14px] font-bold">{step.label}</div>
          <div className="mt-px font-mono text-[10px] text-[var(--text-dim)]">{step.engine}</div>
        </div>
        <span
          className={cn(
            "ml-auto rounded-[7px] px-2 py-1 text-[9px] font-bold tracking-[0.05em] uppercase",
            step.status === "complete" && "bg-[rgba(52,211,153,0.12)] text-[var(--success)]",
            step.status === "active" && "bg-[rgba(45,168,255,0.14)] text-[var(--cyan)]",
            step.status === "pending" && "bg-[var(--glass)] text-[var(--text-dim)]",
          )}
        >
          {step.statusLabel}
        </span>
      </div>
      <div className="flex flex-wrap gap-2">
        {step.metrics?.map((m) => (
          <div
            key={m.label}
            className="min-w-0 flex-1 rounded-[9px] border border-[var(--border)] bg-[var(--glass)] px-2.5 py-2"
          >
            <div
              className={cn(
                "font-mono text-[14px] font-bold whitespace-nowrap",
                m.variant === "pos" && "val-pos",
                m.variant === "neg" && "val-neg",
                m.variant === "warn" && "val-warn",
              )}
            >
              {m.value}
            </div>
            <div className="mt-0.5 text-[9px] tracking-[0.04em] text-[var(--text-dim)] uppercase">
              {m.label}
            </div>
          </div>
        ))}
      </div>
    </button>
  );
}
