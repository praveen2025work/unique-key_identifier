"use client";

import { useEffect, useRef } from "react";
import { TopBar } from "@/components/layout/topbar";
import { WorkspaceView } from "@/components/workspace/workspace-view";
import { PipelineView } from "@/components/pipeline/pipeline-view";
import { OverviewView } from "@/components/overview/overview-view";
import { useUiStore } from "@/store/ui-store";
import { DEFAULT_SESSION_ID } from "@/lib/env";
import {
  useActivatePlugin,
  useEffectiveSessionId,
  useModels,
  useSessionStats,
  useSessions,
} from "@/hooks/use-api";
export function WorkspaceShell() {
  const { activeView, sessionId, setSessionId, applySessionStats, setActivePlugin } = useUiStore();
  const effectiveSessionId = useEffectiveSessionId();
  const pluginActivated = useRef(false);

  const { data: models } = useModels();
  const { data: sessionsData } = useSessions();
  const { data: statsData } = useSessionStats(effectiveSessionId);
  const activatePlugin = useActivatePlugin(effectiveSessionId);

  useEffect(() => {
    if (sessionId) return;

    const preferred = sessionsData?.sessions.find((s) => s.id === DEFAULT_SESSION_ID);
    if (preferred) {
      setSessionId(preferred.id);
      return;
    }
    if (sessionsData?.sessions[0]) {
      setSessionId(sessionsData.sessions[0].id);
      return;
    }
    setSessionId(DEFAULT_SESSION_ID);
  }, [sessionId, sessionsData, setSessionId]);

  useEffect(() => {
    if (models?.default) {
      useUiStore.setState((s) => ({
        telemetry: { ...s.telemetry, model: models.default },
      }));
    }
  }, [models?.default]);

  useEffect(() => {
    if (!statsData?.stats || Object.keys(statsData.stats).length === 0) return;
    applySessionStats(statsData.stats);
  }, [statsData, applySessionStats]);

  useEffect(() => {
    if (pluginActivated.current || !effectiveSessionId) return;
    pluginActivated.current = true;

    void activatePlugin.mutateAsync().then((plugin) => {
      setActivePlugin(plugin);
      useUiStore.setState((s) => ({
        telemetry: { ...s.telemetry, running: true },
      }));
    }).catch(() => {
      pluginActivated.current = false;
    });
  }, [effectiveSessionId, setActivePlugin]);

  return (
    <div className="h-screen overflow-hidden">
      <TopBar />
      <main className="relative mt-[58px] h-[calc(100vh-58px)] overflow-hidden">
        {activeView === "workspace" ? (
          <div key="workspace" className="h-full animate-view-in">
            <WorkspaceView />
          </div>
        ) : null}
        {activeView === "pipeline" ? (
          <div key="pipeline" className="h-full animate-view-in overflow-auto">
            <PipelineView />
          </div>
        ) : null}
        {activeView === "overview" ? (
          <div key="overview" className="h-full animate-view-in overflow-auto">
            <OverviewView />
          </div>
        ) : null}
      </main>
    </div>
  );
}

export default WorkspaceShell;
