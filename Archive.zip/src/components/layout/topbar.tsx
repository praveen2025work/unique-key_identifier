"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun, LayoutGrid, GitBranch, LineChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUiStore } from "@/store/ui-store";
import { formatCost, formatTokens, cn } from "@/lib/utils";
import { RUN_NUMBER } from "@/lib/env";
import type { AppView } from "@/types";

const VIEWS: { id: AppView; label: string; icon: React.ReactNode }[] = [
  { id: "workspace", label: "Workspace", icon: <LayoutGrid className="h-3.5 w-3.5" /> },
  { id: "pipeline", label: "Pipeline", icon: <GitBranch className="h-3.5 w-3.5" /> },
  { id: "overview", label: "Overview", icon: <LineChart className="h-3.5 w-3.5" /> },
];

export function TopBar() {
  const { activeView, setActiveView, telemetry, isTyping } = useUiStore();
  const { theme, resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const showRunning = telemetry.running || isTyping;
  const currentTheme = mounted ? (resolvedTheme ?? theme ?? "dark") : "dark";

  useEffect(() => setMounted(true), []);

  const toggleTheme = () => {
    setTheme(currentTheme === "light" ? "dark" : "light");
  };

  return (
    <header className="fixed top-0 right-0 left-0 z-[100] flex h-[58px] items-center gap-3.5 border-b border-[var(--border)] bg-[var(--surface)] px-[18px] shadow-[var(--shadow-sm)] backdrop-blur-[20px] surface-blur">
      <div className="flex items-center gap-[11px]">
        <div className="relative flex h-[34px] w-[34px] items-center justify-center overflow-hidden rounded-[10px] text-[14px] font-extrabold tracking-tight text-white shadow-[0_4px_16px_rgba(45,168,255,0.4)] btn-gradient animate-shine">
          A1
        </div>
        <div className="flex flex-col leading-[1.1]">
          <div className="text-[15px] font-extrabold tracking-tight">
            <span className="brand-gradient-text">Agent</span> One
          </div>
          <div className="text-[10px] font-medium text-[var(--text-dim)]">
            PnL Production · Run #{RUN_NUMBER}
          </div>
        </div>
      </div>

      <div className="ml-1.5 flex gap-[3px] rounded-[11px] border border-[var(--border)] bg-[var(--card-2)] p-[3px]">
        {VIEWS.map((v) => (
          <button
            key={v.id}
            type="button"
            onClick={() => setActiveView(v.id)}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-[13px] py-1.5 text-[12px] font-semibold transition-all",
              activeView === v.id
                ? "btn-gradient text-white shadow-[0_3px_14px_rgba(45,168,255,0.35)]"
                : "text-[var(--text-dim)] hover:text-[var(--text-sec)]",
            )}
          >
            {v.icon}
            {v.label}
          </button>
        ))}
      </div>

      <div className="flex-1" />

      <div className="flex items-center gap-[7px]">
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[var(--border)] bg-[var(--glass)] px-[11px] py-[5px] font-mono text-[11px]">
          <span className="font-sans text-[10px] font-medium text-[var(--text-dim)]">Model</span>
          <span className="font-semibold text-[var(--violet-2)]">{telemetry.model}</span>
        </div>
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[var(--border)] bg-[var(--glass)] px-[11px] py-[5px] font-mono text-[11px]">
          <span className="font-sans text-[10px] font-medium text-[var(--text-dim)]">In</span>
          <span className="font-semibold text-[var(--cyan-2)]">{formatTokens(telemetry.tokensIn)}</span>
        </div>
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[var(--border)] bg-[var(--glass)] px-[11px] py-[5px] font-mono text-[11px]">
          <span className="font-sans text-[10px] font-medium text-[var(--text-dim)]">Out</span>
          <span className="font-semibold text-[var(--cyan-2)]">{formatTokens(telemetry.tokensOut)}</span>
        </div>
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[var(--border)] bg-[var(--glass)] px-[11px] py-[5px] font-mono text-[11px]">
          <span className="font-sans text-[10px] font-medium text-[var(--text-dim)]">Cost</span>
          <span className="font-semibold text-[var(--warning)]">{formatCost(telemetry.cost)}</span>
        </div>
      </div>

      {showRunning ? (
        <div className="flex items-center gap-1.5 rounded-[9px] border border-[rgba(52,211,153,0.3)] bg-[rgba(52,211,153,0.12)] px-3 py-[5px] text-[11px] font-semibold text-[var(--success)]">
          <div className="h-[7px] w-[7px] rounded-full bg-[var(--success)] animate-pulse-dot" />
          Running
        </div>
      ) : null}

      <Button
        variant="icon"
        size="icon"
        onClick={toggleTheme}
        title="Toggle theme"
        aria-label="Toggle theme"
      >
        {currentTheme === "light" ? (
          <Moon className="h-4 w-4" />
        ) : (
          <Sun className="h-4 w-4" />
        )}
      </Button>
    </header>
  );
}
