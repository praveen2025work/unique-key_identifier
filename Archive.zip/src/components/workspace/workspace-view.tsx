"use client";

import { Button } from "@/components/ui/button";
import { LeftRail } from "@/components/workspace/left-rail";
import { OutputPanel } from "@/components/workspace/output-panel";
import { ChatPanel } from "@/components/chat/chat-panel";

export function WorkspaceView() {
  return (
    <div className="grid h-full grid-cols-[246px_1fr]">
      <LeftRail />
      <div className="grid grid-rows-[auto_1fr_auto] overflow-hidden">
        <div className="panel-blur flex items-center gap-3.5 border-b border-[var(--border)] px-[22px] py-3.5">
          <span className="rounded-[7px] border border-[rgba(45,168,255,0.2)] bg-[rgba(45,168,255,0.1)] px-[9px] py-1 font-mono text-[10px] font-semibold text-[var(--cyan)]">
            STEP 03 / 06
          </span>
          <div>
            <div className="text-[16px] font-bold tracking-tight">PL Explains — Risk Attribution</div>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-[var(--text-sec)]">
              Engine:{" "}
              <span className="inline-flex items-center gap-1 rounded-md border border-[var(--border)] bg-[var(--glass)] px-2 py-0.5 font-mono text-[10px] text-[var(--cyan)]">
                pl_explains_engine.py
              </span>{" "}
              · Greeks decomposition · Δ Γ ν Θ ρ
            </div>
          </div>
          <div className="ml-auto flex gap-2">
            <Button variant="outline">⟳ Re-run</Button>
            <Button variant="outline">📋 Log</Button>
          </div>
        </div>

        <div className="grid h-full min-h-0 grid-cols-[1fr_400px] overflow-hidden">
          <OutputPanel />
          <ChatPanel />
        </div>

        <div className="panel-blur flex items-center gap-3 border-t border-[var(--border)] px-[22px] py-[11px]">
          <div className="text-[12px] text-[var(--text-sec)]">
            Step <strong className="font-semibold text-[var(--text-pri)]">3 of 6</strong> · Review
            analysis, then mark complete to proceed to{" "}
            <strong className="font-semibold text-[var(--text-pri)]">Flash vs Formal</strong>.
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="outline">💬 Add Note</Button>
            <div className="h-[22px] w-px bg-[var(--border-2)]" />
            <Button variant="outline">⏩ Skip</Button>
            <Button variant="success">✓ Mark Complete & Continue</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
