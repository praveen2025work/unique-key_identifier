"use client";

import { useEffect, useRef, useState } from "react";
import { useUiStore } from "@/store/ui-store";
import {
  GREEKS_SUMMARY,
  TRACE_ITEMS,
  EXEC_CODE_SNIPPET,
  SOURCE_FILES,
  WORKFLOW_FILES,
} from "@/data/workflow";
import { PL_EXPLAINS_PANEL } from "@/lib/json-render-schema";
import { JsonRenderPanel } from "@/components/json-render/json-render-panel";
import { cn, formatFileSize } from "@/lib/utils";
import type { DocumentItem, PanelTab, WorkflowFile } from "@/types";
import { Download, Check, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffectiveSessionId, useSessionDocuments, useUploadFile } from "@/hooks/use-api";

const TABS: { id: PanelTab; label: string }[] = [
  { id: "exec", label: "⚙ Execution" },
  { id: "source", label: "📄 Source" },
  { id: "data", label: "📈 Data" },
  { id: "files", label: "📁 Files" },
];

function StatusChip({ status, label }: { status: string; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 rounded-[7px] px-2 py-[3px] text-[10px] font-bold",
        status === "ok" && "bg-[rgba(52,211,153,0.12)] text-[var(--success)]",
        status === "warn" && "bg-[rgba(251,191,36,0.12)] text-[var(--warning)]",
        status === "err" && "bg-[rgba(251,113,133,0.12)] text-[var(--error)]",
      )}
    >
      {label}
    </span>
  );
}

function FileDownloadButton({ name }: { name: string }) {
  const [done, setDone] = useState(false);

  return (
    <Button
      variant="icon"
      size="icon"
      title={`Download ${name}`}
      onClick={() => {
        setDone(true);
        setTimeout(() => setDone(false), 1300);
      }}
      className={cn(done && "border-[var(--success)] text-[var(--success)]")}
    >
      {done ? <Check className="h-[15px] w-[15px]" /> : <Download className="h-[15px] w-[15px]" />}
    </Button>
  );
}

function documentIcon(contentType: string): string {
  if (contentType.includes("csv")) return "📊";
  if (contentType.includes("json")) return "📋";
  if (contentType.includes("pdf")) return "📄";
  return "📁";
}

function documentTypeClass(contentType: string): WorkflowFile["typeClass"] {
  if (contentType.includes("csv") || contentType.includes("parquet")) return "data";
  if (contentType.includes("json")) return "cfg";
  if (contentType.includes("python")) return "py";
  return "data";
}

function mapDocumentToFile(doc: DocumentItem, group: WorkflowFile["group"]): WorkflowFile {
  const ext = doc.original_filename.split(".").pop()?.toUpperCase() ?? "FILE";
  return {
    id: doc.id,
    icon: documentIcon(doc.content_type),
    name: doc.original_filename,
    type: ext,
    typeClass: documentTypeClass(doc.content_type),
    stats: [formatFileSize(doc.file_size), doc.processing_status],
    group,
    badge: doc.processing_status === "completed" ? "✓ Ready" : undefined,
  };
}

function FilesTab() {
  const sessionId = useEffectiveSessionId();
  const { data: documentsData } = useSessionDocuments(sessionId);
  const uploadFile = useUploadFile(sessionId);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);

  const apiInputs = documentsData?.input_documents ?? [];
  const apiOutputs = documentsData?.output_artifacts ?? [];
  const hasApiFiles = apiInputs.length > 0 || apiOutputs.length > 0;

  const fileGroups: { group: WorkflowFile["group"]; label: string; files: WorkflowFile[] }[] =
    hasApiFiles
      ? ([
          {
            group: "inputs" as const,
            label: "📥 Inputs",
            files: apiInputs.map((d) => mapDocumentToFile(d, "inputs")),
          },
          {
            group: "outputs" as const,
            label: "📤 Outputs",
            files: apiOutputs.map((d) => mapDocumentToFile(d, "outputs")),
          },
        ] satisfies { group: WorkflowFile["group"]; label: string; files: WorkflowFile[] }[]).filter(
          (g) => g.files.length > 0,
        )
      : (["inputs", "outputs", "artifacts"] as const).map((group) => ({
          group,
          label:
            group === "inputs"
              ? "📥 Inputs"
              : group === "outputs"
                ? "📤 Outputs"
                : "📦 Code Artifacts",
          files: WORKFLOW_FILES.filter((f) => f.group === group),
        }));

  const handleUpload = async (file: File) => {
    setUploadMessage(null);
    try {
      const result = await uploadFile.mutateAsync(file);
      setUploadMessage(result.message);
    } catch {
      setUploadMessage("Upload failed. Check that the mock API is running.");
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="mb-1 flex items-center gap-2 rounded-[13px] border border-dashed border-[var(--border-2)] bg-[var(--glass)] p-3">
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept=".csv,.json,.txt,.pdf"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void handleUpload(file);
            e.target.value = "";
          }}
        />
        <Button
          variant="outline"
          size="sm"
          disabled={uploadFile.isPending}
          onClick={() => fileInputRef.current?.click()}
          className="gap-1.5"
        >
          <Upload className="h-3.5 w-3.5" />
          {uploadFile.isPending ? "Uploading…" : "Upload file"}
        </Button>
        <span className="text-[10px] text-[var(--text-dim)]">
          Async processing · documents refresh every 5s
        </span>
      </div>
      {uploadMessage ? (
        <p className="mx-0.5 text-[11px] text-[var(--cyan)]">{uploadMessage}</p>
      ) : null}

      {fileGroups.map(({ group, label, files }) => (
        <div key={group}>
          <div className="mx-0.5 mt-1.5 mb-px flex items-center gap-1.5 text-[10px] font-bold tracking-[0.08em] text-[var(--text-dim)] uppercase">
            {label}
            <span className="ml-auto font-mono font-medium">{files.length} files</span>
          </div>
          {files.map((file) => (
            <div
              key={file.id}
              className="mb-2 flex items-center gap-3 rounded-[13px] border border-[var(--border)] bg-[var(--card)] p-3 shadow-[var(--shadow-sm)] transition-all hover:-translate-y-px hover:border-[var(--border-2)] hover:shadow-[var(--shadow)]"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[11px] border border-[var(--border)] bg-[var(--grad-glow)] text-lg">
                {file.icon}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate font-mono text-[12.5px] font-semibold text-[var(--text-pri)]">
                  {file.name}
                </div>
                <div className="mt-[3px] flex flex-wrap items-center gap-2 text-[10px] text-[var(--text-dim)]">
                  <span
                    className={cn(
                      "rounded-md px-[7px] py-[3px] text-[8.5px] font-bold tracking-[0.05em] uppercase",
                      file.typeClass === "py" && "bg-[rgba(45,168,255,0.12)] text-[var(--cyan)]",
                      file.typeClass === "sql" && "bg-[rgba(26,79,156,0.12)] text-[var(--violet)]",
                      file.typeClass === "data" && "bg-[rgba(10,154,106,0.12)] text-[var(--success)]",
                      file.typeClass === "cfg" && "bg-[rgba(199,120,0,0.12)] text-[var(--warning)]",
                      file.typeClass === "log" && "bg-[rgba(126,150,184,0.14)] text-[var(--text-sec)]",
                    )}
                  >
                    {file.type}
                  </span>
                  {file.stats.map((s) => (
                    <span key={s}>{s}</span>
                  ))}
                  {file.badge ? <StatusChip status="ok" label={file.badge} /> : null}
                </div>
              </div>
              <FileDownloadButton name={file.name} />
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export function OutputPanel() {
  const { activePanelTab, setActivePanelTab, selectedSourceFileId, setSelectedSourceFileId } =
    useUiStore();
  const selectedFile = SOURCE_FILES.find((f) => f.id === selectedSourceFileId) ?? SOURCE_FILES[0];
  const panelScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    panelScrollRef.current?.scrollTo({ top: 0, behavior: "auto" });
  }, [activePanelTab]);

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden border-r border-[var(--border)]">
      <div className="panel-blur flex shrink-0 items-center gap-1 border-b border-[var(--border)] px-4">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActivePanelTab(tab.id)}
            className={cn(
              "cursor-pointer border-b-2 px-[13px] py-[11px] text-[12px] font-semibold whitespace-nowrap transition-all",
              activePanelTab === tab.id
                ? "border-[var(--cyan)] text-[var(--cyan)]"
                : "border-transparent text-[var(--text-dim)] hover:text-[var(--text-sec)]",
            )}
          >
            {tab.label}
          </button>
        ))}
        <div className="flex-1" />
        <div className="flex items-center gap-1.5 rounded-[7px] border border-[var(--border)] bg-[var(--glass)] px-[9px] py-1 font-mono text-[10px] text-[var(--text-sec)]">
          <div className="h-1.5 w-1.5 rounded-full bg-[var(--success)] shadow-[0_0_8px_var(--success)]" />
          3.2s
        </div>
      </div>

      <div ref={panelScrollRef} className="flex-1 overflow-y-auto p-4">
        {activePanelTab === "exec" ? (
          <div className="flex flex-col gap-3">
            <div className="overflow-hidden rounded-[13px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
              <div className="flex items-center gap-[7px] border-b border-[var(--border)] bg-[var(--card-2)] px-3.5 py-2.5 text-[11px] font-bold text-[var(--text-sec)]">
                🔧 Agent Tool-Call Trace
              </div>
              {TRACE_ITEMS.map((item) => (
                <div
                  key={item.time + item.tool}
                  className="flex items-center gap-2 border-b border-[var(--border)] px-3.5 py-2 text-[11px] last:border-b-0"
                >
                  <span className="w-[54px] shrink-0 font-mono text-[10px] text-[var(--text-dim)]">
                    {item.time}
                  </span>
                  <span className="w-5 shrink-0 text-center text-[13px]">{item.icon}</span>
                  <span className="flex-1 text-[var(--text-sec)]">
                    <strong className="font-semibold text-[var(--text-pri)]">{item.tool}</strong> ·{" "}
                    {item.detail}
                  </span>
                  <span className="ml-auto rounded-md bg-[rgba(52,211,153,0.1)] px-[7px] py-0.5 font-mono text-[10px] text-[var(--success)]">
                    {item.duration}
                  </span>
                </div>
              ))}
            </div>

            <div className="overflow-hidden rounded-[13px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
              <div className="border-b border-[var(--border)] bg-[var(--grad-glow)] px-3.5 py-[11px] text-[12px] font-bold text-[var(--cyan-2)]">
                📊 PL Explains — Greeks Summary (EMEA-IRD-Rates)
              </div>
              <table className="w-full border-collapse text-[12px]">
                <thead>
                  <tr>
                    {["Greek", "Actual", "Predicted", "Variance", "Status"].map((h) => (
                      <th
                        key={h}
                        className="border-b border-[var(--border)] px-3.5 py-2 text-left text-[9.5px] font-bold tracking-[0.08em] text-[var(--text-dim)] uppercase"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {GREEKS_SUMMARY.map((row) => (
                    <tr key={row.greek} className="hover:bg-[var(--glass)]">
                      <td className="border-b border-[var(--border)] px-3.5 py-2 font-mono text-[var(--text-pri)]">
                        {row.greek}
                      </td>
                      <td className="val-pos border-b border-[var(--border)] px-3.5 py-2 font-mono">
                        {row.actual}
                      </td>
                      <td className="val-pos border-b border-[var(--border)] px-3.5 py-2 font-mono">
                        {row.predicted}
                      </td>
                      <td
                        className={cn(
                          "border-b border-[var(--border)] px-3.5 py-2 font-mono",
                          row.status === "warn" ? "val-warn" : row.greek === "Gamma" ? "val-neg" : "val-pos",
                        )}
                      >
                        {row.variance}
                      </td>
                      <td className="border-b border-[var(--border)] px-3.5 py-2">
                        <StatusChip status={row.status} label={row.statusLabel} />
                      </td>
                    </tr>
                  ))}
                  <tr className="hover:bg-[var(--glass)]">
                    <td className="px-3.5 py-2 font-mono font-bold">Unexplained</td>
                    <td className="px-3.5 py-2" colSpan={2} />
                    <td className="val-neg px-3.5 py-2 font-mono font-bold">-$18,900</td>
                    <td className="px-3.5 py-2">
                      <StatusChip status="err" label="✗ Review" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <JsonRenderPanel spec={PL_EXPLAINS_PANEL} />

            <div className="overflow-hidden rounded-[13px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
              <div className="flex items-center gap-2 border-b border-[var(--border)] bg-[var(--card-2)] px-3.5 py-2">
                <span className="font-mono text-[10px] font-bold tracking-[0.05em] text-[var(--cyan)] uppercase">
                  Python
                </span>
                <span className="ml-auto font-mono text-[10px] text-[var(--text-dim)]">
                  greeks_decomp.py · 44–62
                </span>
              </div>
              <pre className="px-4 py-3.5 font-mono text-[11.5px] leading-[1.75] whitespace-pre-wrap text-[var(--text-sec)]">
                {EXEC_CODE_SNIPPET}
              </pre>
            </div>
          </div>
        ) : null}

        {activePanelTab === "source" ? (
          <div className="flex h-full min-h-[400px] overflow-hidden rounded-[13px] border border-[var(--border)]">
            <div className="w-[218px] shrink-0 overflow-y-auto border-r border-[var(--border)] bg-[var(--surface)] p-2 panel-blur">
              <div className="px-2 pt-2 pb-1 text-[10px] font-bold tracking-[0.08em] text-[var(--text-dim)] uppercase">
                pnl-explains · main
              </div>
              {["Engine", "Query", "Config"].map((section) => (
                <div key={section}>
                  <div className="flex items-center gap-1.5 px-2 pt-2.5 pb-1 text-[9.5px] font-bold tracking-[0.06em] text-[var(--text-dim)] uppercase">
                    {section === "Engine" ? "🐍" : section === "Query" ? "🗄" : "⚙"} {section}
                  </div>
                  {SOURCE_FILES.filter((f) => f.section === section).map((file) => (
                    <button
                      key={file.id}
                      type="button"
                      onClick={() => setSelectedSourceFileId(file.id)}
                      className={cn(
                        "flex w-full items-center gap-2 rounded-lg border border-transparent px-2 py-[7px] font-mono text-[11.5px] transition-all",
                        selectedSourceFileId === file.id
                          ? "border-[rgba(0,133,202,0.22)] bg-[var(--grad-glow)] text-[var(--cyan)]"
                          : "text-[var(--text-sec)] hover:bg-[var(--glass)] hover:text-[var(--text-pri)]",
                      )}
                    >
                      <span className="shrink-0 text-[13px]">{file.icon}</span>
                      {file.name}
                    </button>
                  ))}
                </div>
              ))}
            </div>
            <div className="flex-1 overflow-y-auto p-3.5">
              <div className="mb-3 flex flex-wrap gap-2.5">
                {selectedFile.meta.map((m) => (
                  <span
                    key={m}
                    className="rounded-[7px] border border-[var(--border)] bg-[var(--glass)] px-[9px] py-1 font-mono text-[10px] text-[var(--text-dim)]"
                  >
                    {m}
                  </span>
                ))}
              </div>
              <div className="overflow-hidden rounded-[13px] border border-[var(--border)] bg-[var(--card)]">
                <div className="flex items-center gap-2 border-b border-[var(--border)] bg-[var(--card-2)] px-3.5 py-2">
                  <span className="font-mono text-[10px] font-bold tracking-[0.05em] text-[var(--cyan)] uppercase">
                    {selectedFile.language}
                  </span>
                  <span className="ml-auto font-mono text-[10px] text-[var(--text-dim)]">
                    {selectedFile.name}
                  </span>
                </div>
                <pre className="px-4 py-3.5 font-mono text-[11.5px] leading-[1.75] whitespace-pre-wrap text-[var(--text-sec)]">
                  {selectedFile.code}
                </pre>
              </div>
            </div>
          </div>
        ) : null}

        {activePanelTab === "data" ? (
          <div className="flex flex-col gap-3">
            <DataTable
              title="📥 Input — Trade Sensitivities (sample 5 of 412)"
              headers={["Trade ID", "Delta", "Vega", "Theta", "Actual P&L"]}
              rows={[
                ["IRS-88142", "+4,820", "+1,140", "-310", "+$184,200"],
                ["SWPT-88147", "+2,310", "+3,980", "-880", "+$96,400"],
                ["IRS-88150", "-1,540", "+220", "-140", "-$42,100"],
                ["FRA-88151", "+980", "+60", "-90", "+$31,800"],
                ["SWPT-88158", "+3,640", "+2,710", "-620", "+$128,900"],
              ]}
            />
            <p className="px-0.5 text-[11px] text-[var(--text-dim)]">
              Showing 5 rows · full set = 412 trades · source: finance.pnl.trades
            </p>
            <DataTable
              title="🌍 Input — Market Moves (EOD, by bucket)"
              headers={["Bucket", "Greek", "Move", "Ccy", "Source"]}
              rows={[
                ["5Y", "delta", "+3.0 bp", "EUR", "ECB 14:30"],
                ["2Y×5Y", "vega", "+8.0 bp", "EUR", "vol surface"],
                ["10Y", "delta", "+0.4 bp", "EUR", "close"],
                ["2Y", "theta", "-1d carry", "EUR", "roll"],
              ]}
            />
            <DataTable
              title="📤 Output — explains_2026_06_16.parquet (aggregated)"
              headers={["Greek", "Explained P&L", "Variance", "Breach"]}
              rows={[
                ["delta", "+$1,220,000", "+$28,300", "yes"],
                ["gamma", "-$40,800", "-$1,300", "no"],
                ["vega", "+$295,000", "+$23,700", "no"],
                ["theta", "-$88,100", "+$700", "no"],
                ["rho", "+$13,800", "+$400", "no"],
              ]}
            />
            <p className="px-0.5 text-[11px] text-[var(--text-dim)]">
              Written to finance.pnl.explains · 5 rows · 1 partition (as_of=2026-06-16)
            </p>
          </div>
        ) : null}

        {activePanelTab === "files" ? <FilesTab /> : null}
      </div>
    </div>
  );
}

function DataTable({
  title,
  headers,
  rows,
}: {
  title: string;
  headers: string[];
  rows: string[][];
}) {
  return (
    <div className="overflow-hidden rounded-[13px] border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
      <div className="border-b border-[var(--border)] bg-[var(--grad-glow)] px-3.5 py-[11px] text-[12px] font-bold text-[var(--cyan-2)]">
        {title}
      </div>
      <table className="w-full border-collapse text-[12px]">
        <thead>
          <tr>
            {headers.map((h) => (
              <th
                key={h}
                className="border-b border-[var(--border)] px-3.5 py-2 text-left text-[9.5px] font-bold tracking-[0.08em] text-[var(--text-dim)] uppercase"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row[0]} className="hover:bg-[var(--glass)]">
              {row.map((cell, i) => (
                <td
                  key={`${row[0]}-${i}`}
                  className={cn(
                    "border-b border-[var(--border)] px-3.5 py-2 font-mono text-[var(--text-pri)] last:border-b-0",
                    cell.startsWith("+") && "val-pos",
                    cell.startsWith("-") && cell !== "-1d carry" && "val-neg",
                  )}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
