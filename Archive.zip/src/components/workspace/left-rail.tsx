"use client";

import { useUiStore } from "@/store/ui-store";
import { WORKFLOW_STEPS, SESSION_META } from "@/data/workflow";
import { useEffectiveSessionId, useSession } from "@/hooks/use-api";
import { cn, formatSessionDate, shortSessionId } from "@/lib/utils";

export function LeftRail() {
  const { activeStepId, setActiveStepId } = useUiStore();
  const sessionId = useEffectiveSessionId();
  const { data: session } = useSession(sessionId);
  const completed = WORKFLOW_STEPS.filter((s) => s.status === "complete").length;

  const displayId = session ? shortSessionId(session.id) : SESSION_META.id;
  const displayTitle = session?.title ?? "PnL Production · T+0";
  const displayStarted = session?.created_at
    ? formatSessionDate(session.created_at)
    : SESSION_META.started;

  return (
    <aside className="rail-blur flex flex-col overflow-y-auto border-r border-[var(--border)]">
      <div className="px-[18px] pt-4 pb-3">
        <div className="mb-0.5 text-[10px] font-bold tracking-[0.12em] text-[var(--text-dim)] uppercase">
          Workflow
        </div>
        <div className="truncate text-[13px] font-semibold text-[var(--text-pri)]">{displayTitle}</div>
      </div>

      <div className="px-[18px] pt-1 pb-3">
        <div className="mb-[7px] flex justify-between text-[10px] font-medium text-[var(--text-dim)]">
          <span>Progress</span>
          <span>
            {completed} of {WORKFLOW_STEPS.length} complete
          </span>
        </div>
        <div className="h-[5px] overflow-hidden rounded bg-[var(--card-2)]">
          <div
            className="relative h-full overflow-hidden rounded btn-gradient shadow-[0_0_12px_rgba(45,168,255,0.5)] animate-prog-shine"
            style={{ width: `${(completed / WORKFLOW_STEPS.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-0.5 px-2.5 py-2">
        {WORKFLOW_STEPS.map((step, i) => (
          <div key={step.id}>
            <button
              type="button"
              onClick={() => setActiveStepId(step.id)}
              className={cn(
                "relative flex w-full items-center gap-[11px] rounded-[11px] border border-transparent p-2.5 text-left transition-all",
                step.status === "complete" && "opacity-65",
                step.status === "pending" && "opacity-[0.42]",
                step.status === "active" &&
                  "border-[rgba(45,168,255,0.3)] bg-[var(--grad-glow)] shadow-[inset_0_0_0_1px_rgba(45,168,255,0.15)]",
                activeStepId === step.id && step.status !== "active" && "bg-[var(--glass)]",
                step.status !== "active" && "hover:bg-[var(--glass)]",
              )}
            >
              <div
                className={cn(
                  "flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[9px] border border-[var(--border-2)] bg-[var(--card-2)] text-[14px]",
                  step.status === "complete" &&
                    "border-[rgba(52,211,153,0.35)] bg-[rgba(52,211,153,0.12)] text-[var(--success)]",
                  step.status === "active" &&
                    "border-transparent btn-gradient text-white shadow-[0_4px_14px_rgba(45,168,255,0.45)]",
                )}
              >
                {step.icon}
              </div>
              <div className="min-w-0 flex-1">
                <div
                  className={cn(
                    "truncate text-[12.5px] font-semibold",
                    step.status === "active" && "text-[var(--cyan-2)]",
                    step.status === "complete" && "text-[var(--success)]",
                    step.status === "pending" && "text-[var(--text-dim)]",
                  )}
                >
                  {step.label}
                </div>
                <div className="mt-px text-[10px] text-[var(--text-dim)]">{step.subtitle}</div>
              </div>
              <span
                className={cn(
                  "shrink-0 rounded-[7px] px-[7px] py-[3px] text-[9px] font-bold tracking-[0.05em] uppercase",
                  step.status === "complete" &&
                    "bg-[rgba(52,211,153,0.12)] text-[var(--success)]",
                  step.status === "active" && "bg-[rgba(45,168,255,0.14)] text-[var(--cyan)]",
                  step.status === "pending" && "bg-[var(--glass)] text-[var(--text-dim)]",
                )}
              >
                {step.statusLabel}
              </span>
            </button>
            {i < WORKFLOW_STEPS.length - 1 ? (
              <div className="ml-[26px] h-2 w-0.5 rounded bg-[var(--border-2)]" />
            ) : null}
          </div>
        ))}
      </div>

      <div className="border-t border-[var(--border)] px-4 py-3">
        <div className="font-mono text-[10px] leading-[1.9] text-[var(--text-dim)]">
          Session: <b className="font-medium text-[var(--text-sec)]">{displayId}</b>
          <br />
          Started: <b className="font-medium text-[var(--text-sec)]">{displayStarted}</b>
          <br />
          Book: <b className="font-medium text-[var(--text-sec)]">{SESSION_META.book}</b>
        </div>
      </div>
    </aside>
  );
}
