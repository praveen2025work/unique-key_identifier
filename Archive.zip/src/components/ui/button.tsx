import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[9px] text-[12px] font-semibold transition-all disabled:pointer-events-none disabled:opacity-50 outline-none",
  {
    variants: {
      variant: {
        default: "btn-gradient text-white shadow-[0_4px_14px_rgba(45,168,255,0.4)] hover:-translate-y-px",
        outline:
          "border border-[var(--border)] bg-[var(--glass)] text-[var(--text-sec)] hover:border-[var(--cyan)] hover:text-[var(--cyan)] hover:-translate-y-px",
        ghost: "text-[var(--text-sec)] hover:text-[var(--cyan)]",
        success:
          "bg-gradient-to-br from-[var(--success)] to-[var(--success-d)] text-[#042] font-bold shadow-[0_4px_16px_rgba(52,211,153,0.4)] hover:-translate-y-px",
        icon: "h-[34px] w-[34px] border border-[var(--border)] bg-[var(--glass)] text-[var(--text-sec)] hover:border-[var(--border-2)] hover:text-[var(--cyan)] hover:-translate-y-px",
      },
      size: {
        default: "h-auto px-[14px] py-2",
        sm: "h-8 px-3",
        icon: "h-[34px] w-[34px] p-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
