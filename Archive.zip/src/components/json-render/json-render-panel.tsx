"use client";

import { Renderer, JSONUIProvider } from "@json-render/react";
import type { Spec } from "@json-render/core";
import {
  parseStepOutputPanel,
  jsonRenderRegistry,
  type StepOutputPanel,
} from "@/lib/json-render-schema";
import { cn } from "@/lib/utils";

interface JsonRenderPanelProps {
  spec: StepOutputPanel | Spec | unknown;
  className?: string;
}

function isSpec(value: unknown): value is Spec {
  return (
    typeof value === "object" &&
    value !== null &&
    "root" in value &&
    "elements" in value
  );
}

export function JsonRenderPanel({ spec, className }: JsonRenderPanelProps) {
  let panelSpec: Spec | null = null;
  let title: string | undefined;

  if (isSpec(spec)) {
    panelSpec = spec;
  } else {
    const parsed = parseStepOutputPanel(spec);
    if (parsed) {
      panelSpec = parsed.spec;
      title = parsed.title;
    }
  }

  if (!panelSpec) {
    return null;
  }

  return (
    <div
      className={cn(
        "rounded-[13px] border border-[var(--border)] bg-[var(--card)] p-3 shadow-[var(--shadow-sm)]",
        className,
      )}
    >
      {title ? (
        <div className="mb-2 text-[12px] font-bold text-[var(--cyan-2)]">{title}</div>
      ) : null}
      <JSONUIProvider registry={jsonRenderRegistry}>
        <Renderer spec={panelSpec} registry={jsonRenderRegistry} />
      </JSONUIProvider>
    </div>
  );
}
