"use client";

import { useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Button } from "@/components/ui/button";
import { useUiStore } from "@/store/ui-store";
import {
  CHART_DATA,
  VARIANCE_BARS,
  ACTIVITY_FEED,
} from "@/data/workflow";
import { RUN_NUMBER } from "@/lib/env";
import { cn } from "@/lib/utils";

export function OverviewView() {
  const { setActiveView } = useUiStore();

  useEffect(() => {
    const timer = setTimeout(() => {}, 50);
    return () => clearTimeout(timer);
  }, []);

  const chartData = CHART_DATA.map((d) => ({
    name: d.name,
    value: Math.abs(d.value),
    display: d.display,
    fill: d.color,
    signed: d.value,
  }));

  return (
    <div className="h-full overflow-auto px-9 py-7">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-6 flex flex-wrap items-end gap-3.5">
          <div>
            <div className="text-2xl font-extrabold tracking-tight">Run Overview</div>
            <div className="mt-1 text-[13px] text-[var(--text-sec)]">
              EMEA-IRD-Rates · 2026-06-16 (T+0) · 412 trades · Run #{RUN_NUMBER}
            </div>
          </div>
          <Button
            variant="outline"
            className="ml-auto"
            onClick={() => setActiveView("workspace")}
          >
            ↩ Back to Workspace
          </Button>
        </div>

        <div className="mb-5 grid grid-cols-4 gap-4 max-[1100px]:grid-cols-2">
          <KpiCard icon="💷" label="Total P&L" value="+$1.45M" delta="▲ +$212k vs T-1" deltaType="up" valueClass="val-pos" />
          <KpiCard icon="🎯" label="Coverage" value="98.4%" delta="▼ 0.6% below tolerance" deltaType="down" />
          <KpiCard icon="⚠️" label="Flags" value="3" delta="2 threshold · 1 review" deltaType="flat" valueClass="val-warn" />
          <KpiCard icon="⏱️" label="Run Time" value="1m 42s" delta="▲ 18s faster vs avg" deltaType="up" />
        </div>

        <div className="grid grid-cols-[1.4fr_1fr] gap-4 max-[1100px]:grid-cols-1">
          <PanelCard title="P&L Attribution by Greek" tag="actual vs predicted" icon="📊">
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "var(--text-dim)" }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                      fontSize: 11,
                    }}
                    formatter={(_v, _n, item) => [
                      (item.payload as { display: string }).display,
                      "P&L",
                    ]}
                  />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} animationDuration={600}>
                    {chartData.map((entry) => (
                      <Cell key={entry.name} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-3.5 flex justify-center gap-4">
              <LegendItem color="var(--cyan)" label="Directional" />
              <LegendItem color="var(--violet)" label="Volatility" />
              <LegendItem color="var(--error)" label="Decay / convexity" />
            </div>
          </PanelCard>

          <PanelCard title="Variance vs Threshold" tag="$25k limit" icon="📐">
            <div className="flex flex-col gap-2.5">
              {VARIANCE_BARS.map((g) => (
                <div key={g.name} className="flex items-center gap-3">
                  <div className="w-[54px] shrink-0 text-[12px] font-semibold">{g.name}</div>
                  <div className="relative h-2 flex-1 overflow-hidden rounded-[5px] bg-[var(--card-2)]">
                    <div
                      className="h-full rounded-[5px] transition-all duration-700"
                      style={{
                        width: `${g.pct}%`,
                        background:
                          g.pct > 50 ? "var(--warning)" : g.value < 0 ? "var(--success)" : "var(--success)",
                      }}
                    />
                  </div>
                  <div
                    className={cn(
                      "w-[76px] shrink-0 text-right font-mono text-[11px]",
                      g.pct > 50 ? "val-warn" : g.value < 0 ? "val-neg" : "val-pos",
                    )}
                  >
                    {g.display}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-[10px] border border-[rgba(251,113,133,0.2)] bg-[rgba(251,113,133,0.08)] p-3 text-[11.5px] text-[var(--text-sec)]">
              <strong className="text-[var(--error)]">Residual -$18.9k</strong> — unexplained,
              probable cross-gamma. Annotate before sign-off.
            </div>
          </PanelCard>
        </div>

        <div className="mt-4">
          <PanelCard title="Run Activity" tag="live trace" icon="📋">
            <div className="flex flex-col">
              {ACTIVITY_FEED.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 border-b border-[var(--border)] py-3 last:border-b-0"
                >
                  <div
                    className="relative mt-1 h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ background: item.color }}
                  />
                  <div className="flex-1">
                    <div className="text-[12px] font-semibold text-[var(--text-pri)]">
                      {item.title}
                    </div>
                    <div className="mt-0.5 font-mono text-[10px] text-[var(--text-dim)]">
                      {item.meta}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </PanelCard>
        </div>
      </div>
    </div>
  );
}

function KpiCard({
  icon,
  label,
  value,
  delta,
  deltaType,
  valueClass,
}: {
  icon: string;
  label: string;
  value: string;
  delta: string;
  deltaType: "up" | "down" | "flat";
  valueClass?: string;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)] p-[18px] shadow-[var(--shadow-sm)] transition-all hover:-translate-y-[3px] hover:shadow-[var(--shadow)]">
      <div className="absolute -top-[30px] -right-[30px] h-[90px] w-[90px] rounded-full bg-[var(--grad-glow)] blur-[8px]" />
      <div className="relative mb-3 flex items-center gap-2">
        <div className="flex h-[34px] w-[34px] items-center justify-center rounded-[10px] border border-[var(--border)] bg-[var(--grad-glow)] text-base">
          {icon}
        </div>
        <div className="text-[11px] font-semibold tracking-[0.05em] text-[var(--text-dim)] uppercase">
          {label}
        </div>
      </div>
      <div className={cn("relative font-mono text-[28px] font-extrabold tracking-tight", valueClass)}>
        {value}
      </div>
      <div
        className={cn(
          "relative mt-1 flex items-center gap-1 text-[11px]",
          deltaType === "up" && "val-pos",
          deltaType === "down" && "val-neg",
          deltaType === "flat" && "text-[var(--text-dim)]",
        )}
      >
        {delta}
      </div>
    </div>
  );
}

function PanelCard({
  title,
  tag,
  icon,
  children,
}: {
  title: string;
  tag: string;
  icon: string;
  children: React.ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)] shadow-[var(--shadow-sm)]">
      <div className="flex items-center gap-2 border-b border-[var(--border)] px-[18px] py-3.5">
        <div className="flex h-7 w-7 items-center justify-center rounded-[10px] border border-[var(--border)] bg-[var(--grad-glow)] text-sm">
          {icon}
        </div>
        <div className="text-[13px] font-bold">{title}</div>
        <div className="ml-auto font-mono text-[10px] text-[var(--text-dim)]">{tag}</div>
      </div>
      <div className="p-[18px]">{children}</div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5 text-[11px] text-[var(--text-sec)]">
      <div className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      {label}
    </div>
  );
}
