import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { generateMockReply, SYSTEM_PROMPT } from "@/lib/chat";

const chatBodySchema = z.object({
  sessionId: z.string(),
  message: z.string().min(1),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      }),
    )
    .optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = chatBodySchema.parse(await req.json());
    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (apiKey) {
      const messages = [
        ...(body.history ?? []),
        { role: "user" as const, content: body.message },
      ];

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages,
        }),
      });

      if (response.ok) {
        const data = (await response.json()) as {
          content?: { type: string; text?: string }[];
          usage?: { input_tokens?: number; output_tokens?: number };
        };
        const reply =
          data.content
            ?.filter((b) => b.type === "text")
            .map((b) => b.text ?? "")
            .join("\n") ?? generateMockReply(body.message);

        return NextResponse.json({
          reply,
          usage: {
            input_tokens: data.usage?.input_tokens ?? Math.ceil(body.message.length / 4),
            output_tokens: data.usage?.output_tokens ?? Math.ceil(reply.length / 4),
          },
        });
      }
    }

    const reply = generateMockReply(body.message);
    const inputTokens = Math.ceil(body.message.length / 4);
    const outputTokens = Math.ceil(reply.length / 4);

    return NextResponse.json({
      reply,
      usage: { input_tokens: inputTokens, output_tokens: outputTokens },
    });
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}
