"""
FOBO Dashboard — browser UI for reconciliation run results.

  uvicorn src.dashboard_app:app --host 127.0.0.1 --port 8080
  Open: http://127.0.0.1:8080
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from src.cycle import run_recon_cycle
from src.mcp_server import get_exceptions, reload_rules

ROOT = Path(__file__).parent.parent
STATIC = ROOT / "static"

app = FastAPI(title="FOBO Reconciliation Dashboard", version="1.0.0")

if STATIC.is_dir():
    app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


class RunRequest(BaseModel):
    trade_date: str = "2025-05-19"
    book: str = "ALL"
    file_exceptions: bool = True


@app.get("/", response_class=HTMLResponse)
async def dashboard_page():
    html = STATIC / "dashboard.html"
    if html.is_file():
        return HTMLResponse(html.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>FOBO Dashboard</h1><p>static/dashboard.html missing</p>")


@app.post("/api/run")
async def api_run(body: RunRequest):
    return run_recon_cycle(
        body.trade_date,
        body.book,
        file_exceptions=body.file_exceptions,
        clear_exceptions=True,
    )


@app.get("/api/run")
async def api_run_get(
    trade_date: str = Query("2025-05-19"),
    book: str = Query("ALL"),
    file_exceptions: bool = Query(True),
):
    return run_recon_cycle(trade_date, book, file_exceptions=file_exceptions)


@app.get("/api/exceptions")
async def api_exceptions(severity_filter: str = Query("ALL")):
    return get_exceptions(severity_filter=severity_filter)


@app.post("/api/reload-rules")
async def api_reload_rules():
    return reload_rules()
