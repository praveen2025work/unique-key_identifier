"""
Data Access Layer.

Local:  reads JSON files in data/
Prod:   replace each method body with SQLAlchemy / cx_Oracle query.
        Set DATABASE_URL in .env: oracle+cx_oracle://user:pass@host:1521/ORCL

The interface contract (method signatures) stays the same — only the bodies change.
"""
import json
import os
from pathlib import Path
from typing import Optional

from src.models import FoTrade, BoSettlement


class DataLayer:

    def __init__(self, data_dir: str = "data/"):
        self.data_dir = Path(data_dir)

    # ── FO positions ───────────────────────────────────────────────────────────

    def get_fo_trades(
        self,
        trade_date: str,
        book: str = "ALL"
    ) -> list[FoTrade]:
        """
        Load FO trades for a given date + book.

        Oracle equivalent:
          SELECT * FROM FO_TRADE_POSITIONS
          WHERE TRADE_DATE = TO_DATE(:trade_date, 'YYYY-MM-DD')
          AND (:book = 'ALL' OR BOOK = :book)
          AND STATUS IN ('CONFIRMED', 'PENDING')
        """
        with open(self.data_dir / "fo_trades.json", encoding="utf-8") as f:
            raw = json.load(f)

        trades = [
            FoTrade(**t)
            for t in raw["trades"]
            if t["trade_date"] == trade_date
        ]
        if book != "ALL":
            trades = [t for t in trades if t.book == book]
        return trades

    # ── BO settlements ─────────────────────────────────────────────────────────

    def get_bo_settlements(self, trade_date: str) -> list[BoSettlement]:
        """
        Load BO settlements for a given original trade date.

        Oracle equivalent:
          SELECT * FROM BO_SETTLEMENT_RECORDS
          WHERE TRADE_DATE = TO_DATE(:trade_date, 'YYYY-MM-DD')
        """
        with open(self.data_dir / "bo_settlements.json", encoding="utf-8") as f:
            raw = json.load(f)

        return [
            BoSettlement(**s)
            for s in raw["settlements"]
            if s["trade_date"] == trade_date
        ]

    # ── Exception persistence ──────────────────────────────────────────────────

    def save_exception(self, exc: dict) -> None:
        """
        Persist exception to TB-BB Exception Hub.

        Oracle equivalent:
          INSERT INTO FOBO_EXCEPTIONS (EXCEPTION_ID, TRADE_ID, BREAK_TYPE, ...)
          VALUES (:exc_id, :trade_id, :break_type, ...)
        """
        # Local: no-op (exceptions held in mcp_server memory dict)
        pass

    def get_exceptions(
        self,
        trade_date: Optional[str] = None,
        severity: Optional[str] = None
    ) -> list[dict]:
        """
        Oracle equivalent:
          SELECT * FROM FOBO_EXCEPTIONS
          WHERE TRADE_DATE = :trade_date
          AND (:severity IS NULL OR SEVERITY = :severity)
          AND STATUS = 'OPEN'
        """
        return []  # Local: mcp_server manages in-memory store
