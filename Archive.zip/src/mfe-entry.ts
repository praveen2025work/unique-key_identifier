/** Module Federation remote entry stub */
export { WorkspaceShell as default } from "./components/layout/workspace-shell";
