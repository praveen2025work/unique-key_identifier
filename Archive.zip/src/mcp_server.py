"""
FOBO MCP Server — FastMCP-based.

Run modes:
  stdio (Claude Desktop / Claude Code):
      python src/mcp_server.py

  SSE / HTTP (office network, AOF, uvicorn):
      uvicorn src.mcp_server:app --host 0.0.0.0 --port 8000
      AOF / Agent One Finance connects to: http://<host>:8000/sse
"""
import sys
import uuid
import logging
from datetime import date
from pathlib import Path
from typing import Optional

# Ensure project root on path when called directly
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp.server.fastmcp import FastMCP

from src.models import FoTrade, BoSettlement
from src.rules_engine import RulesEngine
from src.reconciler import FoboReconciler
from src.data_layer import DataLayer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("fobo-mcp")

# ── Singletons ─────────────────────────────────────────────────────────────────
rules_engine = RulesEngine("config/fobo_rules.json")
reconciler   = FoboReconciler(rules_engine)
data_layer   = DataLayer("data/")

# In-memory exception store (local dev). Replace with Oracle INSERT in prod.
_exceptions: dict[str, dict] = {}

# ── FastMCP Server ─────────────────────────────────────────────────────────────
mcp = FastMCP(
    name="FOBO Reconciliation Agent",
    instructions="""
You are the FOBO Reconciliation Agent for Barclays Equity desks.

Execution order for a full recon cycle:
1. reconcile_all(trade_date, book)   — runs ALL matching in one call
2. For each result with severity HIGH or MEDIUM → create_exception(...)
3. Skip CLEAN matches and AUTO_RESOLVE breaks
4. generate_report(trade_date) at the very end

Constraints:
- MISSING_IN_BO always requires an exception — never skip
- STATUS_MISMATCH with auto_resolvable=true can be skipped
- All thresholds come from rules config — do not infer values
- If counterparty is in escalation list → always P1 priority
""",
)


# ── Tool 1: reconcile_all ──────────────────────────────────────────────────────
@mcp.tool()
def reconcile_all(trade_date: str, book: str = "ALL") -> dict:
    """
    Run the complete FOBO reconciliation for a trade date and book scope.
    Loads FO + BO data, matches on trade_ref, classifies every break,
    and returns full results with severities and PnL impacts.
    Business rules loaded from config/fobo_rules.json based on book.

    ALWAYS call this first. Then call create_exception for each HIGH/MEDIUM break.

    Args:
        trade_date: Trade date in YYYY-MM-DD format
        book: Book scope — "ALL" for all desks, or "EQ-DESK-A", "EQ-DESK-B", "EQ-DESK-C"
    """
    fo_trades    = data_layer.get_fo_trades(trade_date=trade_date, book=book)
    bo_settlements = data_layer.get_bo_settlements(trade_date=trade_date)

    fo_map    = {t.trade_id: t for t in fo_trades}
    bo_by_ref = {s.trade_ref: s for s in bo_settlements if s.trade_ref}
    bo_orphans = [s for s in bo_settlements if not s.trade_ref]

    results = []

    for fo_id, fo in fo_map.items():
        bo     = bo_by_ref.get(fo_id)
        result = reconciler.match_and_classify(fo=fo, bo=bo, book=fo.book)
        results.append(result.model_dump())

    for bo in bo_orphans:
        result = reconciler.match_and_classify(fo=None, bo=bo, book=book)
        results.append(result.model_dump())

    breaks = [r for r in results if r["break_type"] != "MATCH"]
    total_pnl = sum(r["pnl_impact"] for r in results)

    applied_rule = rules_engine.resolve(book=fo_trades[0].book if fo_trades else "EQ-DESK-ALL")

    return {
        "status": "ok",
        "trade_date": trade_date,
        "rule_set_applied": applied_rule.name if applied_rule else "none",
        "summary": {
            "total_fo":       len(fo_trades),
            "total_bo":       len(bo_settlements),
            "clean_matches":  len(results) - len(breaks),
            "total_breaks":   len(breaks),
            "high":           len([r for r in breaks if r["severity"] == "HIGH"]),
            "medium":         len([r for r in breaks if r["severity"] == "MEDIUM"]),
            "low":            len([r for r in breaks if r["severity"] == "LOW"]),
            "total_pnl_impact": round(total_pnl, 2),
        },
        "results": results,
    }


# ── Tool 2: create_exception ───────────────────────────────────────────────────
@mcp.tool()
def create_exception(
    trade_id: str,
    break_type: str,
    severity: str,
    pnl_impact: float,
    counterparty: str,
    book: str,
    description: str,
) -> dict:
    """
    Create an exception record in the TB-BB Exception Hub for a detected break.
    Call this for every HIGH and MEDIUM severity break from reconcile_all results.
    Do NOT call for CLEAN matches or auto_resolvable=true breaks.

    Args:
        trade_id:     FO trade ID (e.g. TRD-001) or BO settlement ID (e.g. SET-005)
        break_type:   PRICE_BREAK | QTY_BREAK | MISSING_IN_BO | MISSING_IN_FO | MULTI_BREAK | STATUS_MISMATCH
        severity:     HIGH | MEDIUM | LOW
        pnl_impact:   Dollar PnL impact (0 if not applicable)
        counterparty: Counterparty name from the trade
        book:         Trading book e.g. EQ-DESK-A
        description:  Human-readable break description from reconcile_all recommended_action
    """
    rule_set = rules_engine.resolve(book=book)
    if not rule_set:
        return {"status": "error", "message": f"No rule set found for book={book}"}

    exc_priority = rules_engine.escalation_priority(rule_set, pnl_impact, counterparty)
    sla_hrs      = rule_set.sla_hours.get(exc_priority, 24)

    if severity == "HIGH" or counterparty in rule_set.escalation_counterparties:
        assignee = rule_set.escalation_group
    elif break_type in ("MISSING_IN_BO", "MISSING_IN_FO"):
        assignee = rule_set.settlement_desk
    else:
        assignee = rule_set.settlement_desk

    exc_id = f"EXC-{date.today().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"

    exc = {
        "exception_id":  exc_id,
        "trade_id":      trade_id,
        "break_type":    break_type,
        "severity":      severity,
        "priority":      exc_priority,
        "pnl_impact":    round(pnl_impact, 2),
        "counterparty":  counterparty,
        "book":          book,
        "description":   description,
        "status":        "OPEN",
        "sla_hours":     sla_hrs,
        "assignee_group": assignee,
        "created_date":  date.today().isoformat(),
        "rule_set":      rule_set.name,
    }

    _exceptions[exc_id] = exc
    data_layer.save_exception(exc)

    return {"status": "created", "exception": exc}


# ── Tool 3: get_exceptions ─────────────────────────────────────────────────────
@mcp.tool()
def get_exceptions(severity_filter: str = "ALL") -> dict:
    """
    Retrieve all open exceptions created in this session.
    Use before generate_report to review what will be in the report.

    Args:
        severity_filter: "ALL" | "HIGH" | "MEDIUM" | "LOW"
    """
    excs = list(_exceptions.values())
    if severity_filter != "ALL":
        excs = [e for e in excs if e["severity"] == severity_filter]

    return {
        "count": len(excs),
        "total_pnl_at_risk": round(sum(e["pnl_impact"] for e in excs), 2),
        "exceptions": excs,
    }


# ── Tool 4: reload_rules ───────────────────────────────────────────────────────
@mcp.tool()
def reload_rules() -> dict:
    """
    Hot-reload business rules from config/fobo_rules.json without restarting the server.
    Call this immediately after the BRD team updates the rules config file.
    New rules take effect on the next reconcile_all call.
    """
    count = rules_engine.reload()
    summaries = [
        {"id": rs.rule_set_id, "name": rs.name, "book": rs.book_pattern, "priority": rs.priority}
        for rs in rules_engine._rule_sets
    ]
    return {
        "status": "reloaded",
        "rule_sets_loaded": count,
        "rule_sets": summaries,
    }


# ── Tool 5: generate_report ────────────────────────────────────────────────────
@mcp.tool()
def generate_report(trade_date: str, format: str = "SUMMARY") -> dict:
    """
    Generate the final reconciliation report. ALWAYS call this last.
    Publishes results to TB-BB Exception Hub.

    Args:
        trade_date: Trade date YYYY-MM-DD
        format:     "SUMMARY" | "DETAILED" | "EXCEPTION_HUB"
    """
    excs = list(_exceptions.values())
    total_pnl = sum(e["pnl_impact"] for e in excs)

    by_type: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    for e in excs:
        by_type[e["break_type"]]   = by_type.get(e["break_type"], 0) + 1
        by_priority[e["priority"]] = by_priority.get(e["priority"], 0) + 1

    report = {
        "report_id":     f"RPT-{date.today().strftime('%Y%m%d')}-FOBO-EQ",
        "trade_date":    trade_date,
        "generated_at":  date.today().isoformat(),
        "status":        "COMPLETE",
        "published_to":  "TB-BB Exception Hub",
        "format":        format,
        "summary": {
            "total_exceptions":  len(excs),
            "by_priority":       by_priority,
            "by_break_type":     by_type,
            "total_pnl_at_risk": round(total_pnl, 2),
        },
    }
    if format in ("DETAILED", "EXCEPTION_HUB"):
        report["exceptions"] = excs

    return report


# ── FastAPI app for SSE/HTTP mode (uvicorn) ────────────────────────────────────
# Use: uvicorn src.mcp_server:app --host 0.0.0.0 --port 8000
app = mcp.sse_app()

if __name__ == "__main__":
    # stdio mode — used by Claude Desktop, Claude Code, and direct tool testing
    logger.info("Starting FOBO MCP server in stdio mode...")
    mcp.run()
