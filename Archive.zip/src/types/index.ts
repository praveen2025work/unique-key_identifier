export type AppView = "workspace" | "pipeline" | "overview";
export type PanelTab = "exec" | "source" | "data" | "files";
export type StepStatus = "complete" | "active" | "pending";

export interface WorkflowStep {
  id: string;
  order: number;
  icon: string;
  label: string;
  subtitle: string;
  status: StepStatus;
  statusLabel: string;
  engine?: string;
  metrics?: { label: string; value: string; variant?: "pos" | "neg" | "warn" }[];
}

export interface GreekRow {
  greek: string;
  actual: string;
  predicted: string;
  variance: string;
  status: "ok" | "warn" | "err";
  statusLabel: string;
}

export interface TraceItem {
  time: string;
  icon: string;
  tool: string;
  detail: string;
  duration: string;
}

export interface SourceFile {
  id: string;
  name: string;
  icon: string;
  section: string;
  language: string;
  meta: string[];
  code: string;
}

export interface WorkflowFile {
  id: string;
  icon: string;
  name: string;
  type: string;
  typeClass: "py" | "sql" | "data" | "cfg" | "log";
  stats: string[];
  group: "inputs" | "outputs" | "artifacts";
  badge?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  tag?: string;
}

export interface Finding {
  id: string;
  level: "warn" | "ok" | "err" | "info";
  label: string;
  text: string;
  value?: string;
}

export interface ModelInfo {
  id: string;
  bedrock_id: string;
  name: string;
  description: string;
}

export interface ModelsResponse {
  models: ModelInfo[];
  default: string;
}

export interface Session {
  id: string;
  agent_type: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface SessionsResponse {
  sessions: Session[];
}

export interface SessionStatsPayload {
  input_tokens?: number;
  output_tokens?: number;
  total_tokens?: number;
  cost?: number;
  total_cost?: number;
  running?: boolean;
  plugin_active?: boolean;
}

export interface SessionStats {
  session_id: string;
  stats: SessionStatsPayload;
}

export interface PluginActivationResponse {
  message: string;
  session_id: string;
  plugin_id: string;
  plugin_name: string;
  display_name: string;
}

export interface UploadResponse {
  id: string;
  filename: string;
  status: string;
  message: string;
  s3_key: string;
  estimated_time: string;
  processing_status: string;
}

export interface DocumentItem {
  id: string;
  document_id: string;
  filename: string;
  original_filename: string;
  content_type: string;
  file_size: number;
  processing_status: string;
  created_at: string;
  document_type: string;
  s3_key: string;
}

export interface DocumentsResponse {
  session_id: string;
  input_documents: DocumentItem[];
  output_artifacts: DocumentItem[];
}

export interface MessagesResponse {
  session_id: string;
  messages: ChatMessage[];
  total: number;
}

export interface ActionItem {
  id: string;
  category: string;
  label: string;
  description: string;
  icon: string;
  message: string;
}

export interface ActionCategory {
  category: string;
  actions: ActionItem[];
}

export interface TelemetryState {
  model: string;
  tokensIn: number;
  tokensOut: number;
  cost: number;
  running: boolean;
}

export interface ChatRequest {
  sessionId: string;
  message: string;
  history?: { role: "user" | "assistant"; content: string }[];
}

export interface ChatResponse {
  reply: string;
  usage?: { input_tokens: number; output_tokens: number };
}
