import type {
  Finding,
  GreekRow,
  SourceFile,
  TraceItem,
  WorkflowFile,
  WorkflowStep,
} from "@/types";

export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    id: "pnl-prep",
    order: 1,
    icon: "✓",
    label: "PnL Prep",
    subtitle: "Source validation · Trade load",
    status: "complete",
    statusLabel: "Done",
    engine: "pnl_prep.py",
    metrics: [
      { label: "Trades loaded", value: "412" },
      { label: "Source errors", value: "0" },
    ],
  },
  {
    id: "fobo-rec",
    order: 2,
    icon: "✓",
    label: "FOBO Rec",
    subtitle: "Front / back matching",
    status: "complete",
    statusLabel: "Done",
    engine: "fobo_match.py",
    metrics: [
      { label: "Matched", value: "408" },
      { label: "Breaks", value: "4", variant: "warn" },
    ],
  },
  {
    id: "pl-explains",
    order: 3,
    icon: "📊",
    label: "PL Explains",
    subtitle: "Risk attribution · Greeks",
    status: "active",
    statusLabel: "Live",
    engine: "greeks_decomp.py",
    metrics: [
      { label: "Coverage", value: "98.4%", variant: "pos" },
      { label: "Unexplained", value: "-$18.9k", variant: "neg" },
    ],
  },
  {
    id: "flash-formal",
    order: 4,
    icon: "⚡",
    label: "Flash vs Formal",
    subtitle: "Variance analysis",
    status: "pending",
    statusLabel: "Queued",
    engine: "variance_check.py",
    metrics: [
      { label: "Variance", value: "—" },
      { label: "Tolerance", value: "—" },
    ],
  },
  {
    id: "adjustments",
    order: 5,
    icon: "🔧",
    label: "Adjustments",
    subtitle: "Manual overrides · EOD",
    status: "pending",
    statusLabel: "Queued",
    engine: "eod_adjust.py",
    metrics: [
      { label: "Manual", value: "—" },
      { label: "Auto", value: "—" },
    ],
  },
  {
    id: "sign-off",
    order: 6,
    icon: "✍️",
    label: "Sign-Off",
    subtitle: "Controller approval",
    status: "pending",
    statusLabel: "Queued",
    engine: "controller_approve",
    metrics: [
      { label: "Approver", value: "—" },
      { label: "Status", value: "—" },
    ],
  },
];

export const ACTIVE_STEP_ID = "pl-explains";

export const TRACE_ITEMS: TraceItem[] = [
  {
    time: "08:04:01",
    icon: "🗄",
    tool: "databricks_query",
    detail: "pl_explains_engine.sql",
    duration: "0.8s",
  },
  {
    time: "08:04:02",
    icon: "🐍",
    tool: "python_exec",
    detail: "greeks_decomp.py — 412 trades",
    duration: "1.4s",
  },
  {
    time: "08:04:03",
    icon: "🔍",
    tool: "validate_schema",
    detail: "explains_output.parquet",
    duration: "0.2s",
  },
  {
    time: "08:04:04",
    icon: "📤",
    tool: "write_delta",
    detail: "finance.pnl.explains",
    duration: "0.8s",
  },
];

export const GREEKS_SUMMARY: GreekRow[] = [
  {
    greek: "Delta",
    actual: "+$1,248,300",
    predicted: "+$1,220,000",
    variance: "+$28,300",
    status: "warn",
    statusLabel: "⚠ Threshold",
  },
  {
    greek: "Gamma",
    actual: "-$42,100",
    predicted: "-$40,800",
    variance: "-$1,300",
    status: "ok",
    statusLabel: "✓ Within",
  },
  {
    greek: "Vega",
    actual: "+$318,700",
    predicted: "+$295,000",
    variance: "+$23,700",
    status: "warn",
    statusLabel: "⚠ Threshold",
  },
  {
    greek: "Theta",
    actual: "-$87,400",
    predicted: "-$88,100",
    variance: "+$700",
    status: "ok",
    statusLabel: "✓ Within",
  },
  {
    greek: "Rho",
    actual: "+$14,200",
    predicted: "+$13,800",
    variance: "+$400",
    status: "ok",
    statusLabel: "✓ Within",
  },
];

export const SOURCE_FILES: SourceFile[] = [
  {
    id: "greeks",
    name: "greeks_decomp.py",
    icon: "🐍",
    section: "Engine",
    language: "Python",
    meta: ["Python 3.11", "128 lines", "commit 4f2a91c", "modified 08:01 BST"],
    code: `# Greeks decomposition — deterministic engine
# No LLM calls in the compute path (audit constraint)
import pandas as pd

GREEKS = ['delta', 'gamma', 'vega', 'theta', 'rho']
TOLERANCE = 25_000   # per-greek variance threshold (GBP)

def compute_pl_explains(trades_df, market_data, actual_pnl):
    explained = {}
    for greek in GREEKS:
        s = trades_df[f'{greek}_sensitivity']
        m = market_data[f'{greek}_move']
        explained[greek] = (s * m).sum()

    total = sum(explained.values())
    unexplained = actual_pnl - total
    return {
        'explains': explained,
        'unexplained': unexplained,
        'coverage_pct': total / actual_pnl * 100,
        'breaches': [g for g, v in explained.items()
                     if abs(v) > TOLERANCE]
    }`,
  },
  {
    id: "loader",
    name: "market_data_loader.py",
    icon: "🐍",
    section: "Engine",
    language: "Python",
    meta: ["Python 3.11", "74 lines", "commit 4f2a91c", "modified 07:58 BST"],
    code: `# Loads EOD market moves from Databricks Delta
from databricks import sql

def load_market_moves(book, as_of):
    q = f"""
        SELECT greek, bucket, move_bp, ccy
        FROM finance.market.eod_moves
        WHERE book = '{book}' AND as_of = '{as_of}'
    """
    with sql.connect(**CONN) as c:
        df = pd.read_sql(q, c)
    return df.pivot_table(index='bucket',
                          columns='greek',
                          values='move_bp')`,
  },
  {
    id: "sql",
    name: "pl_explains_engine.sql",
    icon: "🗄",
    section: "Query",
    language: "SQL",
    meta: ["Databricks SQL", "41 lines", "commit 4f2a91c", "modified 07:46 BST"],
    code: `-- Trade-level sensitivities for PL Explains
SELECT
    t.trade_id,
    t.delta_sensitivity,
    t.gamma_sensitivity,
    t.vega_sensitivity,
    t.theta_sensitivity,
    t.rho_sensitivity,
    t.actual_pnl
FROM finance.pnl.trades t
JOIN finance.pnl.fobo_matched f
  ON t.trade_id = f.trade_id
WHERE t.book = 'EMEA-IRD-Rates'
  AND t.as_of = '2026-06-16'
  AND f.match_status = 'MATCHED';`,
  },
  {
    id: "cfg",
    name: "explains_config.yaml",
    icon: "⚙",
    section: "Config",
    language: "YAML",
    meta: ["YAML", "22 lines", "commit 4f2a91c", "modified 07:30 BST"],
    code: `book: EMEA-IRD-Rates
as_of: 2026-06-16
tolerances:
  per_greek_gbp: 25000
  coverage_pct_min: 99.0
  unexplained_gbp: 20000
greeks:
  - delta
  - gamma
  - vega
  - theta
  - rho
output:
  table: finance.pnl.explains
  format: delta
audit:
  llm_in_compute_path: false   # hard constraint`,
  },
];

export const WORKFLOW_FILES: WorkflowFile[] = [
  {
    id: "trades",
    icon: "🗃️",
    name: "trades_emea_ird.parquet",
    type: "parquet",
    typeClass: "data",
    stats: ["412 rows", "2.4 MB", "07:46 BST"],
    group: "inputs",
  },
  {
    id: "market",
    icon: "🌍",
    name: "market_data_2026_06_16.parquet",
    type: "parquet",
    typeClass: "data",
    stats: ["86 rows", "412 KB", "07:50 BST"],
    group: "inputs",
  },
  {
    id: "config",
    icon: "⚙️",
    name: "explains_config.yaml",
    type: "yaml",
    typeClass: "cfg",
    stats: ["22 lines", "1.1 KB", "07:30 BST"],
    group: "inputs",
  },
  {
    id: "explains-out",
    icon: "📊",
    name: "explains_2026_06_16.parquet",
    type: "parquet",
    typeClass: "data",
    stats: ["5 rows", "38 KB", "08:04 BST"],
    group: "outputs",
    badge: "written",
  },
  {
    id: "summary-csv",
    icon: "📄",
    name: "greeks_summary.csv",
    type: "csv",
    typeClass: "data",
    stats: ["6 rows", "2 KB", "08:04 BST"],
    group: "outputs",
  },
  {
    id: "log",
    icon: "🧾",
    name: "run_2847_explains.log.json",
    type: "json",
    typeClass: "log",
    stats: ["4 tool calls", "14 KB", "08:04 BST"],
    group: "outputs",
  },
  {
    id: "greeks-py",
    icon: "🐍",
    name: "greeks_decomp.py",
    type: "python",
    typeClass: "py",
    stats: ["128 lines", "4.6 KB", "commit 4f2a91c"],
    group: "artifacts",
  },
  {
    id: "sql-artifact",
    icon: "🗄️",
    name: "pl_explains_engine.sql",
    type: "sql",
    typeClass: "sql",
    stats: ["41 lines", "1.4 KB", "commit 4f2a91c"],
    group: "artifacts",
  },
];

export const INITIAL_FINDINGS: Finding[] = [
  {
    id: "delta",
    level: "warn",
    label: "⚠ Delta Variance",
    text: "3bp EUR rate move in 5Y bucket post-ECB commentary at 14:30 CET is the probable driver.",
    value: "Actual +$1,248,300 · Pred +$1,220,000 · Δ +$28,300",
  },
  {
    id: "vega",
    level: "warn",
    label: "⚠ Vega Variance",
    text: "EUR 2Y×5Y swaption vol surface re-priced +8 bps intraday.",
    value: "Actual +$318,700 · Pred +$295,000 · Δ +$23,700",
  },
  {
    id: "residual",
    level: "err",
    label: "✗ Unexplained Residual",
    text: "-$18,900 likely from cross-gamma; not captured in first-order approximation.",
    value: "Coverage 98.4% · Tolerance 99.0%",
  },
];

export const SUGGESTED_ACTIONS = [
  "Annotate Delta variance — reference ECB rate move at 14:30 CET.",
  "Flag -$18,900 residual in FC notes as probable cross-gamma.",
  "Vega overshoot acceptable — document vol surface shift in sign-off.",
];

export const QUICK_PROMPTS = [
  "Why is Vega above threshold?",
  "Explain the unexplained residual",
  "Draft sign-off commentary",
  "Compare to T-1",
];

export const SESSION_META = {
  id: "7f3a-d91e",
  started: "08:03:21 BST",
  book: "EMEA-IRD-Rates",
};

export const CHART_DATA = [
  { name: "Delta", value: 1.25, display: "$1.25M", color: "var(--cyan)" },
  { name: "Gamma", value: -0.042, display: "-$42k", color: "var(--error)" },
  { name: "Vega", value: 0.319, display: "$319k", color: "var(--violet)" },
  { name: "Theta", value: -0.087, display: "-$87k", color: "var(--error)" },
  { name: "Rho", value: 0.014, display: "$14k", color: "var(--success)" },
];

export const VARIANCE_BARS = [
  { name: "Delta", value: 28.3, display: "+$28.3k", pct: 92 },
  { name: "Vega", value: 23.7, display: "+$23.7k", pct: 78 },
  { name: "Theta", value: 0.7, display: "+$0.7k", pct: 6 },
  { name: "Rho", value: 0.4, display: "+$0.4k", pct: 3 },
  { name: "Gamma", value: -1.3, display: "-$1.3k", pct: 9 },
];

export const ACTIVITY_FEED = [
  {
    id: "1",
    color: "var(--cyan)",
    title: "PL Explains running — Greeks decomposition on 412 trades",
    meta: "08:04:01 · agent · 4 tool calls · 3.2s",
  },
  {
    id: "2",
    color: "var(--success)",
    title: "FOBO Rec complete — 408 matched, 4 breaks flagged",
    meta: "08:03:48 · agent · auto-resolved 0",
  },
  {
    id: "3",
    color: "var(--success)",
    title: "PnL Prep complete — 412 trades loaded, 0 source errors",
    meta: "08:03:21 · agent · source validation passed",
  },
  {
    id: "4",
    color: "var(--violet)",
    title: "Run #2847 initialised — EMEA-IRD-Rates book",
    meta: "08:03:18 · scheduler · T+0 production cycle",
  },
];

export const EXEC_CODE_SNIPPET = `# Greeks decomposition — deterministic engine
def compute_pl_explains(trades_df, market_data):
    explained = {}
    for greek in ['delta', 'gamma', 'vega', 'theta', 'rho']:
        sensitivity = trades_df[f'{greek}_sensitivity']
        market_move = market_data[f'{greek}_move']
        explained[greek] = (sensitivity * market_move).sum()

    total = sum(explained.values())
    unexplained = actual_pnl - total
    return {
        'explains': explained,
        'unexplained': unexplained,
        'coverage_pct': total / actual_pnl * 100
    }`;
