from pydantic import BaseModel
from typing import Optional, List
from enum import Enum


class BreakType(str, Enum):
    PRICE_BREAK   = "PRICE_BREAK"
    QTY_BREAK     = "QTY_BREAK"
    STATUS_MISMATCH = "STATUS_MISMATCH"
    MISSING_IN_BO = "MISSING_IN_BO"
    MISSING_IN_FO = "MISSING_IN_FO"
    MULTI_BREAK   = "MULTI_BREAK"
    MATCH         = "MATCH"


class Severity(str, Enum):
    HIGH         = "HIGH"
    MEDIUM       = "MEDIUM"
    LOW          = "LOW"
    AUTO_RESOLVE = "AUTO_RESOLVE"
    CLEAN        = "CLEAN"


class FoTrade(BaseModel):
    trade_id:    str
    instrument:  str
    symbol:      str
    quantity:    int
    price:       float
    trade_date:  str
    counterparty: str
    book:        str
    status:      str
    trader:      Optional[str] = None


class BoSettlement(BaseModel):
    settlement_id:   str
    trade_ref:       Optional[str]
    instrument:      str
    symbol:          str
    quantity:        int
    price:           float
    trade_date:      str
    settlement_date: str
    counterparty:    str
    status:          str
    nostro_account:  Optional[str] = None


class FieldBreak(BaseModel):
    field_name:  str
    fo_value:    str
    bo_value:    str
    difference:  str
    pnl_impact:  float = 0.0


class ReconResult(BaseModel):
    fo_trade_id:       Optional[str]
    bo_settlement_id:  Optional[str]
    symbol:            str
    break_type:        BreakType
    severity:          Severity
    field_breaks:      List[FieldBreak] = []
    pnl_impact:        float = 0.0
    counterparty:      str
    book:              str
    recommended_action: str
    exception_id:      Optional[str] = None
    auto_resolvable:   bool = False


class RuleSet(BaseModel):
    rule_set_id:               int
    name:                      str
    description:               Optional[str] = None
    asset_class:               str
    book_pattern:              str
    priority:                  int
    is_active:                 bool
    effective_from:            str
    effective_to:              Optional[str] = None
    thresholds:                dict
    break_severities:          dict
    auto_resolve:              List[str]
    escalation_counterparties: List[str]
    escalation_group:          str
    settlement_desk:           str
    fo_investigation:          Optional[str] = None
    sla_hours:                 dict
