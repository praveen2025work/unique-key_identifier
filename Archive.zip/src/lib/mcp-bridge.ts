/** MCP ext-apps bridge — tool-call layer for agent integrations */
export interface McpToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  status: "pending" | "running" | "complete" | "error";
  durationMs?: number;
}

export interface McpAppContext {
  sessionId: string;
  stepId: string;
  tools: McpToolCall[];
}

export function createMcpContext(sessionId: string, stepId: string): McpAppContext {
  return {
    sessionId,
    stepId,
    tools: [],
  };
}

export async function invokeMcpTool(
  ctx: McpAppContext,
  name: string,
  args: Record<string, unknown>,
): Promise<McpToolCall> {
  const call: McpToolCall = {
    id: crypto.randomUUID(),
    name,
    arguments: args,
    status: "running",
  };
  ctx.tools.push(call);

  await new Promise((r) => setTimeout(r, 200));
  call.status = "complete";
  call.durationMs = 200;

  return call;
}
