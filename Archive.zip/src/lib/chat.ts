export const SYSTEM_PROMPT = `You are Agent One, an AI assistant embedded in Barclays Markets Finance PnL Production workflow.

Current step: PL Explains — Risk Attribution (Step 3 of 6)
Book: EMEA-IRD-Rates · Date: 2026-06-16 (T+0) · Trades: 412

Greeks decomposition results:
- Delta: Actual +$1,248,300 vs Predicted +$1,220,000 → Variance +$28,300 (ABOVE $25k threshold)
- Gamma: Actual -$42,100 vs Predicted -$40,800 → Variance -$1,300 (within tolerance)
- Vega: Actual +$318,700 vs Predicted +$295,000 → Variance +$23,700 (near threshold)
- Theta: Actual -$87,400 vs Predicted -$88,100 → Variance +$700 (within tolerance)
- Rho: Actual +$14,200 vs Predicted +$13,800 → Variance +$400 (within tolerance)
- Unexplained residual: -$18,900 (coverage 98.4% vs 99.0% tolerance)

Market context: ECB commentary at 14:30 CET caused 3bp EUR rate move in 5Y bucket. EUR 2Y×5Y swaption vol surface re-priced +8 bps intraday.

Your role: Help the Finance professional understand results, draft commentary, explain variances, compare to prior days, or prepare sign-off notes. Be concise and precise.`;

export function generateMockReply(message: string): string {
  const lower = message.toLowerCase();

  if (lower.includes("vega")) {
    return "Vega variance of +$23,700 is driven by the EUR 2Y×5Y swaption vol surface re-pricing +8 bps intraday. This is just below the $25k threshold individually but combined with delta variance warrants annotation in FC notes before sign-off.";
  }
  if (lower.includes("unexplained") || lower.includes("residual")) {
    return "The -$18,900 unexplained residual likely reflects cross-gamma effects not captured in first-order greek decomposition. Coverage at 98.4% is within T+0 tolerance but below the 99.0% sign-off target — recommend flagging as probable cross-gamma in controller notes.";
  }
  if (lower.includes("sign-off") || lower.includes("commentary")) {
    return "Suggested sign-off commentary: PL Explains completed for EMEA-IRD-Rates (412 trades). Delta variance (+$28.3k) attributable to 3bp EUR 5Y move post-ECB 14:30 CET. Vega variance (+$23.7k) from vol surface shift. Unexplained -$18.9k flagged as probable cross-gamma. Coverage 98.4%.";
  }
  if (lower.includes("t-1") || lower.includes("compare")) {
    return "vs T-1: Total P&L up $212k. Delta contribution increased $45k on larger rate move. Vega variance was $8.2k yesterday vs $23.7k today — today's vol surface shift is the primary driver. Unexplained residual was -$4.1k T-1 vs -$18.9k today.";
  }

  return "Based on the PL Explains output for EMEA-IRD-Rates, two greeks (Delta and Vega) are above or near the $25k threshold. The unexplained residual of -$18,900 should be annotated before proceeding to Flash vs Formal. Would you like me to draft specific commentary for any variance?";
}
