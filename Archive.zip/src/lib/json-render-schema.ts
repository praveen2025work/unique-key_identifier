import { z } from "zod";
import { defineCatalog, type Spec } from "@json-render/core";
import { schema } from "@json-render/react/schema";
import { shadcnComponentDefinitions } from "@json-render/shadcn/catalog";
import { defineRegistry } from "@json-render/react";
import { shadcnComponents } from "@json-render/shadcn";

export const stepOutputPanelSchema = z.object({
  version: z.literal("1"),
  title: z.string().optional(),
  spec: z.custom<Spec>(),
});

export type StepOutputPanel = z.infer<typeof stepOutputPanelSchema>;

export function parseStepOutputPanel(data: unknown): StepOutputPanel | null {
  const result = stepOutputPanelSchema.safeParse(data);
  return result.success ? result.data : null;
}

const catalog = defineCatalog(schema, {
  components: {
    Card: shadcnComponentDefinitions.Card,
    Stack: shadcnComponentDefinitions.Stack,
    Text: shadcnComponentDefinitions.Text,
    Badge: shadcnComponentDefinitions.Badge,
  },
  actions: {},
});

export const { registry: jsonRenderRegistry } = defineRegistry(catalog, {
  components: {
    Card: shadcnComponents.Card,
    Stack: shadcnComponents.Stack,
    Text: shadcnComponents.Text,
    Badge: shadcnComponents.Badge,
  },
});

/** Default PL Explains panel spec matching reference design */
export const PL_EXPLAINS_PANEL: StepOutputPanel = {
  version: "1",
  title: "PL Explains — Agent Output",
  spec: {
    root: "root",
    elements: {
      root: {
        type: "Card",
        props: {
          title: "Greeks decomposition complete",
          description: "412 trades processed · 98.4% coverage",
          maxWidth: "full",
          centered: false,
        },
        children: ["body"],
      },
      body: {
        type: "Stack",
        props: { direction: "vertical", gap: "sm", align: null, justify: null },
        children: ["summary", "badges"],
      },
      summary: {
        type: "Text",
        props: {
          content: "Two greeks flag above tolerance. Unexplained residual -$18,900.",
          variant: "muted",
          size: null,
        },
        children: [],
      },
      badges: {
        type: "Stack",
        props: { direction: "horizontal", gap: "sm", align: null, justify: null },
        children: ["badge-delta", "badge-residual"],
      },
      "badge-delta": {
        type: "Badge",
        props: { label: "Delta +$28.3k variance", variant: "warning" },
        children: [],
      },
      "badge-residual": {
        type: "Badge",
        props: { label: "Unexplained -$18.9k", variant: "destructive" },
        children: [],
      },
    },
  },
};
