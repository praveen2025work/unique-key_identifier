export const DEFAULT_SESSION_ID = "c9db1973-54cd-4818-9ecd-6ad62e05e650";
export const RUN_NUMBER = 2847;

export function getApiUrl(): string {
  return process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8765";
}
