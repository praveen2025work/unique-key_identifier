"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiGet, apiPost, apiPostForm } from "@/lib/api-client";
import type {
  ActionCategory,
  ChatRequest,
  ChatResponse,
  DocumentsResponse,
  MessagesResponse,
  ModelsResponse,
  PluginActivationResponse,
  Session,
  SessionStats,
  SessionsResponse,
  UploadResponse,
} from "@/types";
import { DEFAULT_SESSION_ID } from "@/lib/env";
import { useUiStore } from "@/store/ui-store";

export const queryKeys = {
  models: ["models"] as const,
  sessions: ["sessions"] as const,
  session: (id: string) => ["session", id] as const,
  stats: (id: string) => ["stats", id] as const,
  documents: (id: string) => ["documents", id] as const,
  messages: (id: string) => ["messages", id] as const,
  actions: (id: string) => ["actions", id] as const,
};

export function useModels() {
  return useQuery({
    queryKey: queryKeys.models,
    queryFn: () => apiGet<ModelsResponse>("/api/models"),
    staleTime: 60_000,
  });
}

export function useSessions() {
  return useQuery({
    queryKey: queryKeys.sessions,
    queryFn: () => apiGet<SessionsResponse>("/api/sessions"),
    staleTime: 30_000,
  });
}

export function useSession(sessionId: string) {
  return useQuery({
    queryKey: queryKeys.session(sessionId),
    queryFn: () => apiGet<Session>(`/api/sessions/${sessionId}`),
    enabled: Boolean(sessionId),
  });
}

export function useSessionStats(sessionId: string) {
  return useQuery({
    queryKey: queryKeys.stats(sessionId),
    queryFn: () => apiGet<SessionStats>(`/api/sessions/${sessionId}/stats`),
    enabled: Boolean(sessionId),
    refetchInterval: 10_000,
  });
}

export function useSessionDocuments(sessionId: string) {
  return useQuery({
    queryKey: queryKeys.documents(sessionId),
    queryFn: () => apiGet<DocumentsResponse>(`/api/sessions/${sessionId}/documents`),
    enabled: Boolean(sessionId),
    refetchInterval: 5_000,
  });
}

export function useSessionMessages(sessionId: string) {
  return useQuery({
    queryKey: queryKeys.messages(sessionId),
    queryFn: () => apiGet<MessagesResponse>(`/api/sessions/${sessionId}/messages`),
    enabled: Boolean(sessionId),
  });
}

export function useSessionActions(sessionId: string) {
  return useQuery({
    queryKey: queryKeys.actions(sessionId),
    queryFn: () => apiGet<ActionCategory[]>(`/api/sessions/${sessionId}/actions`),
    enabled: Boolean(sessionId),
  });
}

export function useCreateSession() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body?: { title?: string; agent_type?: string }) =>
      apiPost<Session>("/api/sessions", body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.sessions });
    },
  });
}

export function useActivatePlugin(sessionId: string) {
  const pluginId = "1f79fe96-153f-4862-829e-fb14cec288e5";
  return useMutation({
    mutationFn: () =>
      apiPost<PluginActivationResponse>(
        `/api/sessions/${sessionId}/plugins/${pluginId}/activate`,
      ),
  });
}

export function useUploadFile(sessionId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (file: File) => {
      const form = new FormData();
      form.append("file", file);
      form.append("session_id", sessionId);
      form.append("async_processing", "true");
      return apiPostForm<UploadResponse>("/api/upload", form);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.documents(sessionId) });
    },
  });
}

export function useChatMutation(sessionId?: string) {
  const qc = useQueryClient();
  const effectiveSessionId = sessionId || useUiStore.getState().sessionId || DEFAULT_SESSION_ID;

  return useMutation({
    mutationFn: async (body: ChatRequest) => {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        throw new Error("Chat request failed");
      }
      return res.json() as Promise<ChatResponse>;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.messages(effectiveSessionId) });
    },
  });
}

export function useEffectiveSessionId(): string {
  const sessionId = useUiStore((s) => s.sessionId);
  return sessionId || DEFAULT_SESSION_ID;
}
