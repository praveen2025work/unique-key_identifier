import { create } from "zustand";
import type {
  AppView,
  PanelTab,
  PluginActivationResponse,
  SessionStatsPayload,
  TelemetryState,
} from "@/types";
import { ACTIVE_STEP_ID } from "@/data/workflow";

interface UiState {
  activeView: AppView;
  activePanelTab: PanelTab;
  activeStepId: string;
  selectedSourceFileId: string;
  sessionId: string;
  telemetry: TelemetryState;
  activePlugin: PluginActivationResponse | null;
  isTyping: boolean;
  setActiveView: (view: AppView) => void;
  setActivePanelTab: (tab: PanelTab) => void;
  setActiveStepId: (id: string) => void;
  setSelectedSourceFileId: (id: string) => void;
  setSessionId: (id: string) => void;
  setIsTyping: (v: boolean) => void;
  setActivePlugin: (plugin: PluginActivationResponse | null) => void;
  applySessionStats: (stats: SessionStatsPayload) => void;
  updateTelemetry: (input: number, output: number) => void;
}

const INPUT_RATE = 0.000015;
const OUTPUT_RATE = 0.000075;

export const useUiStore = create<UiState>((set, get) => ({
  activeView: "workspace",
  activePanelTab: "exec",
  activeStepId: ACTIVE_STEP_ID,
  selectedSourceFileId: "greeks",
  sessionId: "",
  activePlugin: null,
  telemetry: {
    model: "opus-4-6",
    tokensIn: 42180,
    tokensOut: 8340,
    cost: 0.38,
    running: false,
  },
  isTyping: false,
  setActiveView: (view) => set({ activeView: view }),
  setActivePanelTab: (tab) => set({ activePanelTab: tab }),
  setActiveStepId: (id) => set({ activeStepId: id }),
  setSelectedSourceFileId: (id) => set({ selectedSourceFileId: id }),
  setSessionId: (id) => set({ sessionId: id }),
  setIsTyping: (v) => set({ isTyping: v }),
  setActivePlugin: (plugin) => set({ activePlugin: plugin }),
  applySessionStats: (stats) => {
    const { telemetry } = get();
    const next: TelemetryState = { ...telemetry };

    if (typeof stats.input_tokens === "number") next.tokensIn = stats.input_tokens;
    if (typeof stats.output_tokens === "number") next.tokensOut = stats.output_tokens;
    const cost = stats.cost ?? stats.total_cost;
    if (typeof cost === "number") next.cost = cost;
    if (typeof stats.running === "boolean") next.running = stats.running;
    if (typeof stats.plugin_active === "boolean") next.running = stats.plugin_active;

    set({ telemetry: next });
  },
  updateTelemetry: (input, output) => {
    const { telemetry } = get();
    const tokensIn = telemetry.tokensIn + input;
    const tokensOut = telemetry.tokensOut + output;
    const cost = telemetry.cost + input * INPUT_RATE + output * OUTPUT_RATE;
    set({ telemetry: { ...telemetry, tokensIn, tokensOut, cost } });
  },
}));
