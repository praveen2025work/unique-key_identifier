"""
Rules Engine — loads FOBO_RECON_RULES from fobo_rules.json (BRD config).

Local:  reads JSON file
Prod:   swap load_rules() with Oracle query against FOBO_RECON_RULES table.
        Oracle DDL is in docs/oracle_schema.sql

Specificity resolution: higher priority rule_set wins.
  EQ-DESK-A (priority=10) > EQ-DESK-ALL (priority=5) > * (priority=1)
"""
import json
import logging
from pathlib import Path
from datetime import date
from typing import Optional

from src.models import RuleSet

logger = logging.getLogger(__name__)


class RulesEngine:

    def __init__(self, rules_path: str = "config/fobo_rules.json"):
        self.rules_path = Path(rules_path)
        self._rule_sets: list[RuleSet] = []
        self.load_rules()

    def load_rules(self) -> None:
        """
        Load rules from JSON. In prod replace with:
          SELECT * FROM FOBO_RECON_RULES
          WHERE IS_ACTIVE = 'Y' AND EFFECTIVE_FROM <= SYSDATE
          AND (EFFECTIVE_TO IS NULL OR EFFECTIVE_TO >= SYSDATE)
          ORDER BY PRIORITY DESC
        """
        with open(self.rules_path, encoding="utf-8") as f:
            data = json.load(f)
        self._rule_sets = [RuleSet(**rs) for rs in data["rule_sets"]]
        logger.info(f"[RulesEngine] Loaded {len(self._rule_sets)} rule sets from {self.rules_path}")

    def reload(self) -> int:
        """Hot-reload without restart. Call after BRD team updates fobo_rules.json."""
        self.load_rules()
        return len(self._rule_sets)

    def resolve(self, book: str, asset_class: str = "EQUITY") -> Optional[RuleSet]:
        """
        Find the most specific applicable rule set for book + asset class on today's date.
        Returns None if no matching active rule set found.
        """
        today = date.today().isoformat()
        candidates = [
            rs for rs in self._rule_sets
            if rs.is_active
            and rs.effective_from <= today
            and (rs.effective_to is None or rs.effective_to >= today)
            and rs.asset_class in (asset_class, "ALL")
            and self._book_matches(rs.book_pattern, book)
        ]
        if not candidates:
            return None
        return max(candidates, key=lambda rs: rs.priority)

    def _book_matches(self, pattern: str, book: str) -> bool:
        if pattern == "*":
            return True
        if pattern.endswith("*"):
            return book.startswith(pattern[:-1])
        return pattern == book

    # ── Convenience accessors ──────────────────────────────────────────────────

    def threshold(self, rule_set: RuleSet, key: str, default: float = 0.0) -> float:
        return float(rule_set.thresholds.get(key, default))

    def severity(self, rule_set: RuleSet, break_type: str) -> str:
        return rule_set.break_severities.get(break_type, "HIGH")

    def is_auto_resolvable(self, rule_set: RuleSet, break_type: str) -> bool:
        return break_type in rule_set.auto_resolve

    def escalation_priority(
        self, rule_set: RuleSet, pnl_impact: float, counterparty: str
    ) -> str:
        if counterparty in rule_set.escalation_counterparties:
            return "P1"
        if pnl_impact >= self.threshold(rule_set, "pnl_escalate_amount", 1_000_000):
            return "P1"
        if pnl_impact >= self.threshold(rule_set, "pnl_high_threshold", 10_000):
            return "P2"
        return "P3"
