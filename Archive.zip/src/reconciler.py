"""
FOBO Reconciliation Engine.

All thresholds come from RulesEngine (BRD config) — nothing is hardcoded here.
FoboReconciler.match_and_classify() is the single entry point.
"""
import logging
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from src.models import (
    FoTrade, BoSettlement, ReconResult,
    FieldBreak, BreakType, Severity
)
from src.rules_engine import RulesEngine

logger = logging.getLogger(__name__)


class FoboReconciler:

    def __init__(self, rules_engine: RulesEngine):
        self.rules = rules_engine

    def match_and_classify(
        self,
        fo: Optional[FoTrade],
        bo: Optional[BoSettlement],
        book: str = "EQ-DESK-ALL",
    ) -> ReconResult:
        """
        Match one FO/BO pair and classify any breaks.
        Business rules loaded from RulesEngine — no hardcoded thresholds.
        """
        rule_set = self.rules.resolve(book=book, asset_class="EQUITY")
        if not rule_set:
            raise ValueError(f"No active rule set for book={book}. Check fobo_rules.json.")

        # ── MISSING_IN_BO ──────────────────────────────────────────────────────
        if fo and not bo:
            pnl = fo.quantity * fo.price
            sev = self.rules.severity(rule_set, "MISSING_IN_BO")
            return ReconResult(
                fo_trade_id=fo.trade_id, bo_settlement_id=None,
                symbol=fo.symbol, break_type=BreakType.MISSING_IN_BO,
                severity=Severity(sev), pnl_impact=pnl,
                counterparty=fo.counterparty, book=fo.book,
                recommended_action=(
                    f"Escalate to settlement desk — no BO record for {fo.trade_id}. "
                    f"Unsettled exposure: ${pnl:,.2f}. "
                    f"Counterparty: {fo.counterparty}. Check Calypso booking."
                ),
                auto_resolvable=False,
            )

        # ── MISSING_IN_FO (orphan BO) ──────────────────────────────────────────
        if bo and not fo:
            pnl = bo.quantity * bo.price
            sev = self.rules.severity(rule_set, "MISSING_IN_FO")
            return ReconResult(
                fo_trade_id=None, bo_settlement_id=bo.settlement_id,
                symbol=bo.symbol, break_type=BreakType.MISSING_IN_FO,
                severity=Severity(sev), pnl_impact=pnl,
                counterparty=bo.counterparty, book=book,
                recommended_action=(
                    f"Investigate with FO — {bo.settlement_id} has no trade reference. "
                    f"Possible booking error or rogue settlement. "
                    f"Orphan notional: ${pnl:,.2f}."
                ),
                auto_resolvable=False,
            )

        # ── Field-level comparison ─────────────────────────────────────────────
        field_breaks: list[FieldBreak] = []
        total_pnl = 0.0

        # Price check — tolerance in basis points
        price_tol_bps = Decimal(str(self.rules.threshold(rule_set, "price_tol_bps", 2.0)))
        fo_price = Decimal(str(fo.price))
        bo_price = Decimal(str(bo.price))

        if fo_price > 0:
            bps_diff = (fo_price - bo_price).copy_abs() / fo_price * Decimal("10000")
            if bps_diff > price_tol_bps:
                price_pnl = float((fo_price - bo_price).copy_abs() * fo.quantity)
                total_pnl += price_pnl
                field_breaks.append(FieldBreak(
                    field_name="Price",
                    fo_value=f"${fo.price:.4f}",
                    bo_value=f"${bo.price:.4f}",
                    difference=f"Δ ${float(fo_price - bo_price):.4f} ({float(bps_diff):.2f} bps) | PnL ${price_pnl:,.2f}",
                    pnl_impact=price_pnl,
                ))

        # Quantity check — tolerance in percent
        qty_tol_pct = self.rules.threshold(rule_set, "qty_tol_pct", 0.5)
        if fo.quantity != bo.quantity:
            qty_diff_pct = abs(fo.quantity - bo.quantity) / fo.quantity * 100
            if qty_diff_pct > qty_tol_pct:
                field_breaks.append(FieldBreak(
                    field_name="Quantity",
                    fo_value=f"{fo.quantity:,}",
                    bo_value=f"{bo.quantity:,}",
                    difference=f"Δ {fo.quantity - bo.quantity:,} units ({qty_diff_pct:.1f}%)",
                    pnl_impact=0.0,
                ))

        # Status check
        if fo.status != bo.status:
            field_breaks.append(FieldBreak(
                field_name="Status",
                fo_value=fo.status,
                bo_value=bo.status,
                difference="Lifecycle difference",
                pnl_impact=0.0,
            ))

        # ── No breaks → CLEAN MATCH ────────────────────────────────────────────
        if not field_breaks:
            return ReconResult(
                fo_trade_id=fo.trade_id, bo_settlement_id=bo.settlement_id,
                symbol=fo.symbol, break_type=BreakType.MATCH,
                severity=Severity.CLEAN, field_breaks=[],
                pnl_impact=0.0, counterparty=fo.counterparty, book=fo.book,
                recommended_action="No action required — clean match.",
                auto_resolvable=False,
            )

        # ── Classify break type ────────────────────────────────────────────────
        has_price  = any(f.field_name == "Price"    for f in field_breaks)
        has_qty    = any(f.field_name == "Quantity" for f in field_breaks)
        has_status = any(f.field_name == "Status"   for f in field_breaks)

        if has_price and has_qty:
            break_type = BreakType.MULTI_BREAK
        elif has_price:
            break_type = BreakType.PRICE_BREAK
        elif has_qty:
            break_type = BreakType.QTY_BREAK
        else:
            break_type = BreakType.STATUS_MISMATCH

        # ── Severity (from rules, with PnL override) ───────────────────────────
        raw_sev = self.rules.severity(rule_set, break_type.value)

        if has_price and raw_sev != "AUTO_RESOLVE":
            pnl_high = self.rules.threshold(rule_set, "pnl_high_threshold", 10_000)
            pnl_med  = self.rules.threshold(rule_set, "pnl_medium_threshold", 1_000)
            if total_pnl >= pnl_high:
                raw_sev = "HIGH"
            elif total_pnl >= pnl_med and raw_sev not in ("HIGH",):
                raw_sev = "MEDIUM"

        auto_resolvable = self.rules.is_auto_resolvable(rule_set, break_type.value)

        # ── Recommended action from rules ──────────────────────────────────────
        action_map = {
            BreakType.PRICE_BREAK: (
                f"Verify execution price vs Bloomberg BVAL. "
                f"PnL at risk: ${total_pnl:,.2f}. "
                f"Contact {fo.counterparty} confirm agreed price. "
                f"Check accrued interest / clean vs dirty price."
            ),
            BreakType.QTY_BREAK: (
                f"Contact {fo.counterparty} to confirm agreed quantity. "
                f"Check for partial fills, novation, or split settlement."
            ),
            BreakType.STATUS_MISMATCH: (
                "Lifecycle difference — FO=CONFIRMED, BO=SETTLED is expected post-T+2. "
                "Check auto_resolve eligibility in rules config."
                if auto_resolvable else
                "Status mismatch outside auto-resolve window — manual review required."
            ),
            BreakType.MULTI_BREAK: (
                f"Multiple field breaks — escalate to PC immediately. "
                f"Total PnL exposure: ${total_pnl:,.2f}. "
                f"Do not auto-resolve."
            ),
        }

        return ReconResult(
            fo_trade_id=fo.trade_id, bo_settlement_id=bo.settlement_id,
            symbol=fo.symbol, break_type=break_type,
            severity=Severity(raw_sev), field_breaks=field_breaks,
            pnl_impact=total_pnl, counterparty=fo.counterparty, book=fo.book,
            recommended_action=action_map.get(break_type, "Manual review required."),
            auto_resolvable=auto_resolvable,
        )
