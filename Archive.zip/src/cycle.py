"""Full FOBO recon cycle for dashboard and automation."""
from __future__ import annotations

from typing import Any

from src.mcp_server import (
    _exceptions,
    create_exception,
    generate_report,
    reconcile_all,
)


def _norm(value: Any) -> Any:
    if hasattr(value, "value"):
        return value.value
    if isinstance(value, dict):
        return {k: _norm(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_norm(v) for v in value]
    s = str(value)
    if s.startswith(("BreakType.", "Severity.")):
        return s.split(".", 1)[-1]
    return value


def _trade_id(row: dict) -> str:
    return row.get("fo_trade_id") or row.get("bo_settlement_id") or "UNKNOWN"


def run_recon_cycle(
    trade_date: str,
    book: str = "ALL",
    *,
    file_exceptions: bool = True,
    clear_exceptions: bool = True,
) -> dict:
    """Run reconcile → exceptions → report. Returns JSON-serializable payload."""
    if clear_exceptions:
        _exceptions.clear()

    recon = reconcile_all(trade_date, book)
    recon = _norm(recon)

    created: list[dict] = []
    skipped: list[dict] = []

    if file_exceptions:
        for row in recon.get("results", []):
            sev = row.get("severity", "")
            if row.get("break_type") == "MATCH":
                skipped.append({**row, "skip_reason": "clean match"})
                continue
            if row.get("auto_resolvable"):
                skipped.append({**row, "skip_reason": "auto-resolvable"})
                continue
            if sev not in ("HIGH", "MEDIUM"):
                skipped.append({**row, "skip_reason": f"severity={sev}"})
                continue

            resp = create_exception(
                trade_id=_trade_id(row),
                break_type=row["break_type"],
                severity=sev,
                pnl_impact=row.get("pnl_impact", 0),
                counterparty=row.get("counterparty", "UNKNOWN"),
                book=row.get("book", book),
                description=row.get("recommended_action", ""),
            )
            resp = _norm(resp)
            if resp.get("status") == "created":
                created.append(resp["exception"])
            else:
                skipped.append({**row, "skip_reason": resp.get("message", "create failed")})

    report = _norm(generate_report(trade_date, format="DETAILED"))

    breaks = [r for r in recon.get("results", []) if r.get("break_type") != "MATCH"]
    by_type: dict[str, int] = {}
    for r in breaks:
        bt = r.get("break_type", "UNKNOWN")
        by_type[bt] = by_type.get(bt, 0) + 1

    return {
        "trade_date": trade_date,
        "book": book,
        "rule_set_applied": recon.get("rule_set_applied"),
        "summary": recon.get("summary", {}),
        "breaks_by_type": by_type,
        "results": recon.get("results", []),
        "exceptions_created": created,
        "exceptions_skipped": len(skipped),
        "report": report,
    }
