"""
FOBO Agent — Standalone runner using Anthropic SDK.
Runs the full reconciliation cycle autonomously via tool use.

Usage:
  export ANTHROPIC_API_KEY=sk-ant-...
  python src/agent.py --date 2025-05-19 --book ALL
  python src/agent.py --date 2025-05-19 --book EQ-DESK-A
"""
import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import anthropic

# Import tool functions directly (same process — no network needed for local run)
from src.mcp_server import (
    reconcile_all,
    create_exception,
    get_exceptions,
    reload_rules,
    generate_report,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("fobo-agent")


# ── Tool schemas — must match @mcp.tool() signatures in mcp_server.py ─────────
TOOLS = [
    {
        "name": "reconcile_all",
        "description": (
            "Run the complete FOBO reconciliation — loads FO + BO data, matches on trade_ref, "
            "classifies all breaks with PnL impacts. CALL THIS FIRST. "
            "Returns results list with break_type, severity, pnl_impact, auto_resolvable per trade."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "trade_date": {"type": "string", "description": "Trade date YYYY-MM-DD"},
                "book":       {"type": "string", "description": "Book scope: ALL | EQ-DESK-A | EQ-DESK-B | EQ-DESK-C", "default": "ALL"},
            },
            "required": ["trade_date"],
        },
    },
    {
        "name": "create_exception",
        "description": (
            "Create exception in TB-BB Exception Hub for a detected break. "
            "Call for every HIGH or MEDIUM severity break from reconcile_all. "
            "Do NOT call for CLEAN matches or auto_resolvable=true breaks."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "trade_id":     {"type": "string"},
                "break_type":   {"type": "string", "enum": ["PRICE_BREAK", "QTY_BREAK", "STATUS_MISMATCH", "MISSING_IN_BO", "MISSING_IN_FO", "MULTI_BREAK"]},
                "severity":     {"type": "string", "enum": ["HIGH", "MEDIUM", "LOW"]},
                "pnl_impact":   {"type": "number"},
                "counterparty": {"type": "string"},
                "book":         {"type": "string"},
                "description":  {"type": "string"},
            },
            "required": ["trade_id", "break_type", "severity", "pnl_impact", "counterparty", "book", "description"],
        },
    },
    {
        "name": "get_exceptions",
        "description": "Get all open exceptions created this session. Use before generate_report.",
        "input_schema": {
            "type": "object",
            "properties": {
                "severity_filter": {"type": "string", "default": "ALL"},
            },
        },
    },
    {
        "name": "reload_rules",
        "description": "Hot-reload business rules from config/fobo_rules.json after BRD update.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "generate_report",
        "description": "Generate final reconciliation report. CALL THIS LAST.",
        "input_schema": {
            "type": "object",
            "properties": {
                "trade_date": {"type": "string"},
                "format":     {"type": "string", "default": "SUMMARY"},
            },
            "required": ["trade_date"],
        },
    },
]

TOOL_MAP = {
    "reconcile_all":   reconcile_all,
    "create_exception": create_exception,
    "get_exceptions":  get_exceptions,
    "reload_rules":    reload_rules,
    "generate_report": generate_report,
}

SYSTEM_PROMPT = """
You are the FOBO Reconciliation Agent for Barclays Equity desks (EQ-DESK-A, EQ-DESK-B, EQ-DESK-C).

Your job: run a complete end-of-day reconciliation cycle autonomously.

Step-by-step execution order:
1. Call reconcile_all(trade_date, book) — this does ALL matching and break classification in one shot
2. For each result where break_type != "MATCH" AND severity in ["HIGH", "MEDIUM"]:
   - Call create_exception with trade_id, break_type, severity, pnl_impact, counterparty, book, description
3. Skip create_exception if:
   - break_type == "MATCH" (clean)
   - auto_resolvable == true AND break_type == "STATUS_MISMATCH"
4. Call get_exceptions to review what was logged
5. Call generate_report(trade_date, format="DETAILED") as the final step

Hard constraints:
- MISSING_IN_BO is ALWAYS HIGH — never skip creating an exception for it
- If counterparty is in escalation list (Goldman Sachs, JPMorgan, etc.) → P1 regardless of PnL
- Never hardcode thresholds — they come from the rules config
- After generate_report, write a plain-English summary of findings for the controller

When done, summarise: total breaks by type, total PnL at risk, P1 exceptions, and top recommended actions.
"""


def _call_tool(name: str, inputs: dict) -> str:
    func = TOOL_MAP[name]
    result = func(**inputs)
    return json.dumps(result, default=str, indent=2)


def run_agent(trade_date: str, book: str = "ALL") -> None:
    client = anthropic.Anthropic()

    print(f"\n{'═'*64}")
    print(f"  FOBO Reconciliation Agent")
    print(f"  Trade date: {trade_date}   Book: {book}")
    print(f"{'═'*64}\n")

    messages = [
        {
            "role": "user",
            "content": f"Run the FOBO reconciliation for trade date {trade_date}, book scope: {book}.",
        }
    ]

    iteration = 0
    max_iterations = 20  # Safety cap

    while iteration < max_iterations:
        iteration += 1

        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=8096,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        # Print text output
        for block in response.content:
            if block.type == "text" and block.text.strip():
                print(f"\n[Agent]\n{block.text}\n")

        if response.stop_reason == "end_turn":
            break

        # Execute tool calls
        tool_uses = [b for b in response.content if b.type == "tool_use"]
        if not tool_uses:
            break

        tool_results = []
        for tc in tool_uses:
            print(f"  ▶ {tc.name}({json.dumps(tc.input, default=str)})")
            raw = _call_tool(tc.name, tc.input)
            parsed = json.loads(raw)

            # Print key info without flooding console
            if "summary" in parsed:
                s = parsed["summary"]
                print(f"    → breaks={s.get('total_breaks',0)}  pnl=${s.get('total_pnl_impact',0):,.0f}  high={s.get('high',0)}")
            elif "exception" in parsed:
                e = parsed["exception"]
                print(f"    → {e['exception_id']} [{e['priority']}] {e['break_type']} ${e['pnl_impact']:,.0f}")
            elif "report_id" in parsed:
                print(f"    → {parsed['report_id']} — {parsed['summary']['total_exceptions']} exceptions  PnL ${parsed['summary']['total_pnl_at_risk']:,.0f}")
            elif "rule_sets_loaded" in parsed:
                print(f"    → {parsed['rule_sets_loaded']} rule sets reloaded")

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tc.id,
                "content": raw,
            })

        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user",      "content": tool_results})

    print(f"\n{'═'*64}")
    print("  FOBO Agent cycle complete")
    print(f"{'═'*64}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="FOBO Reconciliation Agent")
    parser.add_argument("--date", default="2025-05-19",  help="Trade date YYYY-MM-DD")
    parser.add_argument("--book", default="ALL",         help="Book scope: ALL | EQ-DESK-A | ...")
    args = parser.parse_args()

    run_agent(trade_date=args.date, book=args.book)
