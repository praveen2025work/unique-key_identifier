import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  transpilePackages: [
    "@json-render/core",
    "@json-render/react",
    "@json-render/shadcn",
    "@modelcontextprotocol/ext-apps",
  ],
};

export default nextConfig;
