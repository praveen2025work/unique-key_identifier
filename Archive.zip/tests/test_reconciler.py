"""
FOBO Agent — Unit tests.
Run: pytest tests/ -v
"""
import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models import FoTrade, BoSettlement, BreakType, Severity
from src.rules_engine import RulesEngine
from src.reconciler import FoboReconciler


RULES_PATH = "config/fobo_rules.json"


@pytest.fixture
def engine():
    return RulesEngine(RULES_PATH)


@pytest.fixture
def reconciler(engine):
    return FoboReconciler(engine)


def fo(trade_id="TRD-001", qty=10000, price=185.50, cpty="Citi", book="EQ-DESK-A"):
    return FoTrade(
        trade_id=trade_id, instrument="AAPL US Equity", symbol="AAPL",
        quantity=qty, price=price, trade_date="2025-05-19",
        counterparty=cpty, book=book, status="CONFIRMED",
    )


def bo(settlement_id="SET-001", trade_ref="TRD-001", qty=10000, price=185.50, status="SETTLED"):
    return BoSettlement(
        settlement_id=settlement_id, trade_ref=trade_ref,
        instrument="AAPL US Equity", symbol="AAPL",
        quantity=qty, price=price, trade_date="2025-05-19",
        settlement_date="2025-05-21", counterparty="Citi", status=status,
    )


# ── Rules engine ───────────────────────────────────────────────────────────────

class TestRulesEngine:

    def test_loads_rule_sets(self, engine):
        assert len(engine._rule_sets) >= 1

    def test_wildcard_resolves_to_default(self, engine):
        rule = engine.resolve(book="EQ-DESK-C", asset_class="EQUITY")
        assert rule is not None
        assert rule.book_pattern == "*"

    def test_specific_book_wins(self, engine):
        rule = engine.resolve(book="EQ-DESK-A", asset_class="EQUITY")
        assert rule is not None
        assert rule.book_pattern == "EQ-DESK-A"
        assert rule.priority > 1

    def test_reload(self, engine):
        count = engine.reload()
        assert count >= 1

    def test_threshold_access(self, engine):
        rule = engine.resolve("EQ-DESK-A")
        tol = engine.threshold(rule, "price_tol_bps")
        assert tol > 0

    def test_auto_resolve_status_mismatch_default(self, engine):
        rule = engine.resolve("EQ-DESK-B")
        assert engine.is_auto_resolvable(rule, "STATUS_MISMATCH") is True

    def test_no_auto_resolve_on_strict_desk(self, engine):
        rule = engine.resolve("EQ-DESK-A")
        assert engine.is_auto_resolvable(rule, "STATUS_MISMATCH") is False


# ── Reconciler ─────────────────────────────────────────────────────────────────

class TestReconciler:

    def test_clean_match(self, reconciler):
        result = reconciler.match_and_classify(fo=fo(), bo=bo(), book="EQ-DESK-A")
        assert result.break_type == BreakType.MATCH
        assert result.severity   == Severity.CLEAN
        assert result.pnl_impact == 0.0

    def test_missing_in_bo(self, reconciler):
        result = reconciler.match_and_classify(fo=fo(), bo=None, book="EQ-DESK-A")
        assert result.break_type == BreakType.MISSING_IN_BO
        assert result.severity   == Severity.HIGH
        assert result.pnl_impact == 10000 * 185.50

    def test_missing_in_fo_orphan(self, reconciler):
        orphan = bo(trade_ref=None)
        result = reconciler.match_and_classify(fo=None, bo=orphan, book="EQ-DESK-ALL")
        assert result.break_type == BreakType.MISSING_IN_FO
        assert result.severity   == Severity.HIGH

    def test_price_break_detected(self, reconciler):
        # 182.00 vs 185.50 = ~18.9 bps — above 1 bps tolerance for EQ-DESK-A
        result = reconciler.match_and_classify(
            fo=fo(price=185.50), bo=bo(price=182.00), book="EQ-DESK-A"
        )
        assert result.break_type == BreakType.PRICE_BREAK
        assert result.severity   == Severity.HIGH
        assert result.pnl_impact > 0

    def test_price_within_tolerance(self, reconciler):
        # 0.05 bps difference — within 1 bps tolerance for EQ-DESK-A
        result = reconciler.match_and_classify(
            fo=fo(price=185.50), bo=bo(price=185.499), book="EQ-DESK-A"
        )
        assert result.break_type == BreakType.MATCH

    def test_qty_break_detected(self, reconciler):
        # 4500 vs 5000 = 10% — above 0.1% tolerance for EQ-DESK-A
        result = reconciler.match_and_classify(
            fo=fo(qty=5000), bo=bo(qty=4500), book="EQ-DESK-A"
        )
        assert result.break_type == BreakType.QTY_BREAK
        assert result.severity   == Severity.HIGH

    def test_status_mismatch_low_severity(self, reconciler):
        result = reconciler.match_and_classify(
            fo=fo(), bo=bo(status="SETTLED"), book="EQ-DESK-A"
        )
        # STATUS_MISMATCH with different status value
        broken_fo = fo()
        broken_fo = FoTrade(
            **{**broken_fo.model_dump(), "status": "CONFIRMED"}
        )
        result = reconciler.match_and_classify(fo=broken_fo, bo=bo(status="PENDING"), book="EQ-DESK-B")
        assert result.break_type == BreakType.STATUS_MISMATCH
        assert result.severity   == Severity.LOW

    def test_multi_break_price_and_qty(self, reconciler):
        result = reconciler.match_and_classify(
            fo=fo(qty=5000, price=185.50),
            bo=bo(qty=4500, price=182.00),
            book="EQ-DESK-A"
        )
        assert result.break_type == BreakType.MULTI_BREAK

    def test_escalation_counterparty_p1(self, engine):
        # Goldman Sachs is in escalation list → always P1
        rule = engine.resolve("EQ-DESK-A")
        priority = engine.escalation_priority(rule, pnl_impact=100.0, counterparty="Goldman Sachs")
        assert priority == "P1"

    def test_large_pnl_p1(self, engine):
        rule = engine.resolve("EQ-DESK-A")
        # EQ-DESK-A pnl_escalate_amount = 500,000
        priority = engine.escalation_priority(rule, pnl_impact=600_000.0, counterparty="Citi")
        assert priority == "P1"

    def test_no_rule_set_raises(self, reconciler):
        with pytest.raises(ValueError, match="No active rule set"):
            reconciler.match_and_classify(fo=fo(), bo=None, book="UNKNOWN-BOOK")
