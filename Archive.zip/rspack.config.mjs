import { rspack } from "@rspack/core";
import { ModuleFederationPlugin } from "@module-federation/enhanced/rspack";
import { moduleFederationHostConfig } from "./module-federation.config.ts";

/** Standalone rspack host build for Module Federation remotes */
export default {
  mode: "production",
  entry: "./src/mfe-entry.ts",
  output: {
    path: new URL("./dist/mfe", import.meta.url).pathname,
    filename: "[name].js",
    publicPath: "auto",
    clean: true,
  },
  resolve: {
    extensions: [".ts", ".tsx", ".js", ".jsx"],
    alias: {
      "@": new URL("./src", import.meta.url).pathname,
    },
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: {
          loader: "builtin:swc-loader",
          options: {
            jsc: {
              parser: { syntax: "typescript", tsx: true },
              transform: { react: { runtime: "automatic" } },
            },
          },
        },
        type: "javascript/auto",
      },
    ],
  },
  plugins: [
    new ModuleFederationPlugin(moduleFederationHostConfig),
    new rspack.DefinePlugin({
      "process.env.NODE_ENV": JSON.stringify("production"),
    }),
  ],
};
