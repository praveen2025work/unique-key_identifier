"""
AOF / AWS Bedrock Agent setup script.
Registers the FOBO MCP server as a Bedrock agent action group.

Prerequisites:
  pip install boto3
  aws configure  (or use instance role / assume-role in office)

Usage:
  python aof/setup_aof_agent.py --env dev --server-url http://fobo-server:8000/sse
  python aof/setup_aof_agent.py --env prod --server-url http://fobo-prod.internal:8000/sse
"""
import argparse
import json
import boto3
from pathlib import Path

DEFAULT_MODEL = "anthropic.claude-3-5-sonnet-20241022-v2:0"

AGENT_INSTRUCTION = """
You are the FOBO Reconciliation Agent for Barclays Equity desks (EQ-DESK-A, EQ-DESK-B, EQ-DESK-C).

Run complete reconciliation cycles using the fobo MCP tools in this order:
1. reconcile_all(trade_date, book) — runs all matching and break classification
2. create_exception for each result with severity HIGH or MEDIUM and auto_resolvable=false
3. get_exceptions to confirm what was logged
4. generate_report(trade_date, format="DETAILED") — always last

Hard rules:
- MISSING_IN_BO always requires an exception — never skip
- STATUS_MISMATCH with auto_resolvable=true can be skipped
- If counterparty is in escalation list → P1 regardless of PnL amount
- Never hardcode thresholds — they come from the rules config loaded at runtime
- After generate_report, summarise in plain English for the Product Control controller
""".strip()


def create_fobo_agent(
    session: boto3.Session,
    server_url: str,
    env: str,
    role_arn: str,
) -> dict:
    bedrock = session.client("bedrock-agent")

    # 1. Create the agent
    agent_name = f"FOBO-Recon-Agent-{env.upper()}"
    print(f"Creating Bedrock agent: {agent_name}")

    agent_resp = bedrock.create_agent(
        agentName=agent_name,
        agentResourceRoleArn=role_arn,
        foundationModel=DEFAULT_MODEL,
        description="FOBO equity trade reconciliation agent",
        instruction=AGENT_INSTRUCTION,
        idleSessionTTLInSeconds=1800,
    )
    agent_id = agent_resp["agent"]["agentId"]
    print(f"Agent created: {agent_id}")

    # 2. Create action group pointing to the FOBO MCP server (SSE)
    print(f"Registering MCP server: {server_url}")
    ag_resp = bedrock.create_agent_action_group(
        agentId=agent_id,
        agentVersion="DRAFT",
        actionGroupName="fobo-mcp-tools",
        description="FOBO reconciliation MCP tools",
        actionGroupExecutor={
            "customControl": "RETURN_CONTROL"
        },
        # MCP server registration — AgentCore MCP support
        # Note: field name may vary by SDK version; check latest Bedrock docs
        mcpServers=[
            {
                "serverName": "fobo",
                "url": server_url,
                "authType": "NONE",  # Use VPC + SG for network-level security in prod
            }
        ],
    )
    ag_id = ag_resp["agentActionGroup"]["actionGroupId"]
    print(f"Action group created: {ag_id}")

    # 3. Prepare the agent (makes it ready for invocation)
    bedrock.prepare_agent(agentId=agent_id)
    print("Agent prepared and ready")

    return {"agent_id": agent_id, "action_group_id": ag_id, "server_url": server_url}


def invoke_fobo_agent(
    session: boto3.Session,
    agent_id: str,
    agent_alias_id: str,
    trade_date: str,
    book: str = "ALL",
) -> str:
    """
    Invoke the FOBO agent to run a reconciliation cycle.
    AOF is the orchestrator — it calls the MCP tools autonomously.
    """
    runtime = session.client("bedrock-agent-runtime")

    prompt = f"Run the FOBO reconciliation for trade date {trade_date}, book scope: {book}."

    resp = runtime.invoke_agent(
        agentId=agent_id,
        agentAliasId=agent_alias_id,
        sessionId=f"fobo-{trade_date}-{book}",
        inputText=prompt,
    )

    # Stream the response
    output = ""
    for event in resp["completion"]:
        if "chunk" in event:
            output += event["chunk"]["bytes"].decode("utf-8")

    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Register FOBO agent with AWS Bedrock")
    parser.add_argument("--env",        default="dev",  help="dev | uat | prod")
    parser.add_argument("--server-url", required=True,  help="FOBO MCP server SSE URL")
    parser.add_argument("--role-arn",   required=True,  help="IAM role ARN for Bedrock agent")
    parser.add_argument("--region",     default="us-east-1")
    args = parser.parse_args()

    session = boto3.Session(region_name=args.region)
    result = create_fobo_agent(
        session=session,
        server_url=args.server_url,
        env=args.env,
        role_arn=args.role_arn,
    )

    print(f"\nFOBO Agent registered:")
    print(json.dumps(result, indent=2))
    print("\nTo invoke from Python:")
    print(f"  invoke_fobo_agent(session, agent_id='{result['agent_id']}', ...)")
